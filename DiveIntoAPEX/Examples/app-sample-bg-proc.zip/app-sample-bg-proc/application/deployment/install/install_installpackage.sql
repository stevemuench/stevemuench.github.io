prompt --application/deployment/install/install_installpackage
begin
--   Manifest
--     INSTALL: INSTALL-InstallPackage
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(58731239038935481)
,p_install_id=>wwv_flow_imp.id(61241442352863946)
,p_name=>'InstallPackage'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace PACKAGE "EBA_DEMO_BG_PROC" as     ',
'     ',
'    -- Return the user who submitted the background process     ',
'    -- that is currently processing deptno passed in, or null     ',
'    function user_processing_deptno(p_deptno number)      ',
'    return varchar2;     ',
'    -- Register what user is about to process the     ',
'    -- deptno passed in in a background job         ',
'    function register_user_processing_deptno(p_deptno number)     ',
'    return number;     ',
'    -- Register what execution_id is processing the    ',
'    -- deptno processing request in a background job         ',
'    procedure add_current_execution_id(p_bg_proc_id number);     ',
'     ',
'    -- Process the deptno passed in (LONG-RUNNING)     ',
'    procedure process_deptno(p_deptno number);     ',
'     ',
'    -- Unregister what user is currently processing the     ',
'    -- deptno passed in in a background job     ',
'    procedure unregister_bg_proc_for_deptno(p_deptno number,      ',
'                                            p_orig_id number,    ',
'                                            p_success boolean := true);      ',
'   ',
'    -- handle page processing error on page 3   ',
'    function p3_handle_bg_processing_error(p_error apex_error.t_error)   ',
'    return apex_error.t_error_result;   ',
'end;   ',
'/',
'create or replace PACKAGE BODY "EBA_DEMO_BG_PROC" as      ',
'     ',
'    function user_processing_deptno(p_deptno number)      ',
'    return varchar2      ',
'    is     ',
'        l_ret eba_demo_bg_proc_processes.username%type;     ',
'    begin     ',
'        select username     ',
'        into l_ret     ',
'        from eba_demo_bg_proc_processes     ',
'        where deptno = p_deptno;     ',
'        return l_ret;     ',
'    exception     ',
'        when no_data_found then     ',
'            return null;     ',
'    end;     ',
'    procedure add_current_execution_id(p_bg_proc_id number)    ',
'    is    ',
'        pragma autonomous_transaction;     ',
'        l_exid number := apex_background_process.get_current_execution().id;     ',
'    begin    ',
'        update eba_demo_bg_proc_processes    ',
'        set execution_id = l_exid,    ',
'            started_execution_at = sysdate    ',
'        where id = p_bg_proc_id;    ',
'        commit;    ',
'    end;    ',
'     ',
'     ',
'    function register_user_processing_deptno(p_deptno number)     ',
'    return number     ',
'    is     ',
'        l_ret eba_demo_bg_proc_processes.id%type;     ',
'        l_username varchar2(255) := v(''APP_USER'');     ',
'    begin     ',
'        insert into eba_demo_bg_proc_processes(     ',
'                        username,     ',
'                        deptno)     ',
'        values (l_username,     ',
'                p_deptno)     ',
'        returning id into l_ret;     ',
'        commit;     ',
'        return l_ret;     ',
'    end;     ',
'     ',
'    procedure process_deptno(p_deptno number)     ',
'    is    ',
'        c_total_secs constant integer := 60 + round(dbms_random.value(0,40));     ',
'        c_steps      constant integer := 10;    ',
'    begin     ',
'        -- Simulate a long-running process that will take between 60 and 100 seconds     ',
'        apex_background_process.set_progress(p_totalwork=>c_steps,p_sofar=>0);     ',
'        for j in 1..c_steps loop     ',
'            dbms_session.sleep(round(c_total_secs/10));     ',
'            apex_background_process.set_progress(p_totalwork=>c_steps,p_sofar=>j);     ',
'        end loop;     ',
'    end;     ',
'     ',
'    procedure unregister_bg_proc_for_deptno(p_deptno number,      ',
'                                            p_orig_id number,    ',
'                                            p_success boolean := true)     ',
'    is     ',
'        pragma autonomous_transaction;     ',
'        l_username varchar2(255) := v(''APP_USER'');     ',
'    begin    ',
'        if p_success then     ',
'            insert into eba_demo_bg_proc_history(    ',
'                deptno,    ',
'                username,    ',
'                wait_to_start_time,    ',
'                running_time)    ',
'            select bp.deptno,    ',
'                   bp.username,    ',
'                   bp.started_execution_at - bgp.created_on,    ',
'                   systimestamp - bp.started_execution_at    ',
'              from  eba_demo_bg_proc_processes bp    ',
'              left join apex_appl_page_bg_proc_status bgp    ',
'                     on bgp.execution_id = bp.execution_id    ',
'             where username = l_username      ',
'               and deptno = p_deptno     ',
'               and id = p_orig_id;    ',
'        end if;                 ',
'        delete from eba_demo_bg_proc_processes     ',
'        where username = l_username      ',
'          and deptno = p_deptno     ',
'          and id = p_orig_id;     ',
'        commit;     ',
'    end;',
'',
'    function is_process_error(',
'                p_error apex_error.t_error, ',
'                p_process_name varchar2) return boolean is',
'    begin',
'        return p_error.component.type = ''APEX_APPLICATION_PAGE_PROCESS'' and',
'               p_error.component.name = p_process_name;',
'    end;     ',
'       ',
'    function p3_handle_bg_processing_error(p_error apex_error.t_error)   ',
'    return apex_error.t_error_result is  ',
'        l_result apex_error.t_error_result;   ',
'    begin   ',
'        l_result := apex_error.init_error_result(   ',
'                    p_error => p_error);  ',
'        if is_process_error(p_error,''Process Department in Background'') then   ',
'            unregister_bg_proc_for_deptno(   ',
'                p_deptno  => V(''P3_DEPTNO''),   ',
'                p_orig_id => V(''P3_ONGOING_WORK_ID''),   ',
'                p_success => false   ',
'            );   ',
'        end if;  ',
'        return l_result;   ',
'    end;   ',
'end;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(58731298749935485)
,p_script_id=>wwv_flow_imp.id(58731239038935481)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_BG_PROC'
,p_last_updated_by=>'SMUENCH'
,p_last_updated_on=>to_date('20230126164022','YYYYMMDDHH24MISS')
,p_created_by=>'SMUENCH'
,p_created_on=>to_date('20230126164022','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
