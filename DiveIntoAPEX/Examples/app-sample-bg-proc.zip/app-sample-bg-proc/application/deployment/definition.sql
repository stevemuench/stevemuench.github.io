prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 102
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(61241442352863946)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- drop objects',
'drop table eba_demo_bg_proc_processes cascade constraints;',
'drop table eba_demo_bg_proc_history cascade constraints;',
'drop package eba_demo_bg_proc;',
'',
''))
);
wwv_flow_imp.component_end;
end;
/
