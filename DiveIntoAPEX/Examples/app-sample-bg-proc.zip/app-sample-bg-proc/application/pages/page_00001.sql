prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Departments'
,p_alias=>'DEPARTMENTS'
,p_step_title=>'Departments'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.theme42.util.configAPEXMsgs({',
'    autoDismiss: true,',
'    duration: 5000',
'});'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230506121110'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61482316129672995)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(60463443935051456)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    <ul>',
'        <li>',
'            Select a department to edit. To process that department, click (Process) on the edit page.',
'        </li>',
'        <li>',
'            To see processing status, use the <i>Processing Status</i> page',
'        </li>',
'        <li>',
'            The <i>Hide Process Button</i> toggle menu under your username avoids showing',
'            the button if department is already being processed.',
'        </li> ',
'',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(60838353043615291)
,p_name=>'Departments'
,p_template=>wwv_flow_imp.id(60444613517051451)
,p_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:t-Report--altRowsDefault:t-Report--rowHighlight'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d.DEPTNO,',
'       d.DNAME,',
'       d.LOC,',
'       p.username,',
'       case',
'         when p.username is not null then ''fa fa-hourglass-2'' ',
'       end as icon_class',
'  from DEPT d',
'  left outer join eba_demo_bg_proc_processes p on p.deptno = d.deptno',
' order by deptno'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(60548514344051477)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60839045564615298)
,p_query_column_id=>1
,p_column_alias=>'DEPTNO'
,p_column_display_sequence=>10
,p_column_heading=>'Deptno'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_DEPTNO:#DEPTNO#'
,p_column_linktext=>'#DEPTNO#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60839233178615299)
,p_query_column_id=>2
,p_column_alias=>'DNAME'
,p_column_display_sequence=>20
,p_column_heading=>'Dname'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(60839333864615300)
,p_query_column_id=>3
,p_column_alias=>'LOC'
,p_column_display_sequence=>30
,p_column_heading=>'Loc'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(61483618756673008)
,p_query_column_id=>4
,p_column_alias=>'USERNAME'
,p_column_display_sequence=>50
,p_use_as_row_header=>'N'
,p_hidden_column=>'Y'
,p_derived_column=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(61483445629673007)
,p_query_column_id=>5
,p_column_alias=>'ICON_CLASS'
,p_column_display_sequence=>40
,p_column_heading=>'Processing'
,p_use_as_row_header=>'N'
,p_column_html_expression=>'<span class="#ICON_CLASS#" title="#USERNAME#"></span>'
,p_column_alignment=>'CENTER'
,p_display_when_cond_type=>'NEVER'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(60865513034798126)
,p_name=>'On Dialog Closed'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'body'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(61480754026672980)
,p_event_id=>wwv_flow_imp.id(60865513034798126)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Show Success Message If Any'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if ( this.data.successMessage ) {',
'  apex.message.showPageSuccess(this.data.successMessage.text);',
'}'))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(60865623247798127)
,p_event_id=>wwv_flow_imp.id(60865513034798126)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(60838353043615291)
);
wwv_flow_imp.component_end;
end;
/
