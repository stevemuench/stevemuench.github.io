prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Processing History'
,p_alias=>'PROCESSING-HISTORY'
,p_step_title=>'Processing History'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'06'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230126193013'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(61483306156673005)
,p_plug_name=>'Average Times'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#:u-colors:t-BadgeList--dash:t-BadgeList--fixed:t-BadgeList--large'
,p_plug_template=>wwv_flow_imp.id(60444613517051451)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_list_id=>wwv_flow_imp.id(58734349026160736)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>wwv_flow_imp.id(60555284494051479)
);
wwv_flow_imp.component_end;
end;
/
