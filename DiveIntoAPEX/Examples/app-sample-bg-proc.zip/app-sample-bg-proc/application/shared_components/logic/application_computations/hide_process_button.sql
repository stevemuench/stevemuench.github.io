prompt --application/shared_components/logic/application_computations/hide_process_button
begin
--   Manifest
--     APPLICATION COMPUTATION: HIDE_PROCESS_BUTTON
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(61487245265701623)
,p_computation_sequence=>10
,p_computation_item=>'HIDE_PROCESS_BUTTON'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'Y'
);
wwv_flow_imp.component_end;
end;
/
