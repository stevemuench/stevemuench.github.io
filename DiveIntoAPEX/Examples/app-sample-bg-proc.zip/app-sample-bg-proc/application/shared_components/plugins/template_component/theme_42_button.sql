prompt --application/shared_components/plugins/template_component/theme_42_button
begin
--   Manifest
--     PLUGIN: THEME_42$BUTTON
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(119092146546588170)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '42')
,p_name=>'THEME_42$BUTTON'
,p_display_name=>'Button'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','THEME_42$BUTTON'),'')
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if MENU_ID/}',
'<button class="t-Button {if IS_HOT/} t-Button--hot{endif/}{if IS_ICON_ONLY/} t-Button--noLabel t-Button--icon{else/} t-Button--iconLeft{endif/} #CSS_CLASSES!ATTR#" title="#LABEL!ATTR#"  type="button" data-menu="#MENU_ID!ATTR#" {if IS_DISABLED/} disab'
||'led{endif/}>',
'{else/}',
'<a class="t-Button {if IS_HOT/} t-Button--hot{endif/}{if IS_ICON_ONLY/} t-Button--noLabel t-Button--icon{else/} t-Button--iconLeft{endif/} #CSS_CLASSES!ATTR#" title="#LABEL!ATTR#" href="#LINK_URL#" #LINK_ATTR# {if IS_DISABLED/} disabled{endif/}>',
'{endif/}',
'  {if ?ICON_CLASSES/}<span class="t-Icon t-Icon--left #ICON_CLASSES!ATTR#" aria-hidden="true"></span>{endif/}',
'  <span class="t-Button-label">#LABEL#</span>',
'{if MENU_ID/}',
'</button>',
'{else/}',
'</a>',
'{endif/}',
''))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_substitute_attributes=>true
,p_reference_id=>1568467215199837453
,p_subscribe_plugin_settings=>true
);
wwv_flow_imp.component_end;
end;
/
