prompt --application/shared_components/automations/t
begin
--   Manifest
--     AUTOMATION: t
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_automation(
 p_id=>wwv_flow_imp.id(62957556133175890)
,p_name=>'t'
,p_static_id=>'t'
,p_trigger_type=>'POLLING'
,p_polling_interval=>'FREQ=MINUTELY;INTERVAL=1'
,p_polling_status=>'DISABLED'
,p_result_type=>'ALWAYS'
,p_use_local_sync_table=>false
,p_include_rowid_column=>false
,p_commit_each_row=>false
,p_error_handling_type=>'IGNORE'
);
wwv_flow_imp_shared.create_automation_action(
 p_id=>wwv_flow_imp.id(62957812633175891)
,p_automation_id=>wwv_flow_imp.id(62957556133175890)
,p_name=>'New Action'
,p_execution_sequence=>10
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    null;',
'end;'))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp.component_end;
end;
/
