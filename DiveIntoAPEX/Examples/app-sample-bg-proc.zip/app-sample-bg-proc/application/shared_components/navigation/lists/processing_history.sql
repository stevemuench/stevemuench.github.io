prompt --application/shared_components/navigation/lists/processing_history
begin
--   Manifest
--     LIST: Processing History
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>23127342230087908646
,p_default_application_id=>20217
,p_default_id_offset=>139345408082843357
,p_default_owner=>'WKSP_DEMOAPEX'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(58734349026160736)
,p_name=>'Processing History'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select null      c1_level,',
'       label     c2_name_for_label,',
'       null      c3_target_url,',
'       null      c4_is_current,',
'       null      c5_icon_name,',
'       null      c6_icon_attrs,',
'       null      c7_icon_alt_text,',
'       avg_time       c8_user_attr1_badge_text',
'from (',
'select ''Average Running Time'' as label,',
'        extract( hour from (numtodsinterval(avg((sysdate + running_time) - sysdate),''day'')))||''h ''||',
'        extract( minute from (numtodsinterval(avg((sysdate + running_time) - sysdate),''day'')))||''m ''||',
'        round(extract( second from (numtodsinterval(avg((sysdate + running_time) - sysdate),''day''))))||''s''',
'        as avg_time',
' from eba_demo_bg_proc_history',
'union all',
'select ''Average Wait to Start Time'',',
'        extract( hour from (numtodsinterval(avg((sysdate + wait_to_start_time) - sysdate),''day'')))||''h ''||',
'        extract( minute from (numtodsinterval(avg((sysdate + wait_to_start_time) - sysdate),''day'')))||''m ''||',
'        round(extract( second from (numtodsinterval(avg((sysdate + wait_to_start_time) - sysdate),''day''))))||''s''',
'  from eba_demo_bg_proc_history)',
''))
,p_list_status=>'PUBLIC'
);
wwv_flow_imp.component_end;
end;
/
