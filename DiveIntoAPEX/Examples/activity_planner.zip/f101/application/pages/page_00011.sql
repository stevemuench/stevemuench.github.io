prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Venue'
,p_alias=>'VENUE'
,p_page_mode=>'MODAL'
,p_step_title=>'Venue'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(5997674534939065505)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20231008103312'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7983422059384697728)
,p_plug_name=>'Map'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5997710520316065523)
,p_plug_display_sequence=>20
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7994388509929366683)
,p_plug_name=>'Venue'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5997710520316065523)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select  v.code,',
'        v.description,',
'        v.latitude,',
'        v.longitude,',
'        v.created,',
'        v.created_by,',
'        v.updated,',
'        v.updated_by,',
'        v.address,',
'        v.trip_id,',
'        case ',
'            when v.longitude is not null and v.latitude is not null then',
'                sdo_geometry(',
'                    2001,',
'                        4326,',
'                        sdo_point_type(',
'                            v.longitude,',
'                            v.latitude,',
'                            null),',
'                        null,',
'                        null)',
'        end geocoded_address',
'  from eba_demo_ann_venues v'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(7994394417201366688)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5997713251976065524)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8832961564562824)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_button_name=>'Trigger_Geocoding'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997849713834065586)
,p_button_image_alt=>'Trigger Geocoding'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-map-marker-shine'
,p_grid_column_css_classes=>'u-align-self-center'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994394841665366688)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7994394417201366688)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997850405406065586)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7983422757652697735)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(7994394417201366688)
,p_button_name=>'DUPLICATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997850405406065586)
,p_button_image_alt=>'Duplicate'
,p_button_position=>'DELETE'
,p_button_redirect_url=>'f?p=&APP_ID.:11:&SESSION.:DUPLICATE:&DEBUG.:11:P11_LATITUDE,P11_LONGITUDE,P11_ADDRESS,P11_DESCRIPTION:&P11_LATITUDE.,&P11_LONGITUDE.,\&P11_ADDRESS.\,\&P11_DESCRIPTION.\'
,p_button_condition=>'P11_CODE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994396171345366689)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(7994394417201366688)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997850405406065586)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P11_CODE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994396587824366690)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(7994394417201366688)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997850405406065586)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P11_CODE'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(7994396975635366690)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(7994394417201366688)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(5997850405406065586)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P11_CODE'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8832204944562817)
,p_name=>'P11_TRIP_ID'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'TRIP_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8832816480562823)
,p_name=>'P11_CURRENT_TRIP_COUNTRY_CODE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_prompt=>'Country'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'GEOCODE_COUNTRIES'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r, d',
'from (',
'select REGEXP_SUBSTR(column_value,''[^:]+'',1,1) r,',
'       REGEXP_SUBSTR(column_value,''[^:]+'',1,2) d ',
'from table(apex_string.split(''US:United States;UK:United Kingdom;DE:Germany;FR:France;IT:Italy;CA:Canada;NL:Netherlands;BE:Belgium;AT:Austria;CH:Switzerland;ES:Spain;PT:Portugal;RU:Russian Federation;EE:Estonia;IN:India;MX:Mexico;AU:Australia;BR:Braz'
||'il;CL:Chile;CZ:Czech Republic;NO:Norway;FI:Finland;DK:Denmark;HK:Hong Kong;IE:Ireland;LV:Latvia;RO:Romania;CO:Colombia;PL:Poland;AE:United Arab Emirates;HU:Hungary;SA:Saudi Arabia;ZA:South Africa'','';''))',
') order by d'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>wwv_flow_imp.id(5997847870575065585)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7983421928626697726)
,p_name=>'P11_ADDRESS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_prompt=>'Address'
,p_source=>'ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>1020
,p_field_template=>wwv_flow_imp.id(5997849148818065586)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7983421946225697727)
,p_name=>'P11_GEOCODED_ADDRESS'
,p_source_data_type=>'SDO_GEOMETRY'
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7983422059384697728)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_prompt=>'Map'
,p_source=>'GEOCODED_ADDRESS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_GEOCODED_ADDRESS'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(5997847870575065585)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'ITEM'
,p_attribute_03=>'P11_CURRENT_TRIP_COUNTRY_CODE'
,p_attribute_05=>'P11_ADDRESS'
,p_attribute_14=>'AUTOMATIC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994388807921366684)
,p_name=>'P11_CODE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_primary_key=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_prompt=>'Code'
,p_source=>'CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>16
,p_field_template=>wwv_flow_imp.id(5997849148818065586)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994389163730366684)
,p_name=>'P11_DESCRIPTION'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_prompt=>'Description'
,p_source=>'DESCRIPTION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>400
,p_field_template=>wwv_flow_imp.id(5997849148818065586)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994389635622366685)
,p_name=>'P11_LATITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'LATITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994389977243366685)
,p_name=>'P11_LONGITUDE'
,p_source_data_type=>'NUMBER'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'LONGITUDE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994390384103366686)
,p_name=>'P11_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994390805402366686)
,p_name=>'P11_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994391218993366686)
,p_name=>'P11_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(7994391603733366686)
,p_name=>'P11_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_item_source_plug_id=>wwv_flow_imp.id(7994388509929366683)
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7994394920347366688)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(7994394841665366688)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7994395715291366689)
,p_event_id=>wwv_flow_imp.id(7994394920347366688)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(7983422342724697730)
,p_name=>'When Address Confirmed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P11_GEOCODED_ADDRESS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_GEOCODED_ADDRESS|ITEM TYPE|apexgeocoderselection'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7983422385833697731)
,p_event_id=>wwv_flow_imp.id(7983422342724697730)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Set Longitude'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P11_LONGITUDE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.longitude'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(7983422492561697732)
,p_event_id=>wwv_flow_imp.id(7983422342724697730)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set Latitude'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P11_LATITUDE'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.data.latitude'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8833055740562825)
,p_name=>'When Trigger Geocoding Clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8832961564562824)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8833172495562826)
,p_event_id=>wwv_flow_imp.id(8833055740562825)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_GEOCODING_TRIGGER'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P11_GEOCODED_ADDRESS'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7994397749316366690)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(7994388509929366683)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Venue'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>7985973805137430070
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7994398226796366691)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
,p_internal_uid=>7985974282617430071
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(8832057886562815)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Default Trip Info for Current Edition'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'for j in (select e.trip_id,t.country_code ',
'            from eba_demo_ann_editions e ',
'            left join eba_demo_ann_trips t on t.id = e.trip_id',
'           where e.id = :CURRENT_EDITION) loop',
'    if :P11_CODE is null then',
'        :P11_TRIP_ID := j.trip_id;',
'    end if;',
'    :P11_CURRENT_TRIP_COUNTRY_CODE := j.country_code;',
'end loop;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>8832057886562815
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7983423002631697737)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Duplicating a Venue...'
,p_attribute_01=>'N'
,p_process_when=>'DUPLICATE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
,p_internal_uid=>7974999058452761117
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7983423099957697738)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Else...'
,p_attribute_01=>'N'
,p_process_when=>'DUPLICATE'
,p_process_when_type=>'REQUEST_NOT_EQUAL_CONDITION'
,p_internal_uid=>7974999155778761118
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7983423262217697740)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(7983423002631697737)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Log Debug Message'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_debug.enter(''If Duplicating a Venue...'',',
'    ''P11_LONGITUDE'',:P11_LONGITUDE,',
'    ''P11_LATITUDE'',:P11_LATITUDE,',
'    ''P11_GEOCODED_ADDRESS'',:P11_GEOCODED_ADDRESS',
');'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>7974999318038761120
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7983423230696697739)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(7983423002631697737)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'GeoJSON from Long/Lat'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_DEMO_ANN_APP'
,p_attribute_04=>'GEOJSON_FOR_LAT_LONG'
,p_internal_uid=>7974999286517761119
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(7983423395310697741)
,p_page_process_id=>wwv_flow_imp.id(7983423230696697739)
,p_page_id=>11
,p_direction=>'OUT'
,p_data_type=>'VARCHAR2'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P11_GEOCODED_ADDRESS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(7983423488863697742)
,p_page_process_id=>wwv_flow_imp.id(7983423230696697739)
,p_page_id=>11
,p_name=>'p_latitude'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P11_LATITUDE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(7983423601585697743)
,p_page_process_id=>wwv_flow_imp.id(7983423230696697739)
,p_page_id=>11
,p_name=>'p_longitude'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P11_LONGITUDE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(7994397357104366690)
,p_process_sequence=>30
,p_region_id=>wwv_flow_imp.id(7994388509929366683)
,p_parent_process_id=>wwv_flow_imp.id(7983423099957697738)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Venue'
,p_internal_uid=>7985973412925430070
);
wwv_flow_imp.component_end;
end;
/
