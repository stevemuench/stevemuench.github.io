prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Calendar'
,p_alias=>'CALENDAR'
,p_step_title=>'Calendar'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>'apex.region("calendar").widget().data(''fullCalendar'').gotoDate($v(''P12_START_DATE''))'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'08'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20231008111137'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(8833263606562827)
,p_plug_name=>'Page Title'
,p_plug_display_sequence=>40
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'<span class="apex-logo-text"> -&nbsp; Calendar</span>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(20739519333115078)
,p_plug_name=>'Calendar'
,p_region_name=>'calendar'
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(5997710520316065523)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_ANN_EVENT_RUNS_V'
,p_query_where=>'edition_id = :CURRENT_EDITION and tickets=''Y'''
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ( pOptions) {',
'    pOptions.firstDay = $v(''P12_ZERO_BASED_FIRST_DAY'');                                    ',
'    return pOptions;',
'}',
''))
,p_attribute_01=>'STARTS_AT'
,p_attribute_02=>'ENDS_AT'
,p_attribute_03=>'NAME'
,p_attribute_04=>'ID'
,p_attribute_07=>'N'
,p_attribute_11=>'week:day:navigation'
,p_attribute_13=>'Y'
,p_attribute_17=>'Y'
,p_attribute_18=>'00'
,p_attribute_19=>'Y'
,p_attribute_20=>'9'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20172105710148754)
,p_name=>'P12_START_DATE'
,p_item_sequence=>20
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20172258872148756)
,p_name=>'P12_ZERO_BASED_FIRST_DAY'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(20172224398148755)
,p_computation_sequence=>10
,p_computation_item=>'P12_START_DATE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(first_day,''YYYY-MM-DD'')',
'from eba_demo_ann_editions',
'where id = :CURRENT_EDITION'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(20172420226148757)
,p_computation_sequence=>20
,p_computation_item=>'P12_ZERO_BASED_FIRST_DAY'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_number(to_char(first_day,''D''))-1',
'from eba_demo_ann_editions',
'where id = :CURRENT_EDITION'))
);
wwv_flow_imp.component_end;
end;
/
