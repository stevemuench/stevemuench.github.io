prompt --application/pages/page_00014
begin
--   Manifest
--     PAGE: 00014
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>14
,p_name=>'Schedule'
,p_alias=>'SCHEDULE'
,p_step_title=>'Schedule'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function extractNumberFromUnderscoreString(str) {',
'  const regex = /_(\d+)$/;',
'  const match = str.match(regex);',
'  if (match) {',
'    return parseInt(match[1]);',
'  }',
'  return null; // Return null if no match is found',
'}',
'',
'function eventRunIdForClickedGanttBar(p_this) {',
'  return extractNumberFromUnderscoreString($(p_this).parent()[0].id);',
'}'))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.tickets {',
'   fill: blue;',
'}',
'',
'.starred {',
'   fill: yellow;',
'}',
'',
'.vertical-stretch {',
'    height: calc(100vh - 17rem);',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20231007135852'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17054053730234714679)
,p_plug_name=>'Schedule'
,p_region_name=>'schedule'
,p_region_css_classes=>'vertical-stretch'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(5997710520316065523)
,p_plug_display_sequence=>40
,p_plug_source_type=>'NATIVE_JET_CHART'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(17054054048948714679)
,p_region_id=>wwv_flow_imp.id(17054053730234714679)
,p_chart_type=>'gantt'
,p_animation_on_display=>'none'
,p_animation_on_data_change=>'none'
,p_stack=>'off'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>false
,p_show_baseline=>false
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_row_axis_rendered=>'off'
,p_gantt_axis_position=>'top'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'function( options ) {',
'    options.dragMode = "select";',
'    options.axisDefaults = {',
'        taskLabel: {',
'            rendered: "off"',
'        }',
'    };',
'',
'    return options;',
'}'))
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(17054055799530714680)
,p_chart_id=>wwv_flow_imp.id(17054054048948714679)
,p_seq=>10
,p_name=>'Schedule'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r.id,',
'       r.event_day,',
'        case when :day_start_time is not null then',
'          to_date(to_char(r.day_start,''YYYY-MM-DD'')||'' ''||:day_start_time,''YYYY-MM-DD HH24:MI'')',
'          else r.day_start',
'        end day_start,',
'        case when :day_end_time is not null then',
'          to_date(to_char(r.day_end,''YYYY-MM-DD'')||'' ''||:day_end_time,''YYYY-MM-DD HH24:MI'')',
'          else r.day_end',
'        end day_end,',
'       r.name||case when r.venue is not null then '' (''||v.description||'')'' end as name,',
'       r.venue,',
'       r.starts_at,',
'       r.ends_at,',
'       case ',
'          when r.tickets = ''Y'' then ''tickets''',
'          when r.event_starred = ''Y'' or r.event_run_starred = ''Y'' then ''starred''',
'       end as css_classes',
'  from            eba_demo_ann_event_runs_v r',
'  left outer join eba_demo_ann_venues       v on v.code = r.venue',
'  left       join eba_demo_ann_events       e on e.id   = r.event_id',
' where r.event_day = :p14_day',
' and   e.edition   = :current_edition',
' and (',
'       :p14_hide_starred_session_clashes = ''N'' ',
'       or',
'       (',
'           :p14_hide_starred_session_clashes = ''Y'' and',
'           (',
'               (r.event_starred=''Y'' or r.event_run_starred=''Y'')',
'               or',
'               (',
'                   r.event_starred=''N'' ',
'                   and',
'                    not exists (',
'                       select 1',
'                         from eba_demo_ann_event_runs_v starred_run',
'                         where (starred_run.event_starred=''Y'' or starred_run.event_run_starred=''Y'')',
'                         and (',
'                              (',
'                               /* starred_run starts before and ends after current_run */',
'                               starred_run.starts_at < r.starts_at and starred_run.ends_at > r.ends_at',
'                              )',
'                              or',
'                              (',
'                               /* starred_run starts after and ends before current_run */',
'                               starred_run.starts_at > r.starts_at and starred_run.starts_at < r.ends_at',
'                              )',
'                              or',
'                              (',
'                               /* starred_run ends after current_run starts and before current_run ends */',
'                               r.starts_at <= starred_run.ends_at and starred_run.ends_at <= r.ends_at',
'                              )',
'                              or',
'                              (',
'                               /* starred_run starts after current_run starts and before current_run ends */',
'                               r.starts_at <= starred_run.starts_at and starred_run.starts_at <= r.ends_at',
'                              )',
'                         )',
'                    )',
'               )',
'           )',
'       )',
'     )',
'and (',
'       nvl(:p14_hide_ticketed_from_other_days,''N'') = ''N'' ',
'       or',
'       (',
'           nvl(:p14_hide_ticketed_from_other_days,''N'') = ''Y'' and event_id not in ( select distinct event_id from eba_demo_ann_event_runs_v where tickets=''Y'' and event_day !=  :p14_day)',
'       )',
'     )',
'order by r.starts_at'))
,p_ajax_items_to_submit=>'P14_DAY,P14_HIDE_STARRED_SESSION_CLASHES,P14_HIDE_TICKETED_FROM_OTHER_DAYS'
,p_items_label_rendered=>true
,p_items_label_display_as=>'PERCENT'
,p_gantt_start_date_source=>'DB_COLUMN'
,p_gantt_start_date_column=>'DAY_START'
,p_gantt_end_date_source=>'DB_COLUMN'
,p_gantt_end_date_column=>'DAY_END'
,p_gantt_task_id=>'ID'
,p_gantt_task_name=>'NAME'
,p_gantt_task_start_date=>'STARTS_AT'
,p_gantt_task_end_date=>'ENDS_AT'
,p_gantt_task_css_class=>'&CSS_CLASSES.'
,p_gantt_viewport_start_source=>'DB_COLUMN'
,p_gantt_viewport_start_column=>'DAY_START'
,p_gantt_viewport_end_source=>'DB_COLUMN'
,p_gantt_viewport_end_column=>'DAY_END'
,p_task_label_position=>'end'
,p_threshold_display=>'onIndicator'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17054054556525714680)
,p_chart_id=>wwv_flow_imp.id(17054054048948714679)
,p_axis=>'major'
,p_is_rendered=>'on'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'hours'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>true
,p_zoom_order_hours=>true
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(17054055174634714680)
,p_chart_id=>wwv_flow_imp.id(17054054048948714679)
,p_axis=>'minor'
,p_format_type=>'decimal'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'auto'
,p_minor_tick_rendered=>'auto'
,p_tick_label_rendered=>'on'
,p_axis_scale=>'minutes'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>true
,p_zoom_order_hours=>true
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17054240233877203126)
,p_plug_name=>'Schedule Title'
,p_plug_display_sequence=>30
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'<span class="apex-logo-text"> -&nbsp; Schedule</span>'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(17302148178325629028)
,p_branch_name=>'Go Edit Event Run'
,p_branch_action=>'f?p=&APP_ID.:7:&SESSION.::&DEBUG.::P7_EVENT_RUN_ID,P7_CALLING_PAGE_ID:&P14_SELECTED_EVENT_RUN_ID.,\14\&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'REQUEST_EQUALS_CONDITION'
,p_branch_condition=>'EDIT_EVENT_RUN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(20171750909148751)
,p_name=>'P14_HIDE_TICKETED_FROM_OTHER_DAYS'
,p_item_sequence=>30
,p_item_default=>'N'
,p_prompt=>'Hide Already Ticketed Events'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(5997847870575065585)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17054239687827203121)
,p_name=>'P14_DAY'
,p_item_sequence=>10
,p_item_default=>'1'
,p_prompt=>'Day'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'EVENT_DAYS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'  to_char(FIRST_DAY + LEVEL - 1,''fmDy DD Mon'') AS DAY_NAME_IN_PERIOD,',
'  LEVEL AS DAY_NUMBER',
'FROM',
'  (SELECT FIRST_DAY, LAST_DAY FROM EBA_DEMO_ANN_EDITIONS WHERE ID = :CURRENT_EDITION)',
'CONNECT BY',
'  FIRST_DAY + LEVEL - 1 <= LAST_DAY',
'ORDER BY',
'  DAY_NUMBER ASC',
''))
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(5997847870575065585)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17054240317916203127)
,p_name=>'P14_HIDE_STARRED_SESSION_CLASHES'
,p_item_sequence=>20
,p_item_default=>'N'
,p_prompt=>'Hide Starred Session Clashes'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(5997847870575065585)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(17302147624200629022)
,p_name=>'P14_SELECTED_EVENT_RUN_ID'
,p_item_sequence=>50
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17054239777923203122)
,p_name=>'On Change Day'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_DAY'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17054239914185203123)
,p_event_id=>wwv_flow_imp.id(17054239777923203122)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Gantt'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17054053730234714679)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17054240563265203130)
,p_name=>'On Change Hide Sessions Flag'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_HIDE_STARRED_SESSION_CLASHES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17054240719456203131)
,p_event_id=>wwv_flow_imp.id(17054240563265203130)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17054053730234714679)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17302147670781629023)
,p_name=>'On Gantt Task Clicked'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.oj-gantt-task'
,p_bind_type=>'live'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(17302147778053629024)
,p_event_id=>wwv_flow_imp.id(17302147670781629023)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Handle Event Run Click in Gantt'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'const lTaskId = eventRunIdForClickedGanttBar(this.triggeringElement);',
'// Set Task id to hidden page item and submit the page with EDIT_TASK request',
'apex.page.submit({',
'    request: "EDIT_EVENT_RUN",',
'    set: {',
'        "P14_SELECTED_EVENT_RUN_ID": lTaskId',
'    }',
'});'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(20171917600148752)
,p_name=>'On Change Hide Ticketed Flag'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P14_HIDE_TICKETED_FROM_OTHER_DAYS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(20171997568148753)
,p_event_id=>wwv_flow_imp.id(20171917600148752)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(17054053730234714679)
);
wwv_flow_imp.component_end;
end;
/
