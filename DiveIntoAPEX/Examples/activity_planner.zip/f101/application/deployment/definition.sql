prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(6032824668382041670)
,p_get_version_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name',
'from user_tables',
'where table_name = ''EBA_DEMO_ANN_EVENT_RUNS'''))
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- drop objects',
'drop table eba_demo_ann_trips cascade constraints;',
'drop table eba_demo_ann_editions cascade constraints;',
'drop table eba_demo_ann_event_types cascade constraints;',
'drop table eba_demo_ann_venues cascade constraints;',
'drop table eba_demo_ann_events cascade constraints;',
'drop table eba_demo_ann_event_runs cascade constraints;',
'drop table eba_demo_ann_languages cascade constraints;',
'drop table eba_demo_ann_countries cascade constraints;'))
);
wwv_flow_imp.component_end;
end;
/
