prompt --application/deployment/install/install_types
begin
--   Manifest
--     INSTALL: INSTALL-Types
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8540163517652767461)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'Types'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Generated on 05-MAY-2023 10:47:18 by Region Data Sharing Helper',
'declare',
'    object_does_not_exist exception;',
'    pragma exception_init(object_does_not_exist,-4043);',
'begin',
'  execute immediate ''drop type VENUES_tab'';',
'exception',
'    when object_does_not_exist then',
'        null;',
'end;',
'/        ',
'declare',
'    object_does_not_exist exception;',
'    pragma exception_init(object_does_not_exist,-4043);',
'begin',
'  execute immediate ''drop type VENUES_row'';',
'exception',
'    when object_does_not_exist then',
'        null;',
'end;',
'/        ',
'create or replace type VENUES_row as object',
'(',
'    description varchar2(400),',
'    code varchar2(16)',
')',
'/',
'create or replace type VENUES_tab as table',
'of VENUES_row',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
