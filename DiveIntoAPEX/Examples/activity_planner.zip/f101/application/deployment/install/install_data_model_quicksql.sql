prompt --application/deployment/install/install_data_model_quicksql
begin
--   Manifest
--     INSTALL: INSTALL-Data Model QuickSQL
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(6032672681514556944)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'Data Model QuickSQL'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_condition_type=>'NEVER'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'trips',
'    name',
'    country_code vc2',
'',
'editions',
'    trip_id /fk trips',
'    year vc4',
'    first_day date',
'    last_day date',
'',
'languages',
'    code vc2 /pk',
'    description vc100',
'',
'countries',
'    code vc3 /pk',
'    description vc100    ',
'',
'event_types',
'    code vc4 /pk',
'    description vc100',
'    prefix vc2',
'',
'venues',
'    trip_id /fk trips',
'    code vc4 /pk',
'    description vc100',
'    address vc255',
'    latitude num',
'    longitude num',
'',
'events',
'    name vc100',
'    type /fk event_types',
'    edition /fk editions',
'    language /fk languages',
'    starred vc1 /check Y,N /default N',
'    duration_min num',
'    country /fk countries',
'    url vc255',
'',
'event_runs',
'    event /fk events',
'    venue /fk venues',
'    event_day num',
'    starts_at vc5',
'    ends_at vc5',
'    language /fk languages',
'    subtitles /fk languages',
'    starred vc1 /check Y,N /default N',
'    tickets vc1 /check Y,N /default N',
'    priority num',
'',
'# settings = { prefix: "EBA_DEMO_ANN", semantics: "CHAR", auditCols: true, drop: true, language: "EN", APEX: true }'))
);
wwv_flow_imp.component_end;
end;
/
