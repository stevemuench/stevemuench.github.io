prompt --application/deployment/install/install_views
begin
--   Manifest
--     INSTALL: INSTALL-Views
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(17010331399118242140)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'Views'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'',
'  CREATE OR REPLACE FORCE EDITIONABLE VIEW "EBA_DEMO_ANN_EVENT_RUNS_V" ("ID", "EVENT_ID", "EVENT_DAY", "EVENT_STARRED", "EVENT_RUN_STARRED", "TICKETS", "DAY_START", "DAY_END", "NAME", "VENUE", "STARTS_AT", "ENDS_AT", "FIRST_DAY", "LAST_DAY", "YEAR", '
||'"EDITION_ID") DEFAULT COLLATION "USING_NLS_COMP"  AS ',
'  with e as (',
'  select er.id,',
'         ev.id as event_id,',
'         er.event_day,',
'         ev.starred as event_starred,',
'         er.starred as event_run_starred,',
'         er.tickets,',
'         ev.name,',
'         er.venue,',
'         to_date(to_char(ed.first_day+er.event_day-1,''YYYY-MM-DD'')||'' ''||er.starts_at,''YYYY-MM-DD HH24:MI'') as starts_at,',
'         to_date(to_char(ed.first_day+er.event_day-1,''YYYY-MM-DD'')||'' ''||er.ends_at,''YYYY-MM-DD HH24:MI'') as ends_at,',
'         ed.first_day,',
'         ed.last_day,',
'         ed.year,',
'         ed.id edition_id',
'',
'from      eba_demo_ann_event_runs er',
'left join eba_demo_ann_events     ev on er.event   = ev.id',
'left join eba_demo_ann_editions   ed on ev.edition = ed.id)',
'select e.id,',
'       e.event_id,',
'       e.event_day,',
'       e.event_starred,',
'       e.event_run_starred,',
'       e.tickets,',
'       min(trunc(e.starts_at,''hh'')) over (partition by e.event_day) as day_start,',
'       max(trunc(case when to_char(e.ends_at,''MI'')=''00'' then e.ends_at else e.ends_at + 1/24 end,''hh'')) over (partition by e.event_day) as day_end,',
'       e.name,',
'       e.venue, ',
'       e.starts_at, ',
'       e.ends_at,',
'       e.first_day,',
'       e.last_day,',
'       e.year,',
'       e.edition_id',
'from e;'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(17010331515820242143)
,p_script_id=>wwv_flow_imp.id(17010331399118242140)
,p_object_owner=>'#OWNER#'
,p_object_type=>'VIEW'
,p_object_name=>'EBA_DEMO_ANN_EVENT_RUNS_V'
,p_last_updated_by=>'STEVE.MUENCH@ME.COM'
,p_last_updated_on=>to_date('20230522110300','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE.MUENCH@ME.COM'
,p_created_on=>to_date('20230522110300','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
