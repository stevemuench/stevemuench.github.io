prompt --application/deployment/install/install_nyc_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-NYC Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8908605662856159)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'NYC Sample Data'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --EBA_DEMO_ANN_TRIPS: 1/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_TRIPS$332628',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_TRIPS'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_EDITIONS: 1/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_EDITIONS$917699',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_EDITIONS'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_COUNTRIES: 1/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_COUNTRIES$879110',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_COUNTRIES'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_EVENT_TYPES: 5/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_EVENT_TYPES$123625',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_EVENT_TYPES'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_LANGUAGES: 1/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_LANGUAGES$254557',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_LANGUAGES'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_VENUES: 16/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_VENUES$564745',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_VENUES'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_EVENTS: 12/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_EVENTS$177600',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_EVENTS'', p_delete_after_install => false );',
'    --EBA_DEMO_ANN_EVENT_RUNS: 56/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_ANN_EVENT_RUNS$638816',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_ANN_EVENT_RUNS'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
