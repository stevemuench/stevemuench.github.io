prompt --application/deployment/install/install_datasharingfunction
begin
--   Manifest
--     INSTALL: INSTALL-DataSharingFunction
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8541768269172286721)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'DataSharingFunction'
,p_sequence=>6
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Generated on 05-MAY-2023 10:47:18 by Region Data Sharing Helper',
'create or replace function VENUES_data( p_page_id number := null)',
'return VENUES_tab pipelined',
'is',
'    l_ctx              apex_exec.t_context;',
'    l_page_id          number := coalesce(p_page_id,10);',
'    l_app_id           number := v(''APP_ID'');',
'    l_region_id        number;',
'    l_region_static_id varchar2(128) := ''VENUES'';',
'    l_idx              apex_application.num_assoc_arr;',
'    l_col_count        number;',
'begin',
'    begin',
'        -- Lookup region internal id',
'        select region_id',
'          into l_region_id',
'          from apex_application_page_regions',
'         where application_id = l_app_id',
'           and page_id        = l_page_id',
'           and static_id      = l_region_static_id;',
'    exception',
'        when no_data_found then',
'            return;',
'    end;',
'    -- open an apex_exec "cursor" on the region''s data',
'    l_ctx := apex_region.open_query_context(',
'                 p_page_id   => l_page_id,',
'                 p_region_id => l_region_id );',
'    -- Compute column indexes',
'    l_col_count := apex_exec.get_column_count(l_ctx);',
'    for j in 1..l_col_count loop',
'        l_idx(apex_exec.get_column(l_ctx,j).name) := j;',
'    end loop;',
'    -- Fetch and pipe the data from the region row by row    ',
'    while apex_exec.next_row(p_context => l_ctx) loop',
'        pipe row (',
'            VENUES_row(',
'                 case when l_idx.exists(''DESCRIPTION'') then apex_exec.get_varchar2(l_ctx,l_idx(''DESCRIPTION'')) end,',
'                 case when l_idx.exists(''CODE'') then apex_exec.get_varchar2(l_ctx,l_idx(''CODE'')) end',
'            )',
'        );',
'    end loop;',
'    apex_exec.close(l_ctx);',
'exception',
'    when no_data_needed then',
'        apex_exec.close(l_ctx);',
'        return;',
'    when others then',
'        apex_debug.info(dbms_utility.format_error_stack()',
'                         || chr(10)',
'                         || dbms_utility.format_error_backtrace());',
'        apex_exec.close(l_ctx);',
'        raise;',
'        return;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
