prompt --application/deployment/install/install_advance_identity_sequences
begin
--   Manifest
--     INSTALL: INSTALL-Advance Identity Sequences
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(8442123899157401)
,p_install_id=>wwv_flow_imp.id(6032824668382041670)
,p_name=>'Advance Identity Sequences'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_max_id number;',
'    l_seqname varchar2(100);',
'    l_pk_col varchar2(30);',
'    l_next_val number;',
'begin',
'    for t in (select table_name',
'                from user_tables',
'               where table_name in (''EBA_DEMO_ANN_TRIPS'',',
'                                    ''EBA_DEMO_ANN_EDITIONS'',',
'                                    ''EBA_DEMO_ANN_EVENTS'',',
'                                    ''EBA_DEMO_ANN_EVENT_RUNS'')) loop',
'        l_max_id := null;',
'        l_next_val := null;',
'        select lower(cols.column_name)',
'        into l_pk_col',
'        from user_cons_columns cols',
'        left outer join user_constraints cons',
'          on cons.constraint_name = cols.constraint_name',
'         and cons.constraint_type = ''P''',
'        where cons.table_name = upper(t.table_name)',
'        order by cols.table_name, cols.position',
'        fetch first row only;',
'        execute immediate ''select max(''||l_pk_col||'') from ''||t.table_name',
'        into l_max_id;',
'        if l_max_id is not null then',
'            select data_default',
'            into l_seqname',
'            from user_tab_columns',
'            where table_name = upper(t.table_name)',
'            and column_name = upper(l_pk_col);',
'            while nvl(l_next_val,0) < l_max_id loop',
'                execute immediate ''select ''||l_seqname||'' from sys.dual''',
'                into l_next_val;',
'            end loop;',
'        end if;',
'   end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
