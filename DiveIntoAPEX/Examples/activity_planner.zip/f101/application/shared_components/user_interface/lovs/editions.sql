prompt --application/shared_components/user_interface/lovs/editions
begin
--   Manifest
--     EDITIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(12461048481535986574)
,p_lov_name=>'EDITIONS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select e.id, t.name||'' ''||e.year edition_name',
'from eba_demo_ann_editions e',
'left join eba_demo_ann_trips t on t.id = e.trip_id'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'EBA_DEMO_ANN_EDITIONS'
,p_return_column_name=>'ID'
,p_display_column_name=>'EDITION_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
