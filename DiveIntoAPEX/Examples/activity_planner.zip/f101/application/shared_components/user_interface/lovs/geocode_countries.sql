prompt --application/shared_components/user_interface/lovs/geocode_countries
begin
--   Manifest
--     GEOCODE_COUNTRIES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9050567541404765)
,p_lov_name=>'GEOCODE_COUNTRIES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select r, d',
'from (',
'select REGEXP_SUBSTR(column_value,''[^:]+'',1,1) r,',
'       REGEXP_SUBSTR(column_value,''[^:]+'',1,2) d ',
'from table(apex_string.split(''US:United States;UK:United Kingdom;DE:Germany;FR:France;IT:Italy;CA:Canada;NL:Netherlands;BE:Belgium;AT:Austria;CH:Switzerland;ES:Spain;PT:Portugal;RU:Russian Federation;EE:Estonia;IN:India;MX:Mexico;AU:Australia;BR:Braz'
||'il;CL:Chile;CZ:Czech Republic;NO:Norway;FI:Finland;DK:Denmark;HK:Hong Kong;IE:Ireland;LV:Latvia;RO:Romania;CO:Colombia;PL:Poland;AE:United Arab Emirates;HU:Hungary;SA:Saudi Arabia;ZA:South Africa'','';''))',
') order by d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
);
wwv_flow_imp.component_end;
end;
/
