prompt --application/shared_components/user_interface/lovs/event_days
begin
--   Manifest
--     EVENT_DAYS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(12505108965287182606)
,p_lov_name=>'EVENT_DAYS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'  to_char(FIRST_DAY + LEVEL - 1,''fmDy DD Mon'') AS DAY_NAME_IN_PERIOD,',
'  LEVEL AS DAY_NUMBER',
'FROM',
'  (SELECT FIRST_DAY, LAST_DAY FROM EBA_DEMO_ANN_EDITIONS WHERE ID = :CURRENT_EDITION)',
'CONNECT BY',
'  FIRST_DAY + LEVEL - 1 <= LAST_DAY',
'ORDER BY',
'  DAY_NUMBER ASC',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_return_column_name=>'DAY_NUMBER'
,p_display_column_name=>'DAY_NAME_IN_PERIOD'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
