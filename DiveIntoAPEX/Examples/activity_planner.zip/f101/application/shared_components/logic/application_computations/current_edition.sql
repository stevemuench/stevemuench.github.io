prompt --application/shared_components/logic/application_computations/current_edition
begin
--   Manifest
--     APPLICATION COMPUTATION: CURRENT_EDITION
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(12504781042186175017)
,p_computation_sequence=>5
,p_computation_item=>'CURRENT_EDITION'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'QUERY'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id from eba_demo_ann_editions',
'order by created desc',
'fetch first row only'))
,p_compute_when=>'apex_util.get_preference(''CURRENT_EDITION'') is null'
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
);
wwv_flow_imp.component_end;
end;
/
