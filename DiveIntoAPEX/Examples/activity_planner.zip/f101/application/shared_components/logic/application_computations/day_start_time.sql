prompt --application/shared_components/logic/application_computations/day_start_time
begin
--   Manifest
--     APPLICATION COMPUTATION: DAY_START_TIME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_flow_computation(
 p_id=>wwv_flow_imp.id(8436446910063720)
,p_computation_sequence=>5
,p_computation_item=>'DAY_START_TIME'
,p_computation_point=>'AFTER_LOGIN'
,p_computation_type=>'STATIC_ASSIGNMENT'
,p_computation_processed=>'REPLACE_EXISTING'
,p_computation=>'09:00'
,p_compute_when=>'apex_util.get_preference(''DAY_START_TIME'') is null'
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
);
wwv_flow_imp.component_end;
end;
/
