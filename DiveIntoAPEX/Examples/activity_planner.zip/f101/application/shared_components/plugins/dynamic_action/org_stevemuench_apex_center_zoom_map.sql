prompt --application/shared_components/plugins/dynamic_action/org_stevemuench_apex_center_zoom_map
begin
--   Manifest
--     PLUGIN: ORG.STEVEMUENCH.APEX.CENTER_ZOOM_MAP
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(70935798472418905168)
,p_plugin_type=>'DYNAMIC ACTION'
,p_name=>'ORG.STEVEMUENCH.APEX.CENTER_ZOOM_MAP'
,p_display_name=>'Center & Zoom Map Around Points'
,p_category=>'COMPONENT'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('DYNAMIC ACTION','ORG.STEVEMUENCH.APEX.CENTER_ZOOM_MAP'),'')
,p_javascript_file_urls=>'#PLUGIN_FILES#centerZoomMap#MIN#.js'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function render (',
'    p_dynamic_action in apex_plugin.t_dynamic_action,',
'    p_plugin         in apex_plugin.t_plugin )',
'    return apex_plugin.t_dynamic_action_render_result is',
'    l_result apex_plugin.t_dynamic_action_render_result;',
'begin',
'    l_result.javascript_function := ''centerZoomMap'';',
'    return l_result;',
'end;'))
,p_api_version=>2
,p_render_function=>'render'
,p_standard_attributes=>'REGION:REQUIRED'
,p_substitute_attributes=>true
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>7
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2F2F2063656E7465725A6F6F6D4D61702E6A73202D2046696E616C2076657273696F6E0A77696E646F772E63656E7465725A6F6F6D4D6170203D2066756E6374696F6E2829207B0A202020202F2F20456E73757265206465762D636F6E66696775726564';
wwv_flow_imp.g_varchar2_table(2) := '20616666656374656420656C656D656E7420686173206120737461746963206964200A20202020636F6E7374206964203D20746869732E6166666563746564456C656D656E74732E6174747228202269642220293B0A2020202069662028202169642029';
wwv_flow_imp.g_varchar2_table(3) := '207B0A20202020202020207468726F77206E6577204572726F72282022416666656374656420526567696F6E206D757374206861766520616E2049442220293B0A202020207D0A202020202F2F205573652073746174696320696420746F20656E737572';
wwv_flow_imp.g_varchar2_table(4) := '65206465762063686F73652061206D617020726567696F6E0A20202020636F6E737420726567696F6E203D20617065782E726567696F6E2820696420293B0A202020206966282021726567696F6E207C7C20726567696F6E2E7479706520213D3D202253';
wwv_flow_imp.g_varchar2_table(5) := '70617469616C4D6170222029207B0A20202020202020207468726F77206E6577204572726F72282022416666656374656420526567696F6E206D7573742062652061204D61702220293B0A202020207D0A202020202F2F20446566696E6520626F756E64';
wwv_flow_imp.g_varchar2_table(6) := '73207573696E6720726566726573686564206D617020626F756E64696E6720626F7820636F6F7264696E617465730A202020206C65742062626F78203D20726567696F6E2E6D6170446174612E6D61702E62626F782C0A2020202020202020626F756E64';
wwv_flow_imp.g_varchar2_table(7) := '73203D205B0A2020202020202020202020205B62626F785B305D2C2062626F785B315D5D2C0A2020202020202020202020205B62626F785B325D2C2062626F785B335D5D0A20202020202020205D3B0A202020202F2F2046697420746865206D61702074';
wwv_flow_imp.g_varchar2_table(8) := '6F20746865206E657720626F756E64730A20202020726567696F6E2E6765744D61704F626A65637428292E666974426F756E647328626F756E64732C207B70616464696E673A2033307D293B0A7D3B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(70935194711917283045)
,p_plugin_id=>wwv_flow_imp.id(70935798472418905168)
,p_file_name=>'centerZoomMap.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '77696E646F772E63656E7465725A6F6F6D4D61703D66756E6374696F6E28297B636F6E737420653D746869732E6166666563746564456C656D656E74732E617474722822696422293B6966282165297468726F77206E6577204572726F72282241666665';
wwv_flow_imp.g_varchar2_table(2) := '6374656420526567696F6E206D757374206861766520616E20494422293B636F6E737420743D617065782E726567696F6E2865293B69662821747C7C225370617469616C4D617022213D3D742E74797065297468726F77206E6577204572726F72282241';
wwv_flow_imp.g_varchar2_table(3) := '6666656374656420526567696F6E206D7573742062652061204D617022293B6C657420613D742E6D6170446174612E6D61702E62626F782C6E3D5B5B615B305D2C615B315D5D2C5B615B325D2C615B335D5D5D3B742E6765744D61704F626A6563742829';
wwv_flow_imp.g_varchar2_table(4) := '2E666974426F756E6473286E2C7B70616464696E673A33307D297D3B';
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>123456789123456789123456789
,p_default_application_id=>101
,p_default_id_offset=>8423944178936620
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(71376278908179638977)
,p_plugin_id=>wwv_flow_imp.id(70935798472418905168)
,p_file_name=>'centerZoomMap.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
