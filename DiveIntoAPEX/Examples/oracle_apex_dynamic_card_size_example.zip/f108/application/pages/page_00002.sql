prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>19404766370905118
,p_default_application_id=>108
,p_default_id_offset=>0
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(21352642953126776)
,p_name=>'Books'
,p_alias=>'BOOKS'
,p_step_title=>'Books'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20211010222714'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(21365310579126995)
,p_plug_name=>'Books'
,p_region_name=>'BooksCardRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(21244796589126481)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BODY'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    b.title,',
'    b.year_published,',
'    b.isbn,',
'    p.name AS publisher_name,',
'    ''http://covers.openlibrary.org/b/isbn/''||b.isbn||''-L.jpg'' as image_url',
'FROM',
'    pnl_theroux_books b',
'    LEFT OUTER JOIN pnl_publishers p',
'                 ON b.publisher_id = p.id',
'WHERE',
'    b.open_library_image = ''Y''',
'ORDER BY',
'    year_published'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(21365846878126998)
,p_region_id=>wwv_flow_api.id(21365310579126995)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'PUBLISHER_NAME'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'YEAR_PUBLISHED'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'&IMAGE_URL.'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(21366300619127007)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(21272426096126529)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(21205417397126362)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(21329569891126684)
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(21372628869274501)
,p_name=>'P2_CARD_SIZE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(21366300619127007)
,p_prompt=>'Card Size'
,p_source=>'220px'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC2:Small;180px,Medium;220px,Large;300px'
,p_cHeight=>1
,p_field_template=>wwv_flow_api.id(21325317261126659)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'U'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(21373085932274505)
,p_name=>'SizeChanged'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_CARD_SIZE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(21373177613274506)
,p_event_id=>wwv_flow_api.id(21373085932274505)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#BooksCardRegion'').css(''--a-cv-item-width'', $v(''P2_CARD_SIZE''));'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(21373710934274512)
,p_event_id=>wwv_flow_api.id(21373085932274505)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- just send the value to the server',
'null;'))
,p_attribute_02=>'P2_CARD_SIZE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
