prompt --application/deployment/install/install_inserttwosampleannouncements
begin
--   Manifest
--     INSTALL: INSTALL-InsertTwoSampleAnnouncements
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12997637013168966)
,p_install_id=>wwv_flow_imp.id(12917137605605431)
,p_name=>'InsertTwoSampleAnnouncements'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_demo_announcements(title,text,display_from,display_to)',
'values(''Yard Sale'',',
'       ''There will be a yard sale going on all week in the parking lot.'',',
'       trunc(next_day(sysdate,''MON'')),',
'       trunc(next_day(sysdate,''MON''))+5);',
'insert into eba_demo_announcements(title,text,display_from,display_to)',
'values(''Blood Donation'',',
'       ''Come donate blood if you can in the tent in front of the entrance.'',',
'       trunc(next_day(sysdate,''WED'')),',
'       trunc(next_day(sysdate,''MON''))+2);',
'commit;'))
);
wwv_flow_imp.component_end;
end;
/
