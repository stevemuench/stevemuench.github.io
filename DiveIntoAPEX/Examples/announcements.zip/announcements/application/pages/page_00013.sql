prompt --application/pages/page_00013
begin
--   Manifest
--     PAGE: 00013
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_page.create_page(
 p_id=>13
,p_name=>'Delivery Date Example'
,p_alias=>'DELIVERY-DATE-EXAMPLE'
,p_step_title=>'Delivery Date Example'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Assign a dayFormatter function to P13_DELIVERY_DATE date picker',
'apex.items.P13_DELIVERY_DATE.dayFormatter = function (pCurrentDate) {',
'   // Parse the current day''s date using ISO8860 format mask',
'   const curDate = apex.date.parse(pCurrentDate,"YYYY-MM-DD");',
'   const dayOfWeek = curDate.getDay();',
'   const isWeekend = (dayOfWeek == 6 /* Sat */ || dayOfWeek == 0 /* Sun */);',
'   return {',
'      disabled: isWeekend,',
'      class:    null,            /* no day formatting class              */',
'      tooltip:  isWeekend ? null /* no tooltip for weekend, otherwise... */',
'                          : "Choose a delivery date"',
'   };',
'};',
'// Refresh the page item to engage the new day formatter',
'apex.items.P13_DELIVERY_DATE.refresh();',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230130100349'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(14364326251505315)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12815971851442410)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(12700829604442359)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(12878010277442441)
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13244884269633625)
,p_name=>'P13_DELIVERY_DATE'
,p_item_sequence=>10
,p_prompt=>'Delivery Date'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp.component_end;
end;
/
