prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Announcement'
,p_alias=>'ANNOUNCEMENT'
,p_page_mode=>'MODAL'
,p_step_title=>'Announcement'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.bold-and-red {',
'}',
'.bold-and-red > span { ',
'  font-weight: 900 !important;',
'  color: var(--ut-palette-danger) !important;',
'}'))
,p_step_template=>wwv_flow_imp.id(12701670505442360)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_width=>'1000'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230130105028'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12919277547636356)
,p_plug_name=>'Announcement'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12737555939442378)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_ANNOUNCEMENTS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12925839798636363)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12740323762442379)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12926238625636363)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(12925839798636363)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12876458958442440)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12927689600636365)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(12925839798636363)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12876458958442440)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12928097087636365)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(12925839798636363)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12876458958442440)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(12928402386636365)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(12925839798636363)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(12876458958442440)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12919520980636356)
,p_name=>'P3_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12919953905636358)
,p_name=>'P3_DISPLAY_FROM'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_default=>'P3_CURRENT_DATE'
,p_item_default_type=>'ITEM'
,p_prompt=>'Display Starting On'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'DISPLAY_FROM'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P3_MINIMUM_DISPLAY_FROM_DATE'
,p_attribute_06=>'ITEM'
,p_attribute_08=>'P3_DISPLAY_TO'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'SELECTABLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12920340175636359)
,p_name=>'P3_DISPLAY_TO'
,p_source_data_type=>'DATE'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_default=>'to_char(to_date(:P3_DISPLAY_FROM,''DD-MON-YYYY'')+7,''DD-MON-YYYY'')'
,p_item_default_type=>'EXPRESSION'
,p_item_default_language=>'PLSQL'
,p_prompt=>'Display Until'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'DISPLAY_TO'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'ITEM'
,p_attribute_05=>'P3_DISPLAY_FROM'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER'
,p_attribute_13=>'SELECTABLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12920771939636359)
,p_name=>'P3_TEXT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Text'
,p_source=>'TEXT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_RICH_TEXT_EDITOR'
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'HTML'
,p_attribute_02=>'INTERMEDIATE'
,p_attribute_03=>'OVERFLOW'
,p_attribute_04=>'180'
,p_attribute_07=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12921140666636359)
,p_name=>'P3_PURGE_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Purge Date'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'PURGE_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER'
,p_attribute_13=>'SELECTABLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12921532822636360)
,p_name=>'P3_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Created'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P3_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(12875273940442438)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12921913246636360)
,p_name=>'P3_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Created By'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P3_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(12875273940442438)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12922303747636360)
,p_name=>'P3_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Updated'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P3_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(12875273940442438)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12922752013636360)
,p_name=>'P3_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Updated By'
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P3_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(12875273940442438)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12940443235649713)
,p_name=>'P3_CURRENT_DATE'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_format_mask=>'DD-MON-YYYY HH24:MI'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12940781910649716)
,p_name=>'P3_TITLE'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_item_source_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_prompt=>'Title'
,p_source=>'TITLE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12941157558649720)
,p_name=>'P3_MINIMUM_DISPLAY_FROM_DATE'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(12919277547636356)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(12941282138649721)
,p_computation_sequence=>20
,p_computation_item=>'P3_MINIMUM_DISPLAY_FROM_DATE'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(',
'            least(',
'             nvl(to_date(:P3_DISPLAY_FROM,''DD-MON-YYYY''),',
'                 to_date(''31-DEC-9999'',''DD-MON-YYYY'')),',
'                   trunc( sysdate, ''HH'' )',
'                   + round( extract( minute from cast( sysdate as timestamp ) ) / 15 )',
'                     * interval ''15'' minute',
'',
'            ),',
'            ''DD-MON-YYYY''',
'        ) as x',
'from dual'))
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(12941081854649719)
,p_computation_sequence=>10
,p_computation_item=>'P3_CURRENT_DATE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select to_char(sysdate,''DD-MON-YYYY'')',
'from dual'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12926386983636363)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(12926238625636363)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12927160525636364)
,p_event_id=>wwv_flow_imp.id(12926386983636363)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12939273443649701)
,p_name=>'When From Date Changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_DISPLAY_FROM'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12939361689649702)
,p_event_id=>wwv_flow_imp.id(12939273443649701)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh To Date Item'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_DISPLAY_TO'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12939473436649703)
,p_name=>'When To Date Changed'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_DISPLAY_TO'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12939545132649704)
,p_event_id=>wwv_flow_imp.id(12939473436649703)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh From Date Item'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_DISPLAY_FROM'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12939645216649705)
,p_name=>'On Page Load'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12939798599649706)
,p_event_id=>wwv_flow_imp.id(12939645216649705)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Style Last Day of This and Next Two Months'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P3_PURGE_DATE'
,p_attribute_01=>'sql'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select /* last day of this month */',
'   trunc(last_day(sysdate))               as start_date,',
'   trunc(last_day(sysdate))               as end_date,',
'   ''bold-and-red''                         as css_class,',
'   ''Purge Day''                            as tooltip,',
'   0                                      as is_disabled',
'from dual',
'union all',
'select /* last day of next month */',
'   trunc(last_day(add_months(sysdate,1))) as start_date,',
'   trunc(last_day(add_months(sysdate,1))) as end_date,',
'   ''bold-and-red''                         as css_class,',
'   ''Purge Day''                            as tooltip,',
'   0                                      as is_disabled',
'from dual',
'union all',
'select /* last day of month after that */',
'   trunc(last_day(add_months(sysdate,2))) as start_date,',
'   trunc(last_day(add_months(sysdate,2))) as end_date,',
'   ''bold-and-red''                         as css_class,',
'   ''Purge Day''                            as tooltip,',
'   0                                      as is_disabled',
'from dual'))
,p_attribute_04=>'START_DATE'
,p_attribute_05=>'END_DATE'
,p_attribute_06=>'TOOLTIP'
,p_attribute_07=>'CSS_CLASS'
,p_attribute_08=>'IS_DISABLED'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12939821418649707)
,p_event_id=>wwv_flow_imp.id(12939645216649705)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'...and Enable ONLY Those Three Days'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Access the dayFormatter the Plug-in just assigned before this',
'const pluginFormatter = apex.items.P3_PURGE_DATE.dayFormatter;',
'',
'// Replace the date picker''s dayFormatter with my own',
'apex.items.P3_PURGE_DATE.dayFormatter = function (pDateISOString) {',
'',
'  // That first invokes original pluginFormatter to get its result object',
'  const plugInFormatterResult = pluginFormatter(pDateISOString);',
'',
'  // Then returns a result that defaults disabled to true for any',
'  return {',
'      // disable by default if not in plug-in formatter''s result object',
'      disabled: ''disabled'' in plugInFormatterResult ',
'                 ? plugInFormatterResult.disabled : true,',
'',
'      // return class if in plug-in formatter''s result object',
'      class: ''class'' in plugInFormatterResult ',
'              ? plugInFormatterResult.class : null,',
'',
'      // return tooltip if in the plug-in formatter''s result object',
'      tooltip: ''tooltip'' in plugInFormatterResult ',
'               ? plugInFormatterResult.tooltip : null',
'  };',
'};',
'apex.items.P3_PURGE_DATE.refresh();'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12929297531636366)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(12919277547636356)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Announcement'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12929603679636366)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12928863582636365)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(12919277547636356)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Announcement'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
