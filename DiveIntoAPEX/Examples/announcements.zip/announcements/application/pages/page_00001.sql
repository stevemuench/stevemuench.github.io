prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>110
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Announcements'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230125205343'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12912922123442469)
,p_plug_name=>'Preview Announcements'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12770582965442391)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12940094840649709)
,p_plug_name=>'Simulate Today''s Date'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12737555939442378)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_span=>4
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12939982042649708)
,p_plug_name=>'Announcements'
,p_parent_plug_id=>wwv_flow_imp.id(12940094840649709)
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(12744672410442380)
,p_plug_display_sequence=>20
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_ANNOUNCEMENTS'
,p_query_where=>'TO_DATE(:P1_SIMULATED_TODAY_DATE,''DD-MON-YYYY HH24:MI'') BETWEEN TRUNC(DISPLAY_FROM) and TRUNC(DISPLAY_TO)+1- INTERVAL ''1'' MINUTE'
,p_query_order_by_type=>'STATIC'
,p_query_order_by=>'display_from'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_ajax_items_to_submit=>'P1_SIMULATED_TODAY_DATE'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_no_data_found=>'No announcements for this date'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(12940271868649711)
,p_region_id=>wwv_flow_imp.id(12939982042649708)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>true
,p_body_html_expr=>'<div class="u-lineclamp-5">&TEXT!RAW.</div>'
,p_second_body_adv_formatting=>false
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(12941919573649728)
,p_card_id=>wwv_flow_imp.id(12940271868649711)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_ID:&ID.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12941352783649722)
,p_plug_name=>'Calendar'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(12803559239442405)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>8
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_ANNOUNCEMENTS'
,p_include_rowid_column=>false
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'DISPLAY_FROM'
,p_attribute_02=>'DISPLAY_TO'
,p_attribute_03=>'TITLE'
,p_attribute_04=>'ID'
,p_attribute_07=>'N'
,p_attribute_09=>'list:navigation'
,p_attribute_13=>'N'
,p_attribute_17=>'Y'
,p_attribute_19=>'Y'
,p_attribute_21=>'10'
,p_attribute_22=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12940168578649710)
,p_name=>'P1_SIMULATED_TODAY_DATE'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(12940094840649709)
,p_item_default=>'select to_char(sysdate,''DD-MON-YYYY'') from dual'
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Simulated Today Date'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(12873965875442437)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'2'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:NUMBER-OF-MONTH:TODAY-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_14=>'15'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(12941820545649727)
,p_name=>'P1_SELECTED_DATE_FROM_CALENDAR'
,p_item_sequence=>40
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12940509557649714)
,p_name=>'When Date Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_SIMULATED_TODAY_DATE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12940673864649715)
,p_event_id=>wwv_flow_imp.id(12940509557649714)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Announcements'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12939982042649708)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12941423568649723)
,p_name=>'When Date Selected'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12941352783649722)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_CSS_CALENDAR|REGION TYPE|apexcalendardateselect'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12941734804649726)
,p_event_id=>wwv_flow_imp.id(12941423568649723)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.items.P1_SELECTED_DATE_FROM_CALENDAR.value = this.data.newStartDate;'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12941546872649724)
,p_event_id=>wwv_flow_imp.id(12941423568649723)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_debug.info(''#### %s'',:P1_SELECTED_DATE_FROM_CALENDAR);',
':P1_SIMULATED_TODAY_DATE := to_char(to_date(:P1_SELECTED_DATE_FROM_CALENDAR, ''YYYYMMDDHH24MISS''),''DD-MON-YYYY'');'))
,p_attribute_02=>'P1_SELECTED_DATE_FROM_CALENDAR'
,p_attribute_03=>'P1_SIMULATED_TODAY_DATE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12941604111649725)
,p_event_id=>wwv_flow_imp.id(12941423568649723)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12939982042649708)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12942000535649729)
,p_name=>'When Dialog Closed'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(12939982042649708)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12942147807649730)
,p_event_id=>wwv_flow_imp.id(12942000535649729)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(12941352783649722)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(12942245977649731)
,p_name=>'On Page Load'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(12942313979649732)
,p_event_id=>wwv_flow_imp.id(12942245977649731)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_COM.ORACLE.APEX.FORMAT_DATEPICKER_DAYS'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_SIMULATED_TODAY_DATE'
,p_attribute_01=>'sql'
,p_attribute_03=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select',
'    display_from as start_date,',
'    display_from as end_date,',
'    ''u-color-37-text'' as css_class,',
'    null               as tooltip,',
'    0                  as is_disabled',
'from',
'    eba_demo_announcements',
''))
,p_attribute_04=>'START_DATE'
,p_attribute_05=>'END_DATE'
,p_attribute_06=>'TOOLTIP'
,p_attribute_07=>'CSS_CLASS'
,p_attribute_08=>'IS_DISABLED'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
