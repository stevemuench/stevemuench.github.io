prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.5'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>120725
,p_default_id_offset=>90101546807624544654
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.create_page(
 p_id=>2
,p_user_interface_id=>wwv_flow_api.id(90122899450577671430)
,p_name=>'Books'
,p_alias=>'BOOKS'
,p_step_title=>'Books'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
':root {',
'  --a-cv-item-width: 180px;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'STEVE.MUENCH@GMAIL.COM'
,p_last_upd_yyyymmddhh24miss=>'20220321092541'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(90122912118203671649)
,p_plug_name=>'Books'
,p_region_name=>'BooksCardRegion'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(90122791604213671135)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT',
'    b.title,',
'    b.year_published,',
'    b.isbn,',
'    p.name AS publisher_name,',
'    ''http://covers.openlibrary.org/b/isbn/''||b.isbn||''-L.jpg'' as image_url',
'FROM',
'    pnl_theroux_books b',
'    LEFT OUTER JOIN pnl_publishers p',
'                 ON b.publisher_id = p.id',
'WHERE',
'    b.open_library_image = ''Y''',
'ORDER BY',
'    year_published'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
,p_pagination_display_position=>'BOTTOM_RIGHT'
);
wwv_flow_api.create_card(
 p_id=>wwv_flow_api.id(90122912654502671652)
,p_region_id=>wwv_flow_api.id(90122912118203671649)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'PUBLISHER_NAME'
,p_second_body_adv_formatting=>false
,p_badge_column_name=>'YEAR_PUBLISHED'
,p_media_adv_formatting=>false
,p_media_source_type=>'STATIC_URL'
,p_media_url=>'&IMAGE_URL.'
,p_media_display_position=>'BODY'
,p_media_sizing=>'FIT'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(90122913108243671661)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_api.id(90122819233720671183)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_api.id(90122752225021671016)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_api.id(90122876377515671338)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(90122919893556819159)
,p_name=>'SizeChanged'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P2_CARD_SIZE'
,p_bind_type=>'bind'
,p_bind_event_type=>'change'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(90122919985237819160)
,p_event_id=>wwv_flow_api.id(90122919893556819159)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$(''#BooksCardRegion'').css(''--a-cv-item-width'', $v(''P2_CARD_SIZE''));'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(90122920518558819166)
,p_event_id=>wwv_flow_api.id(90122919893556819159)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- just send the value to the server',
'null;'))
,p_attribute_02=>'P2_CARD_SIZE'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.component_end;
end;
/
