prompt --application/shared_components/navigation/lists/byletter
begin
--   Manifest
--     LIST: ByLetter
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.5'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>120725
,p_default_id_offset=>90101546807624544654
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(49525316957192848684)
,p_name=>'ByLetter'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       null      c1_level,',
'       ''Letter ''||letter    c2_name_for_label,',
'       null      c3_url,',
'       null      c4_is_current,',
'       null      c5_icon_name,',
'       null      c6_icon_attrs,',
'       null      c7_icon_alt_text,',
'       letter_count as c8_count',
'from ( select upper(substr(title,1,1)) as letter, count(*) letter_count',
'         from pnl_theroux_books',
'         group by upper(substr(title,1,1))',
'    )',
'order by c8_count desc',
'fetch first 10 rows only'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
