prompt --application/shared_components/navigation/lists/bysales
begin
--   Manifest
--     LIST: BySales
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.5'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>120725
,p_default_id_offset=>90101546807624544654
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(49524971805220777884)
,p_name=>'BySales'
,p_list_type=>'SQL_QUERY'
,p_list_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from',
'  (select ',
'       null      c1_level,',
'       title     c2_name_for_label,',
'       null      c3_url,',
'       null      c4_is_current,',
'       null      c5_icon_name,',
'       null      c6_icon_attrs,',
'       null      c7_icon_alt_text,',
'       trunc(abs(dbms_random.normal)*1000) as c8_sales',
'from pnl_theroux_books',
')',
'order by c8_sales desc',
'fetch first 10 rows only'))
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
