prompt --application/deployment/install/install_installpackage
begin
--   Manifest
--     INSTALL: INSTALL-InstallPackage
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>1010101010101010101010101010101
,p_default_application_id=>867
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(892873409887914053)
,p_install_id=>wwv_flow_imp.id(892796745471070191)
,p_name=>'InstallPackage'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_demo_simplecalc as',
'    function compute(',
'        p_operand1  in number,',
'        p_operation in varchar2,',
'        p_operand2  in number)',
'        return         number;',
'    procedure update_result(',
'        p_calculation_id in number,',
'        p_result         in number);',
'    procedure del_calcs_with_no_workflow_ref(',
'        p_rows_deleted out number);',
'    function minutes_from_now(',
'        p_minutes in number)',
'        return       date;',
'end eba_demo_simplecalc;',
'/',
'create or replace package body eba_demo_simplecalc as',
'    function compute(',
'        p_operand1  in number,',
'        p_operation in varchar2,',
'        p_operand2  in number)',
'        return         number',
'    is',
'    begin',
'        return case p_operation',
'                    when ''+'' then p_operand1 + p_operand2',
'                    when ''-'' then p_operand1 - p_operand2',
'                    when ''*'' then p_operand1 * p_operand2',
'                    when ''/'' then p_operand1 / p_operand2',
'               end;',
'    end compute;',
'    --',
'    procedure update_result(',
'        p_calculation_id in number,',
'        p_result         in number)',
'    is',
'    begin',
'        update eba_demo_calculation',
'           set result = p_result',
'         where id = p_calculation_id;',
'    end update_result;',
'    --  ',
'    procedure del_calcs_with_no_workflow_ref(',
'        p_rows_deleted out number)',
'    is',
'        l_count number;',
'    begin',
'        select count(*)',
'          into l_count',
'          from eba_demo_calculation;',
'        delete from eba_demo_calculation',
'          where id not in (select detail_pk',
'                             from apex_workflows',
'                            where application_id = V(''APP_ID''));',
'        p_rows_deleted := sql%rowcount;',
'        if l_count > 0 and p_rows_deleted = 0 then',
'            apex_error.add_error (',
'                p_message          => ''All calculation rows are referenced by some workflow!'',',
'                p_display_location => apex_error.c_on_error_page);',
'        end if;                            ',
'    end  del_calcs_with_no_workflow_ref;',
'    --',
'    function minutes_from_now(',
'        p_minutes in number)',
'        return       date',
'    is',
'        c_minutes_in_one_day constant integer := 60 * 24;',
'    begin',
'        return sysdate + (p_minutes / c_minutes_in_one_day);',
'    end minutes_from_now;     ',
'end eba_demo_simplecalc;',
'/'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(892873573733914053)
,p_script_id=>wwv_flow_imp.id(892873409887914053)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_SIMPLECALC'
,p_last_updated_by=>'SMUENCH'
,p_last_updated_on=>to_date('20231031164214','YYYYMMDDHH24MISS')
,p_created_by=>'SMUENCH'
,p_created_on=>to_date('20231031164214','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
