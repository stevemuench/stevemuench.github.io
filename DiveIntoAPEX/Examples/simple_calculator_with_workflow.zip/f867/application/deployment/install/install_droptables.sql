prompt --application/deployment/install/install_droptables
begin
--   Manifest
--     INSTALL: INSTALL-DropTables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>1010101010101010101010101010101
,p_default_application_id=>867
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(959730947274809299)
,p_install_id=>wwv_flow_imp.id(892796745471070191)
,p_name=>'DropTables'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables_to_drop apex_t_varchar2 := apex_t_varchar2(''eba_demo_calculation'');',
'',
'begin',
'    for j in 1..l_tables_to_drop.count loop',
'        begin',
'            execute immediate apex_string.format(''drop table %s cascade constraints'',l_tables_to_drop(j));',
'        exception',
'            when others then',
'                if sqlcode != -942 then',
'                    raise;',
'                end if;',
'        end;',
'    end loop;',
'end;   ',
'/'))
);
wwv_flow_imp.component_end;
end;
/
