prompt --application/shared_components/workflow/workflows/simple_calc_using_process_plugin
begin
--   Manifest
--     WORKFLOW: Simple Calc Using Process Plugin
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>1010101010101010101010101010101
,p_default_application_id=>867
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_workflow(
 p_id=>wwv_flow_imp.id(937324490032966310)
,p_name=>'Simple Calc Using Process Plugin'
,p_static_id=>'SIMPLE_CALC_PROCESS_PLUGIN'
,p_title=>'Calculate &P_OPERAND1. &P_OPERATION. &P_OPERAND2. (Using Custom Activity)'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(937324584821966311)
,p_workflow_id=>wwv_flow_imp.id(937324490032966310)
,p_label=>'Operand 1'
,p_static_id=>'P_OPERAND1'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(937324670375966312)
,p_workflow_id=>wwv_flow_imp.id(937324490032966310)
,p_label=>'Operand 2'
,p_static_id=>'P_OPERAND2'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_is_required=>true
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(937324732388966313)
,p_workflow_id=>wwv_flow_imp.id(937324490032966310)
,p_label=>'Operation'
,p_static_id=>'P_OPERATION'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_value=>'Y'
);
wwv_flow_imp_shared.create_workflow_version(
 p_id=>wwv_flow_imp.id(937324975239966315)
,p_workflow_id=>wwv_flow_imp.id(937324490032966310)
,p_version=>'1.0'
,p_state=>'DEVELOPMENT'
);
wwv_flow_imp_shared.create_workflow_variable(
 p_id=>wwv_flow_imp.id(937325969953966325)
,p_workflow_version_id=>wwv_flow_imp.id(937324975239966315)
,p_label=>'Result'
,p_static_id=>'V_RESULT'
,p_direction=>'VARIABLE'
,p_data_type=>'NUMBER'
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(937325038202966316)
,p_workflow_version_id=>wwv_flow_imp.id(937324975239966315)
,p_name=>'Start'
,p_static_id=>'New'
,p_display_sequence=>10
,p_activity_type=>'NATIVE_WORKFLOW_START'
,p_diagram=>'{"position":{"x":700,"y":970},"z":1}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(937325228982966318)
,p_workflow_version_id=>wwv_flow_imp.id(937324975239966315)
,p_name=>'Calculate Result'
,p_static_id=>'Compute Result'
,p_display_sequence=>20
,p_activity_type=>'PLUGIN_COM_DIVEINTOAPEX_CALCULATOR'
,p_attribute_01=>'P_OPERAND1'
,p_attribute_02=>'P_OPERATION'
,p_attribute_03=>'P_OPERAND2'
,p_attribute_04=>'V_RESULT'
,p_diagram=>'{"position":{"x":890,"y":970},"z":2}'
);
wwv_flow_imp_shared.create_workflow_activity(
 p_id=>wwv_flow_imp.id(937325820565966324)
,p_workflow_version_id=>wwv_flow_imp.id(937324975239966315)
,p_name=>'End'
,p_static_id=>'New_2'
,p_display_sequence=>30
,p_activity_type=>'NATIVE_WORKFLOW_END'
,p_attribute_01=>'COMPLETED'
,p_diagram=>'{"position":{"x":1240,"y":970},"z":3}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(937325135008966317)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(937325038202966316)
,p_to_activity_id=>wwv_flow_imp.id(937325228982966318)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":4,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp_shared.create_workflow_transition(
 p_id=>wwv_flow_imp.id(937325348658966319)
,p_name=>'New'
,p_transition_type=>'NORMAL'
,p_from_activity_id=>wwv_flow_imp.id(937325228982966318)
,p_to_activity_id=>wwv_flow_imp.id(937325820565966324)
,p_diagram=>'{"source":{},"target":{},"vertices":[],"z":5,"label":{"distance":0.5,"offset":0}}'
);
wwv_flow_imp.component_end;
end;
/
