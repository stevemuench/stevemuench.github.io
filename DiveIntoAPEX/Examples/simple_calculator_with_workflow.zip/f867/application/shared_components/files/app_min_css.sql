prompt --application/shared_components/files/app_min_css
begin
--   Manifest
--     APP STATIC FILES: 867
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>1010101010101010101010101010101
,p_default_application_id=>867
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E6D61782D77696474682D6669656C647B6D61782D77696474683A3135656D3B6D696E2D77696474683A38656D7D2E6D61782D77696474682D726573756C747B6D61782D77696474683A3234656D3B6D696E2D77696474683A38656D7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(954010816448685596)
,p_file_name=>'app.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
