prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 867
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0-19'
,p_default_workspace_id=>1010101010101010101010101010101
,p_default_application_id=>867
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(892485772171031481)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
,p_version_scn=>37166384187691
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(899919795467632322)
,p_build_option_name=>'Feature: Push Notifications'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166391101150
,p_feature_identifier=>'APPLICATION_PUSH_NOTIFICATIONS'
,p_build_option_comment=>'Allow users to subscribe to push notifications on their devices.'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(899920079791632324)
,p_build_option_name=>'Feature: User Settings'
,p_build_option_status=>'INCLUDE'
,p_version_scn=>37166391101150
,p_feature_identifier=>'APPLICATION_USER_SETTINGS'
,p_build_option_comment=>'The user settings page is a drawer that links to all user settings pages.'
);
wwv_flow_imp.component_end;
end;
/
