prompt --application/user_interfaces/combined_files
begin
--   Manifest
--     COMBINED FILES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
null;
wwv_flow_imp.component_end;
end;
/
