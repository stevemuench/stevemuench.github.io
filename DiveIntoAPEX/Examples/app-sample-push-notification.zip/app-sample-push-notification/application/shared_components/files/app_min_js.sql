prompt --application/shared_components/files/app_min_js
begin
--   Manifest
--     APP STATIC FILES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '24282866756E6374696F6E28297B617065782E7468656D6534322E7574696C2E636F6E666967415045584D736773287B6175746F4469736D6973733A21302C6475726174696F6E3A3265337D297D29293B';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(189152276708236759)
,p_file_name=>'app.min.js'
,p_mime_type=>'text/javascript'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
