prompt --application/shared_components/workflow/task_definitions/reimbursement_approval
begin
--   Manifest
--     TASK_DEF: Reimbursement Approval
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(99263230818240470)
,p_name=>'Reimbursement Approval'
,p_static_id=>'REIMBURSEMENT_APPROVAL'
,p_subject=>'Reimbursement for &AMOUNT. from &RECEIPT_FROM. by &APP_USER.'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:4:&SESSION.::&DEBUG.:RP,4:P4_TASK_ID:&TASK_ID.'
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ''$''||to_char(amount,''FM9G999G999D00'') as amount, receipt_from, created_by',
'from eba_demo_reimbursement',
'where id = :APEX$TASK_PK'))
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(99300614129527509)
,p_task_def_id=>wwv_flow_imp.id(99263230818240470)
,p_name=>'Notify Approve or Reject'
,p_execution_sequence=>10
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex_pwa.send_push_notification(           ',
'    p_user_name  => :CREATED_BY,',
'    p_title      => ''Reimbursement ''||initcap(:APEX$TASK_OUTCOME),',
'    p_body       => ''Your reimbursement of '' || :AMOUNT || '' from '' || :RECEIPT_FROM || '' was '' || lower(:APEX$TASK_OUTCOME)||''.'',',
'    p_target_url => apex_util.host_url||apex_page.get_url(p_page => ''reimbursement-notification'',p_items=>''p7_id'',p_values=>:APEX$TASK_PK)          ',
');',
'-- apex_pwa.push_queue;',
'update eba_demo_reimbursement ',
'   set status = upper(:APEX$TASK_OUTCOME),',
'       decided_by = :APP_USER,',
'       decided_on = sysdate',
' where id = :APEX$TASK_PK;',
''))
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(99263912343240473)
,p_task_def_id=>wwv_flow_imp.id(99263230818240470)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'PAT'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(99263499351240472)
,p_task_def_id=>wwv_flow_imp.id(99263230818240470)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'PAT'
);
wwv_flow_imp.component_end;
end;
/
