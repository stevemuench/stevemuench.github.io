prompt --application/shared_components/security/authorizations/customers
begin
--   Manifest
--     SECURITY SCHEME: Customers
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_security_scheme(
 p_id=>wwv_flow_imp.id(97923483408741470)
,p_name=>'Customers'
,p_scheme_type=>'NATIVE_IS_IN_GROUP'
,p_attribute_01=>'Customer'
,p_attribute_02=>'A'
,p_caching=>'BY_USER_BY_SESSION'
);
wwv_flow_imp.component_end;
end;
/
