prompt --application/shared_components/security/app_access_control/staff
begin
--   Manifest
--     ACL ROLE: Staff
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(97923169099736875)
,p_static_id=>'STAFF'
,p_name=>'Staff'
);
wwv_flow_imp.component_end;
end;
/
