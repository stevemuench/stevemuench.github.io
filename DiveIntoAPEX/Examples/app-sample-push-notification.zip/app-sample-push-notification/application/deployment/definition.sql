prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(99265114909280468)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- drop objects',
'drop table eba_demo_reimbursement cascade constraints;',
''))
);
wwv_flow_imp.component_end;
end;
/
