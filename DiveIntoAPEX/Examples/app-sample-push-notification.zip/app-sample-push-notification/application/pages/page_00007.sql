prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Reimbursement Notification'
,p_alias=>'REIMBURSEMENT-NOTIFICATION'
,p_step_title=>'Reimbursement Notification'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_deep_linking=>'Y'
,p_rejoin_existing_sessions=>'Y'
,p_page_component_map=>'11'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230507093417'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(99271001045327381)
,p_branch_name=>'Forward to Reimbursement'
,p_branch_action=>'f?p=&APP_ID.:6:&SESSION.::&DEBUG.::P6_ID:&P7_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(99270963164327380)
,p_name=>'P7_ID'
,p_item_sequence=>10
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp.component_end;
end;
/
