prompt --workspace/credentials/app_109_push_notifications_credentials
begin
--   Manifest
--     CREDENTIAL: App 109 Push Notifications Credentials
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1415799707483327
,p_default_application_id=>109
,p_default_id_offset=>191288776838000438
,p_default_owner=>'SMUENCH'
);
wwv_imp_workspace.create_credential(
 p_id=>wwv_flow_imp.id(95486935624536215)
,p_name=>'App 109 Push Notifications Credentials'
,p_static_id=>'App_109_Push_Notifications_Credentials'
,p_authentication_type=>'KEY_PAIR'
,p_prompt_on_install=>false
);
wwv_flow_imp.component_end;
end;
/
