prompt --application/deployment/install/install_insertsampledata
begin
--   Manifest
--     INSTALL: INSTALL-InsertSampleData
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>46537
,p_default_id_offset=>23604687455421703213
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(27038895835354634803)
,p_install_id=>wwv_flow_api.id(23611184874679219700)
,p_name=>'InsertSampleData'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --BOOK_AUTHORS: 12/10000 rows exported, APEX$DATA$PKG/BOOK_AUTHORS$699308',
'    apex_data_install.load_supporting_object_data(p_table_name => ''BOOK_AUTHORS'', p_delete_after_install => true );',
'    --BOOK_PUBLISHER: 6/10000 rows exported, APEX$DATA$PKG/BOOK_PUBLISHER$208211',
'    apex_data_install.load_supporting_object_data(p_table_name => ''BOOK_PUBLISHER'', p_delete_after_install => true );',
'    --BOOK_TAGS: 7/10000 rows exported, APEX$DATA$PKG/BOOK_TAGS$995301',
'    apex_data_install.load_supporting_object_data(p_table_name => ''BOOK_TAGS'', p_delete_after_install => true );',
'    --BOOK_TITLES: 9/10000 rows exported, APEX$DATA$PKG/BOOK_TITLES$953140',
'    apex_data_install.load_supporting_object_data(p_table_name => ''BOOK_TITLES'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_api.component_end;
end;
/
