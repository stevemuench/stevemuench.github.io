prompt --application/delete_application
begin
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>46537
,p_default_id_offset=>23604687455421703213
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.remove_flow(wwv_flow.g_flow_id);
wwv_flow_api.component_end;
end;
/
