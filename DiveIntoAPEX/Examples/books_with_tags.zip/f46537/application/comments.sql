prompt --application/comments
begin
--   Manifest
--     APPLICATION COMMENTS: 46537
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>46537
,p_default_id_offset=>23604687455421703213
,p_default_owner=>'WKSP_SMUENCH'
);
null;
wwv_flow_api.component_end;
end;
/
