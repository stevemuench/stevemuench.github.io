prompt --application/shared_components/logic/application_processes/download_static_website
begin
--   Manifest
--     APPLICATION PROCESS: Download_Static_Website
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(10372842559929163)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Download_Static_Website'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_demo_transform_group.download(',
'            p_file_name    => ''generate-hr-site.xml'', ',
'            p_zipfile_name => ''hr-website.zip'');'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
