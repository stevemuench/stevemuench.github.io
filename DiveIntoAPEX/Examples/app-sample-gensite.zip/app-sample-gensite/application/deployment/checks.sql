prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
null;
wwv_flow_imp.component_end;
end;
/
