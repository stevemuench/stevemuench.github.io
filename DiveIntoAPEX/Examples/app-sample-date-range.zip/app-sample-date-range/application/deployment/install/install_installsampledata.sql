prompt --application/deployment/install/install_installsampledata
begin
--   Manifest
--     INSTALL: INSTALL-InstallSampleData
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>837
,p_default_id_offset=>2400577412535947
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1067688970844407692)
,p_install_id=>wwv_flow_imp.id(1066416602985249763)
,p_name=>'InstallSampleData'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --EBA_DEMO_EVENT_DEFS: 1/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_EVENT_DEFS$924882',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_EVENT_DEFS'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
