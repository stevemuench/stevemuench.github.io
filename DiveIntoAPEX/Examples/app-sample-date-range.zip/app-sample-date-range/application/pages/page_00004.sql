prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>837
,p_default_id_offset=>2400577412535947
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Event Definition'
,p_alias=>'EVENT-DEFINITION'
,p_page_mode=>'MODAL'
,p_step_title=>'Event Definition'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Setup config for Event Start/End Date Range Picker',
'// Allows a single day to be both start and end',
'window.eventStartEndDateRangePicker = new DateRangePicker({',
'    picker: {',
'      name: "P4_EVENT_DATE_RANGE",',
'      format: "DD-MON-YYYY",',
'      allowSingleDay: true ',
'    },',
'    start: {',
'       name: "P4_EVENT_STARTS",  ',
'       label: "Event Start"',
'    },',
'    end: {',
'        name: "P4_EVENT_ENDS",',
'        label:"Event Start"',
'    },',
'    reset: {',
'        id:"Reset_Event_Dates"',
'    }',
'});',
'',
'// Setup the config for CheckIn/CheckOut Date Range Picker',
'// Requires start and end to be different days',
'window.checkInCheckOutDateRangePicker = new DateRangePicker({',
'    picker: {',
'        name: "P4_DEFAULT_HOTEL_STAY_RANGE",',
'        format: "DD-MON-YYYY",',
'        allowSingleDay: false ',
'    },',
'    start: {',
'        name: "P4_DEFAULT_CHECKIN_DATE",  ',
'        label: "Check In"',
'    },',
'    end: {',
'        name: "P4_DEFAULT_CHECKOUT_DATE",',
'        label:"Check Out"',
'    },',
'    reset: {',
'        id:"Reset_Default_Hotel_Stay"',
'    }',
'});'))
,p_step_template=>wwv_flow_imp.id(1066187564416532901)
,p_page_template_options=>'#DEFAULT#:js-dialog-class-t-Drawer--pullOutEnd'
,p_dialog_chained=>'N'
,p_protection_level=>'C'
,p_page_component_map=>'02'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230209090524'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1067622204244397641)
,p_plug_name=>'Event Definition'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1066223518188532920)
,p_plug_display_sequence=>10
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_EVENT_DEFS'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1067629506496397647)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1066226268225532921)
,p_plug_display_sequence=>20
,p_plug_display_point=>'REGION_POSITION_03'
,p_attribute_01=>'N'
,p_attribute_02=>'TEXT'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067643572945467380)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_button_name=>'Reset_Event_Dates'
,p_button_static_id=>'Reset_Event_Dates'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066361713875532980)
,p_button_image_alt=>'Reset Event Dates'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067643728661467381)
,p_button_sequence=>70
,p_button_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_button_name=>'Reset_Default_Hotel_Stay'
,p_button_static_id=>'Reset_Default_Hotel_Stay'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066361713875532980)
,p_button_image_alt=>'Reset Event Date Range'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067629870364397647)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(1067629506496397647)
,p_button_name=>'CANCEL'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066362402623532980)
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067631291077397648)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1067629506496397647)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066362402623532980)
,p_button_image_alt=>'Delete'
,p_button_position=>'DELETE'
,p_button_execute_validations=>'N'
,p_confirm_message=>'&APP_TEXT$DELETE_MSG!RAW.'
,p_confirm_style=>'danger'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'DELETE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067631729547397648)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(1067629506496397647)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066362402623532980)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Apply Changes'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1067632075651397648)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(1067629506496397647)
,p_button_name=>'CREATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066362402623532980)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'NEXT'
,p_button_condition=>'P4_ID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_database_action=>'INSERT'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1066157209752388527)
,p_name=>'P4_EVENT_DATE_RANGE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Event Date(s)'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067622532652397642)
,p_name=>'P4_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_is_query_only=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_use_cache_before_default=>'NO'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_label_alignment=>'RIGHT'
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067622871109397642)
,p_name=>'P4_NAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>80
,p_field_template=>wwv_flow_imp.id(1066361236570532980)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067623338864397643)
,p_name=>'P4_DEFAULT_CHECKIN_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'DEFAULT_CHECKIN_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067623715977397643)
,p_name=>'P4_DEFAULT_CHECKOUT_DATE'
,p_source_data_type=>'DATE'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'DEFAULT_CHECKOUT_DATE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067624069212397643)
,p_name=>'P4_EVENT_STARTS'
,p_source_data_type=>'DATE'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'EVENT_STARTS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067624538119397644)
,p_name=>'P4_EVENT_ENDS'
,p_source_data_type=>'DATE'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'EVENT_ENDS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067624933078397644)
,p_name=>'P4_CREATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Created'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'CREATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P4_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(1066361236570532980)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067625276166397644)
,p_name=>'P4_CREATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Created By'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'CREATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P4_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(1066361236570532980)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067625664305397644)
,p_name=>'P4_UPDATED'
,p_source_data_type=>'DATE'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Updated'
,p_format_mask=>'DD-MON-YYYY HH24:MI:SS'
,p_source=>'UPDATED'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_display_when=>'P4_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(1066361236570532980)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067626046729397644)
,p_name=>'P4_UPDATED_BY'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Updated By'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'UPDATED_BY'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P4_ID'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(1066361236570532980)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067643420073467378)
,p_name=>'P4_DEFAULT_HOTEL_STAY_RANGE'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Default Attendee Hotel Stay'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067643464892467379)
,p_name=>'P4_CATERING_DEADLINE'
,p_source_data_type=>'DATE'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_item_source_plug_id=>wwv_flow_imp.id(1067622204244397641)
,p_prompt=>'Catering Contract Deadline'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'CATERING_DEADLINE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
,p_attribute_02=>'POPUP'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(1067629994155397647)
,p_name=>'Cancel Dialog'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(1067629870364397647)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(1067630775631397648)
,p_event_id=>wwv_flow_imp.id(1067629994155397647)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1067632846307397649)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(1067622204244397641)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Event Definition'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1067633254475397649)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_CLOSE_WINDOW'
,p_process_name=>'Close Dialog'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'CREATE,SAVE,DELETE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1067632468726397649)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(1067622204244397641)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Event Definition'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_imp.component_end;
end;
/
