prompt --application/pages/page_00002
begin
--   Manifest
--     PAGE: 00002
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>837
,p_default_id_offset=>2400577412535947
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>2
,p_name=>'Date Range'
,p_alias=>'DATE-RANGE'
,p_step_title=>'Date Range'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Setup the config for CheckIn/CheckOut Date Range Picker',
'// Requires start and end to be different days',
'window.checkInCheckOutDateRangePicker = new DateRangePicker({',
'    picker: {',
'        name: "P2_CHECKIN_CHECKOUT_PICKER",',
'        format: "DD-MON-YYYY",',
'        allowSingleDay: false ',
'    },',
'    start: {',
'        name: "P2_CHECKIN",  ',
'        label: "Check In"',
'    },',
'    end: {',
'        name: "P2_CHECKOUT",',
'        label:"Check Out"',
'    },',
'    reset: {',
'        id:"Reset_CheckIn_CheckOut"',
'    }',
'});    ',
'',
'// Setup config for Event Start/End Date Range Picker',
'// Allows a single day to be both start and end',
'window.eventStartEndDateRangePicker = new DateRangePicker({',
'    picker: {',
'        name: "P2_EVENT_START_END_PICKER",',
'        format: "DD-MON-YYYY",',
'        allowSingleDay: true ',
'    },',
'    start: {',
'        name: "P2_EVENT_STARTS",  ',
'        label: "Event Start"',
'    },',
'    end: {',
'        name: "P2_EVENT_ENDS",',
'        label:"Event Start"',
'            },',
'    reset: {',
'        id:"Reset_Event_Start_End"',
'    }',
'});    ',
'',
''))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20241111092029'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1066156199257388517)
,p_plug_name=>'Allow Start and End Date to Be the Same'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1066289523324532947)
,p_plug_display_sequence=>60
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1066156272774388518)
,p_plug_name=>'Expect Start and End Date to be Different'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(1066289523324532947)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(1080710314333460931)
,p_plug_name=>'Date Range Picker'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(1066256495378532934)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_region_image=>'#APP_FILES#icons/app-icon-512.png'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1066153745175388493)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1066156272774388518)
,p_button_name=>'Reset_CheckIn_CheckOut'
,p_button_static_id=>'Reset_CheckIn_CheckOut'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066361713875532980)
,p_button_image_alt=>'Reset Checkin Checkout'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(1066156906507388524)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(1066156199257388517)
,p_button_name=>'Reset_Event_Start_End'
,p_button_static_id=>'Reset_Event_Start_End'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(1066361713875532980)
,p_button_image_alt=>'Reset'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-undo'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1066154200150388497)
,p_name=>'P2_CHECKOUT'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1066156272774388518)
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1066156396978388519)
,p_name=>'P2_EVENT_START_END_PICKER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1066156199257388517)
,p_prompt=>'Your Event: Pick Check Start and End Day(s)'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1066156464070388520)
,p_name=>'P2_EVENT_STARTS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1066156199257388517)
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1066156624363388521)
,p_name=>'P2_EVENT_ENDS'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(1066156199257388517)
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067222762596682843)
,p_name=>'P2_CHECKIN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(1066156272774388518)
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(1067223238110682845)
,p_name=>'P2_CHECKIN_CHECKOUT_PICKER'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(1066156272774388518)
,p_prompt=>'Your Stay: Pick Check In and Check Out Days'
,p_format_mask=>'DD-MON-YYYY'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>30
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(1066359899943532979)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'INLINE'
,p_attribute_03=>'NONE'
,p_attribute_06=>'NONE'
,p_attribute_09=>'N'
,p_attribute_11=>'N'
,p_attribute_12=>'MONTH-PICKER:YEAR-PICKER:CLEAR-BUTTON'
,p_attribute_13=>'VISIBLE'
,p_attribute_15=>'FOCUS'
);
wwv_flow_imp.component_end;
end;
/
