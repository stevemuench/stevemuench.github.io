prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(3066073031281263)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table eba_demo_warehouse cascade constraints;',
'drop table eba_demo_thing_categories cascade constraints;',
'drop table eba_demo_things cascade constraints;',
'drop table eba_demo_thing_stock cascade constraints;',
'drop package eba_demo_thing;',
'drop package eba_demo_thing_json;',
'drop package eba_demo_thing_ords;'))
);
wwv_flow_imp.component_end;
end;
/
