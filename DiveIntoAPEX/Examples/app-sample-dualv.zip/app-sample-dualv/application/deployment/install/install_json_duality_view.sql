prompt --application/deployment/install/install_json_duality_view
begin
--   Manifest
--     INSTALL: INSTALL-JSON Duality View
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3282394629233327)
,p_install_id=>wwv_flow_imp.id(3066073031281263)
,p_name=>'JSON Duality View'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace json relational duality view things_dv as',
'eba_demo_things @insert @update',
'{',
'    _id         : id',
'    name        : name',
'    description : description',
'    price       : price',
'    available   : available',
'    eba_demo_thing_categories @unnest',
'    {',
'        categoryId : id',
'        category   : name',
'    }',
'    stock : eba_demo_thing_stock @insert @update @delete',
'    {',
'        thingStockId : id',
'        quantity     : quantity',
'        eba_demo_warehouse @unnest',
'        {',
'            warehouseId : id',
'            warehouse   : name',
'        }',
'    }',
'}',
'/'))
);
wwv_flow_imp.component_end;
end;
/
