prompt --application/deployment/install/install_autorest_enable_duality_view
begin
--   Manifest
--     INSTALL: INSTALL-AutoREST Enable Duality View
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4684046591563435)
,p_install_id=>wwv_flow_imp.id(3066073031281263)
,p_name=>'AutoREST Enable Duality View'
,p_sequence=>60
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'  ords.enable_object (',
'    p_enabled      => TRUE,',
'    p_object       => ''THINGS_DV'',',
'    p_object_type  => ''VIEW'',',
'    p_object_alias => ''things_dv''',
'  );',
'  commit;',
'end;',
'/',
'    '))
);
wwv_flow_imp.component_end;
end;
/
