prompt --application/deployment/install/install_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3488418562079132)
,p_install_id=>wwv_flow_imp.id(3066073031281263)
,p_name=>'Sample Data'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'insert into eba_demo_thing_categories(name) values (''BOOKS'');',
'insert into eba_demo_thing_categories(name) values (''MUSIC'');',
'insert into eba_demo_thing_categories(name) values (''MOVIES'');',
'insert into eba_demo_warehouse(name) values (''LAS VEGAS'');',
'insert into eba_demo_warehouse(name) values (''SEATTLE'');',
'insert into eba_demo_warehouse(name) values (''BALTIMORE'');',
'commit',
'/',
'declare',
'    c_json_template constant varchar2(4000) :=',
'     q''~{',
'          "name": "%s",',
'          "description": "%s",',
'          "price": %s,',
'          "available": "%s",',
'          "category": "%s",',
'          "stock": [',
'              {"quantity": %s,"warehouse": "LAS VEGAS"},',
'              {"quantity": %s,"warehouse": "SEATTLE"},',
'              {"quantity": %s,"warehouse": "BALTIMORE"}',
'          ]',
'        }~'';',
'begin',
'    for j in (select x.name, ',
'                     x.description, ',
'                     x.price, ',
'                     x.category, ',
'                     x.available',
'              from apex_application_files aaf,',
'                   json_table(aaf.blob_content, ''$[*]''',
'                    columns(',
'                        name        varchar2(4000) path ''$.NAME'',',
'                        description varchar2(4000) path ''$.DESCRIPTION'',',
'                        price       number         path ''$.PRICE'',',
'                        category    varchar2(4000) path ''$.CATEGORY'',',
'                        available   date           path ''$.AVAILABLE''',
'                    )) x',
'              where flow_id = coalesce(apex_application_install.get_application_id,to_number(v(''APP_ID'')))',
'                and filename = ''SampleData.json'') loop',
'        insert into things_dv(data)',
'        values(apex_string.format(',
'                c_json_template,',
'                j.name,',
'                j.description,',
'                j.price,',
'                to_char(j.available,''YYYY-MM-DD''),',
'                j.category,',
'                trunc(dbms_random.value(1,10)),',
'                trunc(dbms_random.value(1,10)),',
'                trunc(dbms_random.value(1,10))));',
'    end loop;',
'    commit;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
