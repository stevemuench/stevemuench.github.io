prompt --application/deployment/install/install_drop_tables
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(3067062706315865)
,p_install_id=>wwv_flow_imp.id(3066073031281263)
,p_name=>'Drop Tables'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'drop table if exists eba_demo_things cascade constraints;',
'drop table if exists eba_demo_thing_categories cascade constraints;',
'drop table if exists eba_demo_warehouse cascade constraints;',
'drop table if exists eba_demo_thing_stock cascade constraints;',
''))
);
wwv_flow_imp.component_end;
end;
/
