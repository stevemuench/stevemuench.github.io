prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
null;
wwv_flow_imp.component_end;
end;
/
