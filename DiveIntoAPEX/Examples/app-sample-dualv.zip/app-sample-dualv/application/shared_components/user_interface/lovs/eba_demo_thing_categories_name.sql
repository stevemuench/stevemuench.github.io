prompt --application/shared_components/user_interface/lovs/eba_demo_thing_categories_name
begin
--   Manifest
--     EBA_DEMO_THING_CATEGORIES.NAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3070916605392590)
,p_lov_name=>'EBA_DEMO_THING_CATEGORIES.NAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'EBA_DEMO_THING_CATEGORIES'
,p_return_column_name=>'ID'
,p_display_column_name=>'NAME'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
