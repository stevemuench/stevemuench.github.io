prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(4282964223471917)
,p_name=>'ALL_STOCK_REQUIRES_WAREHOUSE'
,p_message_text=>'All stock entries require a warehouse'
,p_version_scn=>9750146
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(4690521786821148)
,p_name=>'AVAILABLE_TOO_OLD'
,p_message_text=>'A new thing''s available date must be in the past year or the future'
,p_version_scn=>11122095
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(5082427191194408)
,p_name=>'INVALID_CATEGORY'
,p_message_text=>'Please supply a valid category'
,p_version_scn=>11349799
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(3681480427605064)
,p_name=>'INVALID_PRICE'
,p_message_text=>'Price must be between 0.01 and 99999.99 with no fractional cents'
,p_version_scn=>9166848
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(4886197805260221)
,p_name=>'INVALID_QUANTITY'
,p_message_text=>'Stock quantity must be a non-negative whole number'
,p_version_scn=>11349875
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(5082624697199680)
,p_name=>'INVALID_WAREHOUSE'
,p_message_text=>'Please supply a valid warehouse'
,p_version_scn=>11349844
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(6489755667319875)
,p_name=>'LOST_UPDATE_FAILURE'
,p_message_text=>'Thing changed by another user. Get the thing again and retry.'
,p_version_scn=>12805574
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.10.31'
,p_release=>'23.2.0'
,p_default_workspace_id=>2757332067248753
,p_default_application_id=>100
,p_default_id_offset=>0
,p_default_owner=>'DIVEINTOAPEX'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(4204849438927291)
,p_name=>'REQUIRED_FIELDS_MISSING'
,p_message_text=>'Required fields missing: %0'
,p_version_scn=>9718636
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(4204661249925581)
,p_name=>'REQUIRED_FIELD_MISSING'
,p_message_text=>'Required field missing: %0'
,p_version_scn=>9718569
);
wwv_flow_imp.component_end;
end;
/
