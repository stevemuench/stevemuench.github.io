prompt --application/deployment/install/install_employees_function_sql
begin
--   Manifest
--     INSTALL: INSTALL-employees_function.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12427566742001618)
,p_install_id=>wwv_flow_imp.id(12426989509997207)
,p_name=>'employees_function.sql'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Generated on 14-MAR-2023 15:30:09 by Region Data Sharing Helper',
'create or replace function employees_data( p_page_id number := null)',
'return employees_tab pipelined',
'is',
'    l_ctx              apex_exec.t_context;',
'    l_page_id          number := coalesce(p_page_id,1);',
'    l_app_id           number := v(''APP_ID'');',
'    l_region_id        number;',
'    l_region_static_id varchar2(128) := ''employees'';',
'    l_idx              apex_application.num_assoc_arr;',
'    l_col_count        number;',
'begin',
'    begin',
'        -- Lookup region internal id',
'        select region_id',
'          into l_region_id',
'          from apex_application_page_regions',
'         where application_id = l_app_id',
'           and page_id        = l_page_id',
'           and static_id      = l_region_static_id;',
'    exception',
'        when no_data_found then',
'            return;',
'    end;',
'    -- open an apex_exec "cursor" on the region''s data',
'    l_ctx := apex_region.open_query_context(',
'                 p_page_id   => l_page_id,',
'                 p_region_id => l_region_id );',
'    -- Compute column indexes',
'    l_col_count := apex_exec.get_column_count(l_ctx);',
'    for j in 1..l_col_count loop',
'        l_idx(apex_exec.get_column(l_ctx,j).name) := j;',
'    end loop;',
'    -- Fetch and pipe the data from the region row by row    ',
'    while apex_exec.next_row(p_context => l_ctx) loop',
'        pipe row (',
'            employees_row(',
'                 case when l_idx.exists(''ENAME'') then apex_exec.get_varchar2(l_ctx,l_idx(''ENAME'')) end,',
'                 case when l_idx.exists(''JOB'') then apex_exec.get_varchar2(l_ctx,l_idx(''JOB'')) end,',
'                 case when l_idx.exists(''MGR'') then apex_exec.get_varchar2(l_ctx,l_idx(''MGR'')) end,',
'                 case when l_idx.exists(''EMPNO'') then apex_exec.get_number(l_ctx,l_idx(''EMPNO'')) end,',
'                 case when l_idx.exists(''HIREDATE'') then apex_exec.get_date(l_ctx,l_idx(''HIREDATE'')) end,',
'                 case when l_idx.exists(''SAL'') then apex_exec.get_number(l_ctx,l_idx(''SAL'')) end,',
'                 case when l_idx.exists(''COMM'') then apex_exec.get_number(l_ctx,l_idx(''COMM'')) end,',
'                 case when l_idx.exists(''DEPTNO'') then apex_exec.get_varchar2(l_ctx,l_idx(''DEPTNO'')) end',
'            )',
'        );',
'    end loop;',
'    apex_exec.close(l_ctx);',
'exception',
'    when no_data_needed then',
'        apex_exec.close(l_ctx);',
'        return;',
'    when others then',
'        apex_debug.info(dbms_utility.format_error_stack()',
'                         || chr(10)',
'                         || dbms_utility.format_error_backtrace());',
'        apex_exec.close(l_ctx);',
'        raise;',
'        return;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
