prompt --application/deployment/install/install_employees_types_sql
begin
--   Manifest
--     INSTALL: INSTALL-employees_types.sql
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(12427369647999682)
,p_install_id=>wwv_flow_imp.id(12426989509997207)
,p_name=>'employees_types.sql'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- Generated on 14-MAR-2023 15:30:09 by Region Data Sharing Helper',
'declare',
'    object_does_not_exist exception;',
'    pragma exception_init(object_does_not_exist,-4043);',
'begin',
'  execute immediate ''drop type employees_tab'';',
'exception',
'    when object_does_not_exist then',
'        null;',
'end;',
'/        ',
'declare',
'    object_does_not_exist exception;',
'    pragma exception_init(object_does_not_exist,-4043);',
'begin',
'  execute immediate ''drop type employees_row'';',
'exception',
'    when object_does_not_exist then',
'        null;',
'end;',
'/        ',
'create or replace type employees_row as object',
'(',
'    ename varchar2(50),',
'    job varchar2(50),',
'    mgr varchar2(50),',
'    empno number,',
'    hiredate date,',
'    sal number,',
'    comm number,',
'    deptno varchar2(50)',
')',
'/',
'create or replace type employees_tab as table',
'of employees_row',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
