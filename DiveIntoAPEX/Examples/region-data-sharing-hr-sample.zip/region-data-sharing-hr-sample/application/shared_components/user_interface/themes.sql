prompt --application/shared_components/user_interface/themes
begin
--   Manifest
--     THEME: 107
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_theme(
 p_id=>wwv_flow_imp.id(12370292760902331)
,p_theme_id=>42
,p_theme_name=>'Universal Theme'
,p_theme_internal_name=>'UNIVERSAL_THEME'
,p_navigation_type=>'L'
,p_nav_bar_type=>'LIST'
,p_reference_id=>4070917134413059350
,p_is_locked=>false
,p_default_page_template=>wwv_flow_imp.id(12218266344902253)
,p_default_dialog_template=>wwv_flow_imp.id(12213093684902251)
,p_error_template=>wwv_flow_imp.id(12203072506902244)
,p_printer_friendly_template=>wwv_flow_imp.id(12218266344902253)
,p_breadcrumb_display_point=>'REGION_POSITION_01'
,p_sidebar_display_point=>'REGION_POSITION_02'
,p_login_template=>wwv_flow_imp.id(12203072506902244)
,p_default_button_template=>wwv_flow_imp.id(12367287042902326)
,p_default_region_template=>wwv_flow_imp.id(12294383733902289)
,p_default_chart_template=>wwv_flow_imp.id(12294383733902289)
,p_default_form_template=>wwv_flow_imp.id(12294383733902289)
,p_default_reportr_template=>wwv_flow_imp.id(12294383733902289)
,p_default_tabform_template=>wwv_flow_imp.id(12294383733902289)
,p_default_wizard_template=>wwv_flow_imp.id(12294383733902289)
,p_default_menur_template=>wwv_flow_imp.id(12306727182902294)
,p_default_listr_template=>wwv_flow_imp.id(12294383733902289)
,p_default_irr_template=>wwv_flow_imp.id(12284502917902285)
,p_default_report_template=>wwv_flow_imp.id(12332255304902306)
,p_default_label_template=>wwv_flow_imp.id(12364749493902324)
,p_default_menu_template=>wwv_flow_imp.id(12368886231902327)
,p_default_calendar_template=>wwv_flow_imp.id(12368965163902327)
,p_default_list_template=>wwv_flow_imp.id(12348657081902314)
,p_default_nav_list_template=>wwv_flow_imp.id(12360435827902321)
,p_default_top_nav_list_temp=>wwv_flow_imp.id(12360435827902321)
,p_default_side_nav_list_temp=>wwv_flow_imp.id(12355057438902318)
,p_default_nav_list_position=>'SIDE'
,p_default_dialogbtnr_template=>wwv_flow_imp.id(12231134309902261)
,p_default_dialogr_template=>wwv_flow_imp.id(12228389653902259)
,p_default_option_label=>wwv_flow_imp.id(12364749493902324)
,p_default_required_label=>wwv_flow_imp.id(12366050159902325)
,p_default_navbar_list_template=>wwv_flow_imp.id(12354619007902318)
,p_file_prefix => nvl(wwv_flow_application_install.get_static_theme_file_prefix(42),'#APEX_FILES#themes/theme_42/22.2/')
,p_files_version=>64
,p_icon_library=>'FONTAPEX'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#APEX_FILES#libraries/apex/#MIN_DIRECTORY#widget.stickyWidget#MIN#.js?v=#APEX_VERSION#',
'#THEME_FILES#js/theme42#MIN#.js?v=#APEX_VERSION#'))
,p_css_file_urls=>'#THEME_FILES#css/Core#MIN#.css?v=#APEX_VERSION#'
);
wwv_flow_imp.component_end;
end;
/
