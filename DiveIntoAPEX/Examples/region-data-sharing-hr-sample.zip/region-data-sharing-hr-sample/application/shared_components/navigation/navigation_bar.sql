prompt --application/shared_components/navigation/navigation_bar
begin
--   Manifest
--     ICON BAR ITEMS: 107
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
null;
wwv_flow_imp.component_end;
end;
/
