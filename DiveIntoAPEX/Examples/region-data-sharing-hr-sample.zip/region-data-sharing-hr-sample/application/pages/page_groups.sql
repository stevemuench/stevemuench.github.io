prompt --application/pages/page_groups
begin
--   Manifest
--     PAGE GROUPS: 107
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>107
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_page.create_page_group(
 p_id=>wwv_flow_imp.id(12395730316902356)
,p_group_name=>'Administration'
);
wwv_flow_imp.component_end;
end;
/
