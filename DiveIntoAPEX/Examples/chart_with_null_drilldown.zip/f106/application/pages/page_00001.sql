prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>19404766370905118
,p_default_application_id=>106
,p_default_id_offset=>0
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_page(
 p_id=>1
,p_user_interface_id=>wwv_flow_api.id(20148397209818384)
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Chart With Null Drilldown'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20210418143243'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(6706242998924147)
,p_plug_name=>'Chart of Books by Rating'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(20063148292818109)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(6706379027924148)
,p_region_id=>wwv_flow_api.id(6706242998924147)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(6706456022924149)
,p_chart_id=>wwv_flow_api.id(6706379027924148)
,p_seq=>10
,p_name=>'Books by Rating'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when rating_stars is null then ''<Unrated>'' else rating_stars||'' Stars'' end as label,',
'       num_books,',
'       rating_stars,',
'       case when rating_stars is null then ''irn_rating_stars'' else ''ireq_rating_stars'' end as ir_filter_param_name',
'from (       ',
'       select rating_stars,',
'       count(*) as num_books',
'       from pnl_theroux_books',
'       group by rating_stars',
')'))
,p_items_value_column_name=>'NUM_BOOKS'
,p_items_label_column_name=>'LABEL'
,p_custom_column_name=>'IR_FILTER_PARAM_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:CR,2:&IR_FILTER_PARAM_NAME.:&RATING_STARS.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_api.create_page_plug(
 p_id=>wwv_flow_api.id(20161340253823402)
,p_plug_name=>'Chart of Books by Publisher'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_api.id(20063148292818109)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_display_point=>'BODY'
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_api.create_jet_chart(
 p_id=>wwv_flow_api.id(20161429558823403)
,p_region_id=>wwv_flow_api.id(20161340253823402)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_api.create_jet_chart_series(
 p_id=>wwv_flow_api.id(20161538266823404)
,p_chart_id=>wwv_flow_api.id(20161429558823403)
,p_seq=>10
,p_name=>'Books by Publisher'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when b.publisher_id is null then ''<None>'' else p.name end as label,',
'       num_books,',
'       b.publisher_id,',
'       case when b.publisher_id is null then ''irn_publisher_id'' else ''ireq_publisher_id'' end as ir_filter_param_name',
'from (       ',
'       select publisher_id,',
'       count(*) as num_books',
'       from pnl_theroux_books',
'       group by publisher_id',
') b',
'left outer join pnl_publishers p on b.publisher_id = p.id'))
,p_items_value_column_name=>'NUM_BOOKS'
,p_items_label_column_name=>'LABEL'
,p_custom_column_name=>'IR_FILTER_PARAM_NAME'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
,p_link_target=>'f?p=&APP_ID.:2:&SESSION.::&DEBUG.:CR,2:&IR_FILTER_PARAM_NAME.:&PUBLISHER_ID.'
,p_link_target_type=>'REDIRECT_PAGE'
);
wwv_flow_api.component_end;
end;
/
