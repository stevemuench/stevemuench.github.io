prompt --application/shared_components/remote_servers/slc12kos
begin
--   Manifest
--     REMOTE SERVER: slc12kos
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.3'
,p_default_workspace_id=>1908816359534887
,p_default_application_id=>119
,p_default_id_offset=>10297408605059787
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_remote_server(
 p_id=>wwv_flow_api.id(9760475227432571574)
,p_name=>'slc12kos'
,p_static_id=>'slc12kos'
,p_base_url=>nvl(wwv_flow_application_install.get_remote_server_base_url('slc12kos'),'http://slc12kos.us.oracle.com:8080/ords/examples')
,p_https_host=>nvl(wwv_flow_application_install.get_remote_server_https_host('slc12kos'),'')
,p_server_type=>'REMOTE_SQL'
,p_ords_timezone=>nvl(wwv_flow_application_install.get_remote_server_ords_tz('slc12kos'),'US/Pacific')
,p_credential_id=>wwv_flow_api.id(9760475068759571571)
,p_prompt_on_install=>true
);
wwv_flow_api.component_end;
end;
/
