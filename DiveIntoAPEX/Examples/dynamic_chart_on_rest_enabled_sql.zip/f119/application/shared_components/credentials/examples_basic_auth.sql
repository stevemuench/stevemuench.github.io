prompt --application/shared_components/credentials/examples_basic_auth
begin
--   Manifest
--     CREDENTIAL: examples_basic_auth
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.3'
,p_default_workspace_id=>1908816359534887
,p_default_application_id=>119
,p_default_id_offset=>10297408605059787
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_credential(
 p_id=>wwv_flow_api.id(9760475068759571571)
,p_name=>'examples_basic_auth'
,p_static_id=>'examples_basic_auth'
,p_authentication_type=>'BASIC'
,p_valid_for_urls=>'http://slc12kos.us.oracle.com:8080/ords/examples'
,p_prompt_on_install=>true
);
wwv_flow_api.component_end;
end;
/
