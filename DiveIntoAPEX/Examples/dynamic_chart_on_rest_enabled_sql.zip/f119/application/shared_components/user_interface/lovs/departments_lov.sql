prompt --application/shared_components/user_interface/lovs/departments_lov
begin
--   Manifest
--     DEPARTMENTS_LOV
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.3'
,p_default_workspace_id=>1908816359534887
,p_default_application_id=>119
,p_default_id_offset=>10297408605059787
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_list_of_values(
 p_id=>wwv_flow_api.id(9760548775181583452)
,p_lov_name=>'DEPARTMENTS_LOV'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select dname, deptno',
'from dept',
'order by dname'))
,p_source_type=>'SQL'
,p_location=>'REMOTE'
,p_remote_server_id=>wwv_flow_api.id(9760475227432571574)
,p_return_column_name=>'DEPTNO'
,p_display_column_name=>'DNAME'
);
wwv_flow_api.component_end;
end;
/
