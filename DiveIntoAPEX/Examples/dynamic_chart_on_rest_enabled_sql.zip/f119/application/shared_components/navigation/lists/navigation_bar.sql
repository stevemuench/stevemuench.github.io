prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.3'
,p_default_workspace_id=>1908816359534887
,p_default_application_id=>119
,p_default_id_offset=>10297408605059787
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_list(
 p_id=>wwv_flow_api.id(9750457307096251986)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
);
wwv_flow_api.component_end;
end;
/
