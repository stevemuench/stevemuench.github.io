prompt --application/deployment/install/install_installpackage
begin
--   Manifest
--     INSTALL: INSTALL-InstallPackage
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.3'
,p_default_workspace_id=>1908816359534887
,p_default_application_id=>119
,p_default_id_offset=>10297408605059787
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(9764086327543994615)
,p_install_id=>wwv_flow_api.id(9764072519038987494)
,p_name=>'InstallPackage'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE PACKAGE "REGION_UTILS" is',
'  function has_data(p_region_static_id varchar2) return boolean;',
'  function has_data_as_string(p_region_static_id varchar2) return varchar2;',
'end;',
'/',
'',
'',
'CREATE OR REPLACE EDITIONABLE PACKAGE BODY "REGION_UTILS" is',
'    function boolean_to_string(p_value boolean) return varchar2 is',
'    begin',
'        return case when p_value then ''TRUE'' else ''FALSE'' end;',
'    end;',
'    function has_data(p_region_static_id varchar2) return boolean',
'    is',
'        l_context     apex_exec.t_context;',
'        l_region_id   apex_application_page_regions.region_id%type;',
'        l_return      boolean;',
'        l_page_id     number := v(''APP_PAGE_ID'');',
'        l_app_id      number := v(''APP_ID'');',
'    begin',
'        select region_id',
'        into l_region_id',
'        from apex_application_page_regions',
'        where application_id = l_app_id',
'          and page_id        = l_page_id',
'          and static_id      = p_region_static_id;',
'        l_context := apex_region.open_query_context(',
'                       p_page_id   => l_page_id,',
'                       p_region_id => l_region_id,',
'                       p_max_rows  => 1);',
'        l_return  := apex_exec.next_row( p_context => l_context );',
'        apex_exec.close( l_context );',
'        APEX_DEBUG.INFO(''--- region_utils.has_data(''''%s'''') = %s'',p_region_static_id,boolean_to_string(l_return));  ',
'        return l_return;',
'    exception when others then',
'        apex_exec.close( l_context );',
'        raise;',
'    end;',
'    function has_data_as_string(p_region_static_id varchar2) return varchar2 is ',
'    begin',
'        return boolean_to_string(has_data(p_region_static_id));',
'    end;',
'end;',
'/',
'',
''))
);
wwv_flow_api.create_install_object(
 p_id=>wwv_flow_api.id(9764086452806994623)
,p_script_id=>wwv_flow_api.id(9764086327543994615)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'REGION_UTILS'
,p_last_updated_by=>'STEVE.MUENCH@ORACLE.COM'
,p_last_updated_on=>to_date('20220204220127','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE.MUENCH@ORACLE.COM'
,p_created_on=>to_date('20220204220127','YYYYMMDDHH24MISS')
);
wwv_flow_api.component_end;
end;
/
