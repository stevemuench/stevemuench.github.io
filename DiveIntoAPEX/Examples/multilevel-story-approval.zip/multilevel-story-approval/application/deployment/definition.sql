prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 29099
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(10083311339690570426)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- drop objects',
'drop table eba_demo_story cascade constraints;',
'drop table eba_demo_story_appr_steps cascade constraints;',
'drop table eba_demo_story_appr_step_def cascade constraints;',
'drop table eba_demo_story_users cascade constraints;',
'drop table eba_demo_story_department cascade constraints;'))
);
wwv_flow_imp.component_end;
end;
/
