prompt --application/deployment/install/install_indexes
begin
--   Manifest
--     INSTALL: INSTALL-Indexes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(1014520129119025)
,p_install_id=>wwv_flow_imp.id(10083311339690570426)
,p_name=>'Indexes'
,p_sequence=>50
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create index eba_demo_story_appr_steps_idx on eba_demo_story_appr_steps(story_id,iteration)',
'/'))
);
wwv_flow_imp.component_end;
end;
/
