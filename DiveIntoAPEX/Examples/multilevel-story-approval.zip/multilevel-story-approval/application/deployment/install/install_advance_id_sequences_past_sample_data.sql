prompt --application/deployment/install/install_advance_id_sequences_past_sample_data
begin
--   Manifest
--     INSTALL: INSTALL-Advance ID Sequences Past Sample Data
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(4060299442305810)
,p_install_id=>wwv_flow_imp.id(10083311339690570426)
,p_name=>'Advance ID Sequences Past Sample Data'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_max_id number;',
'    l_seqname varchar2(100);',
'    l_pk_col varchar2(30);',
'    l_next_val number;',
'begin',
'    for t in (select table_name ',
'                from user_tables ',
'               where table_name in (''EBA_DEMO_STORY_USERS'',',
'                                    ''EBA_DEMO_STORY_DEPARTMENT'',',
'                                    ''EBA_DEMO_STORY_APPR_STEP_DEF'')) loop',
'        l_max_id := null;',
'        l_next_val := null;',
'        select lower(cols.column_name)',
'        into l_pk_col',
'        from user_cons_columns cols',
'        left outer join user_constraints cons',
'          on cons.constraint_name = cols.constraint_name',
'         and cons.constraint_type = ''P''',
'        where cons.table_name = upper(t.table_name)',
'        order by cols.table_name, cols.position',
'        fetch first row only; ',
'        execute immediate ''select max(''||l_pk_col||'') from ''||t.table_name',
'        into l_max_id;',
'        if l_max_id is not null then',
'            select data_default',
'            into l_seqname',
'            from user_tab_columns',
'            where table_name = upper(t.table_name)',
'            and column_name = upper(l_pk_col);        ',
'            while nvl(l_next_val,0) < l_max_id loop ',
'                execute immediate ''select ''||l_seqname||'' from sys.dual''',
'                into l_next_val;',
'            end loop;',
'        end if;',
'   end loop;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
