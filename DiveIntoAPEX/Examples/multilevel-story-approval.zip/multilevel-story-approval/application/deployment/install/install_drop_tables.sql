prompt --application/deployment/install/install_drop_tables
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(2985393419803012)
,p_install_id=>wwv_flow_imp.id(10083311339690570426)
,p_name=>'Drop Tables'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables apex_t_varchar2 := apex_t_varchar2(''eba_demo_story'',',
'                                                ''eba_demo_story_appr_steps'',',
'                                                ''eba_demo_story_appr_step_def'',',
'                                                ''eba_demo_story_department'',',
'                                                ''eba_demo_story_users'');',
'begin',
'    --',
'    -- Quietly drop all tables in the list',
'    --',
'    for j in 1..l_tables.count loop',
'        begin',
'            execute immediate ''drop table ''||l_tables(j)||'' cascade constraints'';',
'        exception',
'            when others then',
'                if sqlcode != -942 then',
'                    raise;',
'                end if;',
'        end;',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
