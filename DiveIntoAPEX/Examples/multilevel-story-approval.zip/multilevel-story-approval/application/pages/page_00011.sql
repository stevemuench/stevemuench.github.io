prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'Demo Purposes Only Login'
,p_alias=>'DEMO-PURPOSES-ONLY-LOGIN'
,p_step_title=>'Demo Purposes Only Login'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'table.overview td:first-child {',
'  text-align: right;',
'}',
'table.overview td {',
'  padding: 1em;',
'}',
'.left-side {',
'  min-width: 150px',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'12'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230822193712'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(277183620620602)
,p_plug_name=>'Left Side'
,p_region_css_classes=>'left-side'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(10083047086298540283)
,p_plug_display_sequence=>40
,p_plug_grid_column_span=>3
,p_plug_display_column=>1
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3996240652252128)
,p_plug_name=>'Demo Purposes Only Login'
,p_region_name=>'userTree'
,p_parent_plug_id=>wwv_flow_imp.id(277183620620602)
,p_region_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(10083047086298540283)
,p_plug_display_sequence=>30
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select case when connect_by_isleaf = 1 then 0',
'            when level = 1             then 1',
'            else                           -1',
'       end          as status, ',
'       level, ',
'       username     as title, ',
'       ''fa fa-user'' as icon, ',
'       id           as value, ',
'       null         as tooltip, ',
'       null         as link ',
'from eba_demo_story_users',
'start with manager_id is null',
'connect by prior id = manager_id',
'order siblings by username'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_JSTREE'
,p_attribute_02=>'S'
,p_attribute_03=>'P11_SELECTED_USERID'
,p_attribute_04=>'N'
,p_attribute_08=>'a-Icon'
,p_attribute_09=>'icon-tree-folder'
,p_attribute_10=>'TITLE'
,p_attribute_11=>'LEVEL'
,p_attribute_12=>'ICON'
,p_attribute_15=>'STATUS'
,p_attribute_20=>'VALUE'
,p_attribute_23=>'LEVEL'
,p_attribute_24=>'LINK'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(277235913620603)
,p_plug_name=>'Overview'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10083113695138540380)
,p_plug_display_sequence=>50
,p_plug_new_grid_row=>false
,p_plug_grid_column_span=>9
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<table class="overview">',
'    <tr>',
'        <td><strong>KIM</strong></td>',
'        <td>Founder and runs the company</td>',
'    </tr>',
'    <tr>',
'        <td><strong>CHAZ</strong></td>',
'        <td>Leads Marketing and is <strong>RORY</strong>''s manager</td>',
'    </tr>',
'    <tr>',
'        <td><strong>GINA</strong></td>',
'        <td>Directs Editorial and mentors <strong>TINA</strong></td>',
'    </tr>',
'    <tr>',
'        <td><strong>PAT</strong></td>',
'        <td>Oversees Product Management and manages <strong>BO</strong> &amp; <strong>JANE</strong></td>',
'    </tr>',
'</table>'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3795094642260092)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(10083041896884540264)
,p_plug_display_sequence=>10
,p_plug_source=>'<p>You are not currently logged in. To login, select a user and click the (Login) button.</p>'
,p_plug_display_condition_type=>'USER_IS_PUBLIC_USER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3795184074260093)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(10083041896884540264)
,p_plug_display_sequence=>20
,p_plug_source=>'<p>You are currently logged in as &APP_USER.. To switch user, select a different user and click the (Login) button.</p>'
,p_plug_display_condition_type=>'USER_IS_NOT_PUBLIC_USER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3793881609260080)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(277183620620602)
,p_button_name=>'LOGIN'
,p_button_static_id=>'loginButton'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10083186892440540529)
,p_button_image_alt=>'Login'
,p_button_css_classes=>'margin-top-md'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3794061871260081)
,p_name=>'P11_SELECTED_USERNAME'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3794154668260082)
,p_name=>'P11_SELECTED_USERID'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(3794638624260087)
,p_computation_sequence=>10
,p_computation_item=>'P11_SELECTED_USERID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'from eba_demo_story_users',
'where username = :APP_USER'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3793740103260078)
,p_name=>'Expand Tree'
,p_event_sequence=>20
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3793774167260079)
,p_event_id=>wwv_flow_imp.id(3793740103260078)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_TREE_EXPAND'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(3996240652252128)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3794403578260085)
,p_name=>'When Node Changed'
,p_event_sequence=>30
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(3996240652252128)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_JSTREE|REGION TYPE|treeviewselectionchange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3794527924260086)
,p_event_id=>wwv_flow_imp.id(3794403578260085)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P11_SELECTED_USERNAME'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'apex.region("userTree").call("getSelectedNodes")[0]?.label'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3794970680260090)
,p_event_id=>wwv_flow_imp.id(3794403578260085)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Hide Login Button for Current User'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(3793881609260080)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P11_SELECTED_USERNAME'
,p_client_condition_expression=>'&APP_USER.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3794989443260091)
,p_event_id=>wwv_flow_imp.id(3794403578260085)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Show Login Button for Other User'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(3793881609260080)
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P11_SELECTED_USERNAME'
,p_client_condition_expression=>'&APP_USER.'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3794841317260089)
,p_event_id=>wwv_flow_imp.id(3794403578260085)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_name=>'Update Login Button Label'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(3793881609260080)
,p_attribute_01=>'$("#loginButton span").text(''Login as ''+$v(''P11_SELECTED_USERNAME''));'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3794682809260088)
,p_event_id=>wwv_flow_imp.id(3794403578260085)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'JQUERY_SELECTOR'
,p_affected_elements=>'#loginButton'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3795296937260094)
,p_name=>'Hide Login Button if Not Logged In'
,p_event_sequence=>40
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
,p_display_when_type=>'USER_IS_PUBLIC_USER'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3795426315260095)
,p_event_id=>wwv_flow_imp.id(3795296937260094)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(3793881609260080)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4039659069366707)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3793881609260080)
,p_internal_uid=>6202586365103832
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(4039974094366709)
,p_page_process_id=>wwv_flow_imp.id(4039659069366707)
,p_page_id=>11
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'lower( :P11_SELECTED_USERNAME )'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(4040504578366709)
,p_page_process_id=>wwv_flow_imp.id(4039659069366707)
,p_page_id=>11
,p_name=>'p_consent'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'STATIC'
,p_value=>'FALSE'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(4040937086368196)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3793881609260080)
,p_internal_uid=>6203864382105321
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(4041335454368196)
,p_page_process_id=>wwv_flow_imp.id(4040937086368196)
,p_page_id=>11
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'ITEM'
,p_value=>'P11_SELECTED_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(4041835224368197)
,p_page_process_id=>wwv_flow_imp.id(4040937086368196)
,p_page_id=>11
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>2
,p_value_type=>'NULL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(4042353135368197)
,p_page_process_id=>wwv_flow_imp.id(4040937086368196)
,p_page_id=>11
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>3
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp.component_end;
end;
/
