prompt --application/pages/page_00012
begin
--   Manifest
--     PAGE: 00012
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>12
,p_name=>'Email'
,p_alias=>'EMAIL'
,p_step_title=>'Email'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'17'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230827110438'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(326683666584785)
,p_plug_name=>'Page Title'
,p_plug_display_sequence=>10
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'- Email'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10384503215917885)
,p_plug_name=>'Info'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info:t-Alert--accessibleHeading'
,p_plug_template=>wwv_flow_imp.id(10083041896884540264)
,p_plug_display_sequence=>20
,p_plug_source=>'<p>Provide an email address to receive the task definition notification emails during the current session. Otherwise, the demo will use the email defined for the corresponding APEX User (e.g. <code>CHAZ</code>) if it exists. If neither email address '
||'is configured, then no notification emails will be sent.</p>'
,p_plug_display_condition_type=>'USER_IS_NOT_PUBLIC_USER'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(298354063029518)
,p_button_sequence=>40
,p_button_name=>'Save_Email'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10083186892440540529)
,p_button_image_alt=>'Save Email Override for Session'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(298230146029517)
,p_branch_name=>'Goto Stories'
,p_branch_action=>'f?p=&APP_ID.:9:&SESSION.::&DEBUG.:::&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'BEFORE_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(298453937029519)
,p_name=>'P12_OVERRIDE_EMAIL_ADDRESS'
,p_item_sequence=>30
,p_prompt=>'Override Notification Email Address'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(10083184482365540517)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
