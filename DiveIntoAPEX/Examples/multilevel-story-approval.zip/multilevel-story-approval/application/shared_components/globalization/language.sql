prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 29099
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
null;
wwv_flow_imp.component_end;
end;
/
