prompt --application/shared_components/user_interface/lovs/approvers
begin
--   Manifest
--     APPROVERS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(3793014683248300)
,p_lov_name=>'APPROVERS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select username',
'from',
'(',
'select 1 as kind, username from eba_demo_story_users',
'union all',
'select 2, ''#MANAGER1#'' from dual',
'union all',
'select 2, ''#MANAGER2#'' from dual',
'union all',
'select 2, ''#MANAGER3#'' from dual',
'union all',
'select 2, ''#MANAGER4#'' from dual',
'union all',
'select 3, ''#''||e.name||''#''',
'from eba_demo_story_department e',
')',
'order by kind,username'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'USERNAME'
,p_display_column_name=>'USERNAME'
);
wwv_flow_imp.component_end;
end;
/
