prompt --application/shared_components/workflow/task_definitions/story_approval
begin
--   Manifest
--     TASK_DEF: Story Approval
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_task_def(
 p_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Story Approval'
,p_static_id=>'STORY_APPROVAL'
,p_subject=>'&SUBJECT.'
,p_priority=>3
,p_expiration_policy=>'NONE'
,p_max_renewal_count=>3
,p_details_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.:RP,3:P3_TASK_ID:&TASK_ID.'
,p_actions_sql_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select stp.approver   as approvers,',
'       case ',
'            when :P_APPROVAL_STEP = :P_TOTAL_STEPS',
'            then ''Y'' ',
'            else ''N'' ',
'       end            as is_final_approval, ',
'       sty.name       as story_title,',
'       sty.created_by as story_author,',
'       coalesce(:P12_OVERRIDE_EMAIL_ADDRESS,styusr.email)   as story_author_email,',
'       (select listagg(coalesce(:P12_OVERRIDE_EMAIL_ADDRESS,aprusr.email),'','')',
'          from apex_task_participants apr',
'          left outer join apex_workspace_apex_users aprusr on aprusr.user_name = apr.participant',
'         where apr.participant_type = ''POTENTIAL_OWNER''',
'           and apr.task_id = :APEX$TASK_ID  ',
'           and aprusr.email is not null) as approvers_email,',
'       coalesce(:P12_OVERRIDE_EMAIL_ADDRESS,ownusr.email) as task_owner_email',
'from eba_demo_story sty',
'left join eba_demo_story_appr_steps stp on stp.story_id = sty.id',
'left outer join apex_workspace_apex_users styusr on styusr.user_name = sty.created_by',
'left outer join apex_workspace_apex_users ownusr on ownusr.user_name = :APEX$TASK_OWNER',
'where stp.story_id = :APEX$TASK_PK',
'and   stp.step     = :P_APPROVAL_STEP'))
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(2986696781899219)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_label=>'Total Approval Steps'
,p_static_id=>'P_TOTAL_STEPS'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(10082926063591683516)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_label=>'Potential Owners'
,p_static_id=>'P_POTENTIAL_OWNERS'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_param(
 p_id=>wwv_flow_imp.id(10082926434447683515)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_label=>'Approval Step'
,p_static_id=>'P_APPROVAL_STEP'
,p_data_type=>'VARCHAR2'
,p_is_required=>true
,p_is_visible=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(1292032848798206)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Notify Story Author That More Info Requested'
,p_execution_sequence=>70
,p_on_event=>'REQUEST_INFO'
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&STORY_AUTHOR_EMAIL.'
,p_attribute_06=>'More Info Requested on "&STORY_TITLE."'
,p_attribute_07=>'Hi &STORY_AUTHOR., please check your "My Story Approvals" page as &APEX$TASK_OWNER. has requested more information about your story "&STORY_TITLE."'
,p_attribute_08=>'<p>Hi &STORY_AUTHOR., please check your <em>My Story Approvals</em> page as &APEX$TASK_OWNER. has requested more information about your story "&STORY_TITLE."</p>'
,p_attribute_10=>'N'
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'STORY_AUTHOR_EMAIL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(1292548974811135)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Demo Purposes - Request Info - Push Mail Queue'
,p_execution_sequence=>80
,p_on_event=>'REQUEST_INFO'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'apex_mail.push_queue;'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'STORY_AUTHOR_EMAIL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(1293854344854661)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Notify Approver More Info Provided'
,p_execution_sequence=>90
,p_on_event=>'SUBMIT_INFO'
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&TASK_OWNER_EMAIL.'
,p_attribute_06=>'&STORY_AUTHOR. Provided More Info for "&STORY_TITLE."'
,p_attribute_07=>'Hi &APEX$TASK_OWNER., please check your "Approvals" page again to review "&STORY_TITLE." for approval. &STORY_AUTHOR. has provided the additional info you requested.'
,p_attribute_08=>'<p>Hi &APEX$TASK_OWNER., please check your <em>Approvals</em> page again to review "&STORY_TITLE." for approval. &STORY_AUTHOR. has provided the additional info you requested.</p>'
,p_attribute_10=>'N'
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'TASK_OWNER_EMAIL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(1294185788858383)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Demo Purposes - Submit Info - Push Mail Queue'
,p_execution_sequence=>100
,p_on_event=>'SUBMIT_INFO'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'apex_mail.push_queue;'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'TASK_OWNER_EMAIL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(3398867822395757)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Demo Purposes - Create - Push Mail Queue'
,p_execution_sequence=>50
,p_on_event=>'CREATE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'apex_mail.push_queue;'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'APPROVER_EMAILS'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(3399480382408212)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Demo Purposes - Complete - Push Mail Queue'
,p_execution_sequence=>60
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'apex_mail.push_queue;'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':IS_FINAL_APPROVAL = ''Y'' and :STORY_AUTHOR_EMAIL is not null'
,p_condition_expr2=>'PLSQL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(10082983825813011231)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Send Final Approval Email If Appropriate'
,p_execution_sequence=>40
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&STORY_AUTHOR_EMAIL.'
,p_attribute_06=>'"&STORY_TITLE." Approved'
,p_attribute_07=>'Hi &STORY_AUTHOR., your story "&STORY_TITLE." has received final approval.'
,p_attribute_08=>'<p>Hi &STORY_AUTHOR., your story "&STORY_TITLE." has received final approval.</p>'
,p_attribute_10=>'N'
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'EXPRESSION'
,p_condition_expr1=>':IS_FINAL_APPROVAL = ''Y'' and :STORY_AUTHOR_EMAIL is not null'
,p_condition_expr2=>'PLSQL'
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(10083430225522108729)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Handle Approval'
,p_execution_sequence=>10
,p_outcome=>'APPROVED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'eba_demo_story_approvals.handle_approval(:APEX$TASK_ID);'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(10083430785126112077)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Handle Rejection'
,p_execution_sequence=>20
,p_outcome=>'REJECTED'
,p_on_event=>'COMPLETE'
,p_action_type=>'NATIVE_PLSQL'
,p_action_clob=>'eba_demo_story_approvals.handle_rejection(:APEX$TASK_ID);'
,p_action_clob_language=>'PLSQL'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
);
wwv_flow_imp_shared.create_task_def_action(
 p_id=>wwv_flow_imp.id(10083508581632168778)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_name=>'Email to Approver'
,p_execution_sequence=>30
,p_on_event=>'CREATE'
,p_action_type=>'NATIVE_SEND_EMAIL'
,p_attribute_01=>'&APP_EMAIL.'
,p_attribute_02=>'&APPROVERS_EMAILS.'
,p_attribute_06=>'&APEX$TASK_SUBJECT.'
,p_attribute_07=>'Hello, &APEX$TASK_OWNER., please review the story "&STORY_TITLE." for approval.'
,p_attribute_08=>'<p>Hello, &APPROVERS. please review the story "&STORY_TITLE." for approval.</p>'
,p_attribute_10=>'N'
,p_attribute_14=>'HTML'
,p_location=>'LOCAL'
,p_stop_execution_on_error=>true
,p_condition_type=>'ITEM_IS_NOT_NULL'
,p_condition_expr1=>'APPROVER_EMAILS'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(10083326038166652517)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_participant_type=>'POTENTIAL_OWNER'
,p_identity_type=>'USER'
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':P_POTENTIAL_OWNERS'
);
wwv_flow_imp_shared.create_task_def_participant(
 p_id=>wwv_flow_imp.id(10083326345186652520)
,p_task_def_id=>wwv_flow_imp.id(10082924807260694255)
,p_participant_type=>'BUSINESS_ADMIN'
,p_identity_type=>'USER'
,p_value_type=>'STATIC'
,p_value=>'PAT'
);
wwv_flow_imp.component_end;
end;
/
