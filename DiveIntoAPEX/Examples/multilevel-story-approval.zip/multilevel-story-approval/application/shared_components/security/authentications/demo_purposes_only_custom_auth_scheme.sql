prompt --application/shared_components/security/authentications/demo_purposes_only_custom_auth_scheme
begin
--   Manifest
--     AUTHENTICATION: Demo Purposes Only Custom Auth Scheme
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(3989377562226970)
,p_name=>'Demo Purposes Only Custom Auth Scheme'
,p_scheme_type=>'NATIVE_CUSTOM'
,p_attribute_03=>'is_authenticated_for_demo'
,p_attribute_05=>'N'
,p_plsql_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'--===========================================================',
'-- Return true for any username in eba_demo_story_users table',
'--===========================================================',
'',
'function is_authenticated_for_demo(',
'    p_username in varchar2,',
'    p_password in varchar2)',
'    return        boolean',
'is',
'begin',
'    for j in (select username ',
'                from eba_demo_story_users',
'               where upper(username) = upper(p_username)) loop',
'       return true;',
'    end loop;',
'    return false; ',
'end;'))
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
);
wwv_flow_imp.component_end;
end;
/
