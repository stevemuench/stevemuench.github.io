prompt --application/shared_components/files/icons_app_icon_32_png
begin
--   Manifest
--     APP STATIC FILES: 29099
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200806000000737A7AF4000000017352474200AECE1CE9000000E1494441545847633C1531F73FC30002C651078C86C068080C99106051E267E05016C25962DC3B709981E9D31F06114E01924A';
wwv_flow_imp.g_varchar2_table(2) := '15A2CB011E574506453F639C869F6DDF0496FB74F715498EA0AA03A4D4E5199EDD7C489223A8E680E7FBAE333C3B791B1C0AF7AEDC66D01092272A2AA8E60064DBEE6F3ACBF065F77DDA3BE0E3AD170CFC6A121816D1C501204B40009430616C210D69B0';
wwv_flow_imp.g_varchar2_table(3) := '8368EA00986530CB4134BA184D1D00B21057D0C3E282E60E2094BAE8E680D144082B9A4713217AA2A4492224541D233BE2C1A6F344D78844D70584B21EB9F2A30E180D81D11018F0100000EC68DDE18C0ACB690000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10083295858660540904)
,p_file_name=>'icons/app-icon-32.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
