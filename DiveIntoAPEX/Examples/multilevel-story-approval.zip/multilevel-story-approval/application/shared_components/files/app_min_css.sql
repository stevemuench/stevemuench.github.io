prompt --application/shared_components/files/app_min_css
begin
--   Manifest
--     APP STATIC FILES: 29099
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>29099
,p_default_id_offset=>6259155968026763
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '74642E612D4952522D6C696E6B436F6C2C746823612D4952522D6865616465722D2D6C696E6B436F6C7B77696474683A36656D3B746578742D616C69676E3A63656E74657221696D706F7274616E747D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(3385793487688710)
,p_file_name=>'app.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
