prompt --application/deployment/install/install_droptablebeforecreatingit
begin
--   Manifest
--     INSTALL: INSTALL-DropTableBeforeCreatingIt
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(11937367686125741)
,p_install_id=>wwv_flow_imp.id(10679766600707149)
,p_name=>'DropTableBeforeCreatingIt'
,p_sequence=>7
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    table_does_not_exist exception;',
'    pragma exception_init(table_does_not_exist,-942);',
'begin',
'  execute immediate ''drop table eba_demo_reg_data_requests'';',
'exception',
'    when table_does_not_exist then',
'        null;',
'end;',
'/ '))
);
wwv_flow_imp.component_end;
end;
/
