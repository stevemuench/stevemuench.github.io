prompt --application/deployment/install/install_installrequeststable
begin
--   Manifest
--     INSTALL: INSTALL-InstallRequestsTable
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.2'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10923605191471254)
,p_install_id=>wwv_flow_imp.id(10679766600707149)
,p_name=>'InstallRequestsTable'
,p_sequence=>15
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE TABLE "EBA_DEMO_REG_DATA_REQUESTS" ',
'   (	"ID" NUMBER DEFAULT ON NULL to_number(sys_guid(), ''XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX'') NOT NULL ENABLE, ',
'	"APP_ID" NUMBER, ',
'	"PAGE_ID" NUMBER, ',
'	"REGION_STATIC_ID" VARCHAR2(255 CHAR), ',
'	"XML_DESCRIBE" "XMLTYPE", ',
'	"CREATED" DATE NOT NULL ENABLE, ',
'	"CREATED_BY" VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	"UPDATED" DATE NOT NULL ENABLE, ',
'	"UPDATED_BY" VARCHAR2(255 CHAR) NOT NULL ENABLE, ',
'	"BASENAME" VARCHAR2(25), ',
'	"INCLUDE_COLUMNS" VARCHAR2(4000), ',
'	"READY" VARCHAR2(1), ',
'	"GENERATE_REQUESTED_ON" DATE, ',
'	 CONSTRAINT "EBA_DEMO_REG_DATA_ID_PK" PRIMARY KEY ("ID")',
'  USING INDEX  ENABLE',
'   ) ;',
'',
'CREATE OR REPLACE EDITIONABLE TRIGGER "EBA_DEMO_REG_DATA_REQUESTS_BIU" ',
'    before insert or update ',
'    on eba_demo_reg_data_requests',
'    for each row',
'begin',
'    if inserting then',
'        :new.created := sysdate;',
'        :new.created_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'    end if;',
'    :new.updated := sysdate;',
'    :new.updated_by := coalesce(sys_context(''APEX$SESSION'',''APP_USER''),user);',
'end eba_demo_reg_data_requests_biu;',
'',
'/',
'',
'',
'ALTER TRIGGER "EBA_DEMO_REG_DATA_REQUESTS_BIU" ENABLE;',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(10923771086471254)
,p_script_id=>wwv_flow_imp.id(10923605191471254)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TABLE'
,p_object_name=>'EBA_DEMO_REG_DATA_REQUESTS'
,p_last_updated_by=>'STEVE'
,p_last_updated_on=>to_date('20230117214914','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE'
,p_created_on=>to_date('20230117214914','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(11168756706315268)
,p_script_id=>wwv_flow_imp.id(10923605191471254)
,p_object_owner=>'#OWNER#'
,p_object_type=>'TRIGGER'
,p_object_name=>'EBA_DEMO_REG_DATA_REQUESTS_BIU'
,p_last_updated_by=>'STEVE'
,p_last_updated_on=>to_date('20230118111634','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE'
,p_created_on=>to_date('20230118111634','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
