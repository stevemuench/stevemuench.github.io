prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Region Data Sharing Helper'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// Make APEX messages auto-dismiss after 3 secs',
'apex.theme42.util.configAPEXMsgs({',
'    autoDismiss: true,',
'    duration: 3000',
'});'))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230123110407'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10356235118721923)
,p_plug_name=>'Instructions'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:is-collapsed:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10521539983706035)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_grid_column_css_classes=>'margin-bottom-md'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Choose a region whose filtered results you want to share with other',
'    regions in the same app. The region must have a static id configured',
'    and be based on a Local DB, REST Enabled SQL, or REST Source.',
'    Only applications with at least one qualifying region appear.',
'    Click <I>Add Region</I> to add it to the list of selected regions below.',
'    Once the status of a selected region is <i>Ready</i>, you can adjust',
'    the base name and included columns and save any changes. If you change',
'    the columns exposed in a selected region, you can click <i>Regenerate</i> to',
'    refresh the set of available columns to choose from. Finally, ',
'    click the download button to get a zip file containing',
'    the generated SQL scripts and a README file explaining what they are',
'    and how to use them. When you no longer anticipate needing to download',
'    data sharing artifacts for a selected region, you can remove it from',
'    the list of selected ones. This simply removes its name from a table',
'    related to this helper app.',
'</p>',
'<p>',
'    See blogs articles like <a target="_blank" ',
'    href="https://blogs.oracle.com/apex/post/add-a-chart-to-your-faceted-search-page">Add',
'    a Chart to your Faceted Search Page</a> and <a target="_blank" ',
'    href="https://diveintoapex.com/2023/01/16/refitting-filtered-map-points/">Refitting',
'    Filtered Map Points</a> for more background on the region',
'    data sharing technique the generated pipeline function enables.',
'</p>'))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10357354405721934)
,p_plug_name=>'Choose a Region...'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10568676669706058)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10358410264721945)
,p_plug_name=>'Selected Regions'
,p_region_css_classes=>' w100p'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10568676669706058)
,p_plug_display_sequence=>60
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_REG_DATA_REQUESTS'
,p_query_order_by=>'generate_requested_on desc'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id ',
'  from eba_demo_reg_data_requests',
'fetch first row only'))
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11886222391458907)
,p_plug_name=>'Selected Regions'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(10568676669706058)
,p_plug_display_sequence=>50
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source=>'<center>You have not yet selected any regions to generate data sharing artifacts for...</center>'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'NOT_EXISTS'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id ',
'  from eba_demo_reg_data_requests',
'fetch first row only'))
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10355097565721911)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10357354405721934)
,p_button_name=>'ADD_REGION'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10641567990706097)
,p_button_image_alt=>'Add Region'
,p_button_execute_validations=>'N'
,p_grid_column_css_classes=>'u-align-self-center'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
,p_grid_column_span=>1
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11835035219715733)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10357354405721934)
,p_button_name=>'REGENERATE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10641567990706097)
,p_button_image_alt=>'Regenerate'
,p_button_execute_validations=>'N'
,p_grid_new_row=>'N'
,p_grid_new_column=>'N'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11173414882436432)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'DOWNLOAD'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Download'
,p_button_position=>'COPY'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.:APPLICATION_PROCESS=GENERATE_ARTIFACTS:&DEBUG.::REQUEST_ID:&P1_ID.'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_STATUS'
,p_button_condition2=>'Ready'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-download'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11262833577347334)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'REFRESH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Refresh'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_STATUS'
,p_button_condition2=>'Ready'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_NOT_EQ_COND2'
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-refresh'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11260439714347310)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'PREVIOUS'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Previous'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_PREVIOUS_REQUEST_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-angle-left'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11260359129347309)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'NEXT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Next'
,p_button_position=>'COPY'
,p_button_condition=>'P1_NEXT_REQUEST_ID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-angle-right'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11261028012347316)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'SAVE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Save'
,p_button_position=>'COPY'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P1_STATUS'
,p_button_condition2=>'Ready'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-save'
,p_database_action=>'UPDATE'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11260630305347312)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_button_name=>'DELETE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(10640802259706096)
,p_button_image_alt=>'Delete'
,p_button_position=>'COPY'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_button_css_classes=>'margin-left-sm margin-right-sm'
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(11260798144347313)
,p_branch_name=>'Handle Previous'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P1_ID:&P1_PREVIOUS_REQUEST_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(11260439714347310)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(11260806531347314)
,p_branch_name=>'Handle Next'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P1_ID:&P1_NEXT_REQUEST_ID.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(11260359129347309)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10355962958721920)
,p_name=>'P1_APPLICATION'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10357354405721934)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.application_id',
'from apex_applications a',
'where a.application_id != :APP_ID',
'and exists (select null',
'              from apex_application_page_regions r',
'             where r.application_id = a.application_id',
'               and r.static_id is not null',
'               and r.location in (''Local Database'',',
'                                   ''Remote Database'',',
'                                   ''Web Source''))',
'order by a.application_name',
'fetch first row only'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Application'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.application_name||'' (''||a.application_id||'')'' as name,',
'       a.application_id',
'from apex_applications a',
'where a.application_id != :APP_ID',
'and exists (select null',
'              from apex_application_page_regions r',
'             where r.application_id = a.application_id',
'               and r.static_id is not null',
'               and r.location in (''Local Database'',',
'                                   ''Remote Database'',',
'                                   ''Web Source''))',
'order by a.application_name'))
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10356021137721921)
,p_name=>'P1_PAGE'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10357354405721934)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select p.page_id',
'from apex_application_pages p',
'where p.application_id = :P1_APPLICATION',
'and p.page_function not in (''Global Page'',''Login'')',
'and exists (select null',
'              from apex_application_page_regions r',
'             where r.application_id = p.application_id',
'               and r.page_id = p.page_id',
'               and r.static_id is not null',
'               and r.location in (''Local Database'',',
'                                   ''Remote Database'',',
'                                   ''Web Source''))',
'order by p.page_id',
'fetch first row only'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Page'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select page_name||'' (''||page_id||'')'' as name, page_id',
'from apex_application_pages p',
'where p.application_id = :P1_APPLICATION',
'and p.page_function not in (''Global Page'',''Login'')',
'and exists (select null',
'              from apex_application_page_regions r',
'             where r.application_id = p.application_id',
'               and r.page_id = p.page_id',
'               and r.static_id is not null',
'               and r.location in (''Local Database'',',
'                                   ''Remote Database'',',
'                                   ''Web Source''))',
'order by p.page_id'))
,p_lov_cascade_parent_items=>'P1_APPLICATION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10356129104721922)
,p_name=>'P1_REGION'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10357354405721934)
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select static_id',
'from apex_application_page_regions',
'where application_id = :P1_APPLICATION',
'and page_id = :P1_PAGE',
'and static_id is not null',
'and location in (''Local Database'',',
'                 ''Remote Database'',',
'                 ''Web Source'')',
'order by region_name',
'fetch first row only'))
,p_item_default_type=>'SQL_QUERY'
,p_prompt=>'Region'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select region_name||'' [''||source_type||'']'', static_id',
'from apex_application_page_regions',
'where application_id = :P1_APPLICATION',
'and page_id = :P1_PAGE',
'and static_id is not null',
'and location in (''Local Database'',',
'                 ''Remote Database'',',
'                 ''Web Source'')',
'order by region_name'))
,p_lov_cascade_parent_items=>'P1_PAGE'
,p_ajax_items_to_submit=>'P1_APPLICATION'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'NONE'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11171781243436415)
,p_name=>'P1_INCLUDE_COLUMNS'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_source_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_prompt=>'Include Columns'
,p_source=>'INCLUDE_COLUMNS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SHUTTLE'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select x.name,',
'       x.seq',
'from eba_demo_reg_data_requests r,',
'xmltable(''/ROWSET/ROW'' passing r.xml_describe',
'              columns',
'               seq for ordinality,',
'               name varchar2(255) path ''NAME'',',
'               data_type varchar2(80) path ''DATA_TYPE'',',
'               declared_size number path ''DECLARED_SIZE''',
') x',
'where r.id = :P1_ID',
'order by x.seq'))
,p_lov_cascade_parent_items=>'P1_ID'
,p_ajax_optimize_refresh=>'Y'
,p_cHeight=>10
,p_display_when=>'P1_STATUS'
,p_display_when2=>'Ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(10639853791706095)
,p_item_template_options=>'#DEFAULT#:t-Form-fieldContainer--stretchInputs:t-Form-fieldContainer--indicatorLabel:t-Form-fieldContainer--xlarge'
,p_is_persistent=>'N'
,p_lov_display_extra=>'NO'
,p_attribute_01=>'MOVE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11172064006436418)
,p_name=>'P1_ID'
,p_source_data_type=>'NUMBER'
,p_is_primary_key=>true
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_source_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11173813124436436)
,p_name=>'P1_NEXT_REQUEST_ID'
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11173983286436437)
,p_name=>'P1_PREVIOUS_REQUEST_ID'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11174023881436438)
,p_name=>'P1_REQUEST_COUNT'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_display_point=>'EDIT'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11260195615347307)
,p_name=>'P1_BASENAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_source_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_prompt=>'Base Name'
,p_source=>'BASENAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>25
,p_begin_on_new_line=>'N'
,p_display_when=>'P1_STATUS'
,p_display_when2=>'Ready'
,p_display_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_field_template=>wwv_flow_imp.id(10640370833706095)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'  This is the base name that will be used when generating the',
'  object type (<tt><i>basename</i>_row</tt>), table type (<tt><i>basename</i>_tab</tt>),',
'  and pipelined function (<tt><i>basename</i>_data</tt>). It can be up to 25 ',
'  characters long.',
'</p>'))
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11262299013347328)
,p_name=>'P1_STATUS'
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_prompt=>'Status'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11262311945347329)
,p_name=>'P1_NAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_display_point=>'EDIT'
,p_prompt=>'Region'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11262416036347330)
,p_name=>'P1_GENERATED'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_prompt=>'Generated'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(10639094625706094)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11262507477347331)
,p_name=>'P1_GENERATE_REQUESTED_ON'
,p_source_data_type=>'DATE'
,p_is_query_only=>true
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_item_source_plug_id=>wwv_flow_imp.id(10358410264721945)
,p_source=>'GENERATE_REQUESTED_ON'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11834868851715731)
,p_name=>'P1_SUCCESS_MESSAGE'
,p_item_sequence=>70
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11836765831715750)
,p_name=>'P1_REGION_IN_SELECTED_LIST'
,p_item_sequence=>80
,p_item_default=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with region_in_selected_list as (',
'    select max(id) as id ',
'      from eba_demo_reg_data_requests',
'     where app_id = :P1_APPLICATION',
'       and page_id = :P1_PAGE',
'       and region_static_id = :P1_REGION',
')',
'select case ',
'         when x.id is null then ''N'' ',
'         else ''Y'' end',
'from region_in_selected_list x',
''))
,p_item_default_type=>'SQL_QUERY'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(11174240490436440)
,p_computation_sequence=>10
,p_computation_item=>'P1_ID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'from eba_demo_reg_data_requests',
'order by created desc',
'fetch first row only'))
,p_compute_when=>'P1_ID'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(11263216959347338)
,p_validation_name=>'Enforce Legal Base Name'
,p_validation_sequence=>10
,p_validation=>':P1_BASENAME = substr(nvl(regexp_replace(:P1_BASENAME,''[^a-zA-Z0-9_]|^[0-9]'',''''),''X''),1,25)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Base name must start with a letter, contain only letters, numbers, and underscores, and be 25 characters or less. '
,p_always_execute=>'Y'
,p_associated_item=>wwv_flow_imp.id(11260195615347307)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11885697657458901)
,p_name=>'When Region Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_REGION'
,p_condition_element=>'P1_REGION'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11885752519458902)
,p_event_id=>wwv_flow_imp.id(11885697657458901)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'with region_in_selected_list as (',
'    select max(id) as id ',
'      from eba_demo_reg_data_requests',
'     where app_id = :P1_APPLICATION',
'       and page_id = :P1_PAGE',
'       and region_static_id = :P1_REGION',
')',
'select case ',
'         when x.id is null then ''N'' ',
'         else ''Y'' end',
'into :P1_REGION_IN_SELECTED_LIST',
'from region_in_selected_list x;'))
,p_attribute_02=>'P1_APPLICATION,P1_PAGE,P1_REGION'
,p_attribute_03=>'P1_REGION_IN_SELECTED_LIST'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11885824144458903)
,p_event_id=>wwv_flow_imp.id(11885697657458901)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_name=>'Selected? > Show REGENERATE'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11835035219715733)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P1_REGION_IN_SELECTED_LIST'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11885996161458904)
,p_event_id=>wwv_flow_imp.id(11885697657458901)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Selected? > Hide ADD_REGION'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10355097565721911)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P1_REGION_IN_SELECTED_LIST'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11886054292458905)
,p_event_id=>wwv_flow_imp.id(11885697657458901)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'Y'
,p_name=>'!Selected > Show ADD_REGION'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10355097565721911)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P1_REGION_IN_SELECTED_LIST'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11886131377458906)
,p_event_id=>wwv_flow_imp.id(11885697657458901)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'Y'
,p_name=>'!Selected > Hide REGENERATE'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11835035219715733)
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P1_REGION_IN_SELECTED_LIST'
,p_client_condition_expression=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11886471312458909)
,p_name=>'When Basename Changed'
,p_event_sequence=>20
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_BASENAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11886540956458910)
,p_event_id=>wwv_flow_imp.id(11886471312458909)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Hide Download Button'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11173414882436432)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11886680390458911)
,p_name=>'When Columns Changed'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_INCLUDE_COLUMNS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11886744002458912)
,p_event_id=>wwv_flow_imp.id(11886680390458911)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Hide Download Button'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11173414882436432)
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11834912559715732)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Customize Success Message'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P1_SUCCESS_MESSAGE := ''Selected region ''||case  ',
'when :REQUEST = ''DELETE'' then ''removed''',
'when :REQUEST in (''SAVE'',''NEXT'',''PREVIOUS'') then ''updated''',
'end||''.'';'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>':REQUEST in (''SAVE'',''NEXT'',''PREVIOUS'',''DELETE'') '
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11260585294347311)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_region_id=>wwv_flow_imp.id(10358410264721945)
,p_process_type=>'NATIVE_FORM_DML'
,p_process_name=>'Process form Region Data Sharing Generation Requests'
,p_attribute_01=>'REGION_SOURCE'
,p_attribute_05=>'Y'
,p_attribute_06=>'Y'
,p_attribute_08=>'Y'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'&P1_SUCCESS_MESSAGE.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11262648678347332)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear Out Deleted Row'
,p_process_sql_clob=>':P1_ID := null;'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'DELETE'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12158751724191616)
,p_process_sequence=>50
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sync Lists to Next Row'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select app_id, page_id, region_static_id',
'into :P1_APPLICATION, :P1_PAGE, :P1_REGION',
'from eba_demo_reg_data_requests',
'where id = :P1_NEXT_REQUEST_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'NEXT'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(12158874502191617)
,p_process_sequence=>60
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Sync Lists to Previous Row'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select app_id, page_id, region_static_id',
'into :P1_APPLICATION, :P1_PAGE, :P1_REGION',
'from eba_demo_reg_data_requests',
'where id = :P1_PREVIOUS_REQUEST_ID;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'PREVIOUS'
,p_process_when_type=>'REQUEST_EQUALS_CONDITION'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11262067436347326)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Retrieve Extra Info'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ',
'       a.application_name||'' (''||a.application_id||'') > ''||',
'       p.page_name||'' (''||p.page_id||'') > ''||',
'       r.region_name||'' [''||r.source_type||'']'' as name,',
'       case ready',
'        when ''Y'' then ''Ready'' ',
'        else ''Working (Click Refresh to try again...)''',
'        end as status,',
'        apex_util.get_since(updated) generated',
'into :P1_NAME,',
'     :P1_STATUS,',
'     :P1_GENERATED',
'from eba_demo_reg_data_requests q',
'left join apex_applications a ',
'       on a.application_id = q.app_id',
'left join apex_application_pages p ',
'       on p.application_id = q.app_id ',
'      and p.page_id = q.page_id',
'left join apex_application_page_regions r',
'       on r.static_id = q.region_static_id',
'      and r.application_id = q.app_id',
'      and r.page_id = q.page_id',
'where id = :P1_ID;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>'P1_ID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11174305087436441)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(10358410264721945)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize Form'
,p_attribute_01=>'P1_NEXT_REQUEST_ID'
,p_attribute_02=>'P1_PREVIOUS_REQUEST_ID'
,p_attribute_03=>'P1_REQUEST_COUNT'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10356674765721927)
,p_process_sequence=>10
,p_process_point=>'ON_SUBMIT_BEFORE_COMPUTATION'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Add Region to Selected List'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_DEMO_REGION_DATA_SHARING'
,p_attribute_04=>'ADD_REGION_TO_SELECTED_LIST'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'ADD_REGION,REGENERATE'
,p_process_when_type=>'REQUEST_IN_CONDITION'
);
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10356761233721928)
,p_page_process_id=>wwv_flow_imp.id(10356674765721927)
,p_page_id=>1
,p_name=>'p_app_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_APPLICATION'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10356883209721929)
,p_page_process_id=>wwv_flow_imp.id(10356674765721927)
,p_page_id=>1
,p_name=>'p_page_id'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P1_PAGE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10356943500721930)
,p_page_process_id=>wwv_flow_imp.id(10356674765721927)
,p_page_id=>1
,p_name=>'p_region_static_id'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P1_REGION'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11886340177458908)
,p_page_process_id=>wwv_flow_imp.id(10356674765721927)
,p_page_id=>1
,p_direction=>'OUT'
,p_data_type=>'NUMBER'
,p_ignore_output=>false
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P1_ID'
);
wwv_flow_imp.component_end;
end;
/
