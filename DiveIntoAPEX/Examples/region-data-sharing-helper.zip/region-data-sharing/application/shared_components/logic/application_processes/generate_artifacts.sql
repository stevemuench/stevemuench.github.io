prompt --application/shared_components/logic/application_processes/generate_artifacts
begin
--   Manifest
--     APPLICATION PROCESS: GENERATE_ARTIFACTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>101010101010101010101010
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'WKSP_APEXAPPS'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(11214493676046293)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GENERATE_ARTIFACTS'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_bind_vars apex_application.vc_assoc_arr;',
'    l_region_static_id varchar2(128);',
'    l_basename         varchar2(128);',
'    l_app_id           number;',
'    l_page_id          number;',
'    l_generated_at     varchar2(25);',
'begin',
'    l_bind_vars(''id'') := :REQUEST_ID;',
'    select basename,',
'           region_static_id,',
'           page_id,',
'           app_id,',
'           to_char(localtimestamp,''DD-MON-YYYY HH24:MI:SS'')',
'    into l_basename, ',
'         l_region_static_id,',
'         l_page_id,',
'         l_app_id,',
'         l_generated_at',
'    from eba_demo_reg_data_requests',
'    where id = to_number(:REQUEST_ID);',
'    l_bind_vars(''appid'') := l_app_id;',
'    l_bind_vars(''basename'') := l_basename;',
'    l_bind_vars(''regionstaticid'') := l_region_static_id;',
'    l_bind_vars(''pageid'') := l_page_id;',
'    l_bind_vars(''generatedat'') := l_generated_at;           ',
'    eba_demo_transform_group.download(',
'         p_file_name    => ''generate-data-sharing-artifacts.xml'', ',
'         p_zipfile_name => l_basename||''-region-data-sharing-artifacts.zip'',',
'         p_bind_vars => l_bind_vars);',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
);
wwv_flow_imp.component_end;
end;
/
