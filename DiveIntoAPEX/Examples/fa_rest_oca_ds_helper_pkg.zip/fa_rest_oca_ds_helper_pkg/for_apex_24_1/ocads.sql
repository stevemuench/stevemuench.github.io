create or replace package oca_ds as
--------------------------------------------------------------------------------
--
--  Copyright (c) 2023, Oracle and/or its affiliates.
--
--    NAME
--      adfbc_ocads.sql
--
--    DESCRIPTION
--      Helper routines to simplify writing tests against ADF REST data sources
--
--    MODIFIED   (MM/DD/YYYY)
--    smuench     11/23/2023 - Created
--------------------------------------------------------------------------------
    c_star constant varchar2(1) := '*';

    function open_query(
        p_from                in varchar2,
        p_select              in varchar2                               default c_star,
        p_where               in varchar2                               default null,
        p_order_by            in varchar2                               default null,
        p_first_row           in number                                 default null,
        p_max_rows            in number                                 default null,
        p_resource_key        in varchar2                               default null,
        p_parameters          in apex_exec.t_parameters         default apex_exec.c_empty_parameters,
        p_filters             in apex_exec.t_filters            default apex_exec.c_empty_filters,
        p_order_bys           in apex_exec.t_order_bys          default apex_exec.c_empty_order_bys,
        p_row_search          in varchar2                               default null,
        p_row_search_behavior in apex_exec.t_filter_combination default apex_exec.c_filter_combination_and,
        p_app_id              in number                                 default nv('APP_ID'))
        return                   apex_exec.t_context;
    --
    function open_dml(
        p_from                  in varchar2,
        p_attributes            in varchar2                       default c_star,
        p_lost_update_detection in boolean                        default false,
        p_row_version_attr      in varchar2                       default null,
        p_parameters            in apex_exec.t_parameters default apex_exec.c_empty_parameters,
        p_app_id                in number                         default nv('APP_ID'))
        return         apex_exec.t_context;
    --
    procedure insert_row(
        p_context in apex_exec.t_context);
    --
    procedure update_row(
        p_context in apex_exec.t_context);
    --
    procedure delete_row(
        p_context in apex_exec.t_context);
    --
    procedure close(
        p_context in apex_exec.t_context);
    --
    function get_varchar2(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        varchar2;
    --
    function get_boolean(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        boolean;
    --
    function get_clob(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        clob;
    --
    function get_number(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        number;
    --
    function get_date(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        date;
    --
    function get_timestamp(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        timestamp;
    --
    function get_timestamp_tz(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        timestamp with time zone;
    --
    function get_timestamp_ltz(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2)
        return        timestamp with local time zone;
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in varchar2);
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in number);
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in date);
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in timestamp);
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in timestamp with time zone);
    --
    procedure set_value(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2,
        p_value    in timestamp with local time zone);

    procedure open_array(
        p_context  in apex_exec.t_context,
        p_attrname in varchar2);
    --
    procedure close_array(
        p_context  in apex_exec.t_context);
    -- 
    procedure add_dml_array_row(
        p_context in apex_exec.t_context,
        p_attrname in varchar2 default null,
        p_operation in apex_exec.t_dml_operation default null);
end oca_ds;
/
