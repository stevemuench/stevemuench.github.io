prompt --application/deployment/install/install_upsert_staff
begin
--   Manifest
--     INSTALL: INSTALL-Upsert Staff
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10686731332039465)
,p_install_id=>wwv_flow_imp.id(661840070432022836)
,p_name=>'Upsert Staff'
,p_sequence=>15
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'merge into eba_demo_staff tgt',
'using (',
'    with x as (',
'        select aaf.blob_content ',
'          from apex_application_files aaf, ',
'               apex_applications aa',
'         where aa.application_id = ',
'                    coalesce(',
'                        apex_application_install.get_application_id,',
'                        to_number(v(''APP_ID'')))',
'           and aaf.flow_id = aa.application_id',
'           and aaf.filename = ''staff.json''',
'    )',
'    select y.name',
'    from x,',
'         json_table(x.blob_content, ''$.staff[*]'' columns',
'        (',
'            name     varchar2(255) path ''$.NAME''',
'        )) y',
') src',
'on (tgt.name = src.name)',
'when not matched then',
'    insert (name)',
'    values (src.name)',
'/',
'commit',
'/'))
);
wwv_flow_imp.component_end;
end;
/
