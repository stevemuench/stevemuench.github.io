prompt --application/deployment/install/install_drop_tables_quietly
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables Quietly
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(10679880650015982)
,p_install_id=>wwv_flow_imp.id(661840070432022836)
,p_name=>'Drop Tables Quietly'
,p_sequence=>5
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables apex_t_varchar2 := apex_t_varchar2(''eba_demo_staff'',',
'                                                ''eba_demo_action'',',
'                                                ''eba_demo_team'');',
'begin',
'    --',
'    -- Quietly drop all tables in the list',
'    --',
'    for j in 1..l_tables.count loop',
'        begin',
'            execute immediate ''drop table ''||l_tables(j)||'' cascade constraints'';',
'        exception',
'            when others then',
'                if sqlcode != -942 then',
'                    raise;',
'                end if;',
'        end;',
'    end loop;',
'end;',
'/'))
);
wwv_flow_imp.component_end;
end;
/
