prompt --application/deployment/install/install_package
begin
--   Manifest
--     INSTALL: INSTALL-Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(661841589787014516)
,p_install_id=>wwv_flow_imp.id(661840070432022836)
,p_name=>'Package'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_demo_action_validation is',
'    --==========================================================',
'    -- Ensure the action has exactly one Lead',
'    --==========================================================    ',
'    procedure one_lead_per_action_team(',
'        p_action_id in number);',
'    --==========================================================',
'    -- Ensure the action has no duplicate team members',
'    --========================================================== ',
'    procedure no_duplicate_team_members(',
'        p_action_id in number);   ',
'end;',
'/',
'create or replace package body eba_demo_action_validation is',
'    ------------------------------------------------------------',
'    -- Constant for error message keys',
'    ------------------------------------------------------------',
'    c_msg_team_must_have_lead constant varchar2(25) := ''TEAM_MUST_HAVE_A_LEAD'';',
'    c_msg_team_max_one_lead   constant varchar2(25) := ''TEAM_MAX_ONE_LEAD'';',
'    c_msg_team_no_duplicates  constant varchar2(25) := ''TEAM_NO_DUPE_MEMBERS'';',
'',
'    --==========================================================',
'    -- Raise an error with indicated message key',
'    --==========================================================',
'    procedure error(',
'        p_message_key in varchar2)',
'    is',
'    begin',
'        apex_error.add_error (',
'            p_message          => apex_lang.message(p_message_key),',
'            p_display_location => apex_error.c_on_error_page);',
'    end;',
'    --==========================================================',
'    -- PUBLIC API: See specification for details',
'    --==========================================================    ',
'    procedure one_lead_per_action_team(',
'        p_action_id in number)',
'    is',
'        l_lead_count number;',
'    begin',
'        -- Ensure the action id still exists since it might',
'        -- have been deleted. If it exists, perform the check',
'        -- on the children rows.',
'        for j in (select id ',
'                    from eba_demo_action',
'                   where id = p_action_id) loop',
'            select count(*)',
'            into l_lead_count',
'            from eba_demo_team',
'            where action_id = p_action_id',
'            and role = ''LEAD'';',
'            if l_lead_count != 1 then',
'                error(  case ',
'                            when l_lead_count < 1 ',
'                            then c_msg_team_must_have_lead',
'                            else c_msg_team_max_one_lead',
'                        end);',
'            end if;',
'        end loop;',
'    end;',
'    --==========================================================',
'    -- PUBLIC API: See specification for details',
'    --==========================================================      ',
'    procedure no_duplicate_team_members(',
'        p_action_id in number)',
'    is',
'    begin',
'        -- Ensure the action id still exists since it might',
'        -- have been deleted. If it exists, perform the check',
'        -- on the children rows.',
'        for j in (select id ',
'                    from eba_demo_action',
'                   where id = p_action_id) loop    ',
'            for k in (select user_id, count(*)',
'                        from eba_demo_team',
'                       where action_id = p_action_id',
'                       group by user_id',
'                       having count(*) > 1',
'                       fetch first row only) loop',
'                error(c_msg_team_no_duplicates);',
'                exit;',
'            end loop;',
'        end loop;',
'    end;    ',
'end;',
'/'))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(661841635007014510)
,p_script_id=>wwv_flow_imp.id(661841589787014516)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_ACTION_VALIDATION'
,p_last_updated_by=>'STEVE.MUENCH@ORACLE.COM'
,p_last_updated_on=>to_date('20230814173517','YYYYMMDDHH24MISS')
,p_created_by=>'STEVE.MUENCH@ORACLE.COM'
,p_created_on=>to_date('20230814173517','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
