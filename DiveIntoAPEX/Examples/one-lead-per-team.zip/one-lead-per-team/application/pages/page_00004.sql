prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Action Items'
,p_alias=>'ACTION-ITEMS'
,p_step_title=>'Action Items'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'td[headers=action-team-lead], th#action-team-lead {',
'  width: 10em ',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230818192243'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(661315357485683133)
,p_plug_name=>'Actions'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(661575893872162967)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select a.id,',
'       a.name,',
'       s.name as lead',
'  from      eba_demo_action a',
'  left join eba_demo_team   t on t.action_id = a.id and t.role = ''LEAD'' ',
'  left join eba_demo_staff  s on t.user_id   = s.id'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Actions'
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(661315440099683133)
,p_name=>'Actions'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'C'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_detail_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:RP:P5_ID:\#ID#\'
,p_detail_link_text=>'<span role="img" aria-label="Edit"><span class="fa fa-edit" aria-hidden="true" title="Edit"></span></span>'
,p_owner=>'STEVE.MUENCH@ORACLE.COM'
,p_internal_uid=>650640620685867321
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(661315910481683142)
,p_db_column_name=>'ID'
,p_display_order=>0
,p_is_primary_key=>'Y'
,p_column_identifier=>'A'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_display_text_as=>'HIDDEN_ESCAPE_SC'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(661316268739683146)
,p_db_column_name=>'NAME'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'Action Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(816363366461243)
,p_db_column_name=>'LEAD'
,p_display_order=>12
,p_column_identifier=>'C'
,p_column_label=>'Lead'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_static_id=>'action-team-lead'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(661327778281718031)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'6506530'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'NAME:LEAD:'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(661317611800683152)
,p_plug_name=>'Action Items'
,p_plug_display_sequence=>10
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'- Action Items'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(661316720160683146)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(661315357485683133)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(661658885633162840)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Create'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:5::'
);
wwv_flow_imp.component_end;
end;
/
