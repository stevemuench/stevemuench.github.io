prompt --application/shared_components/globalization/messages
begin
--   Manifest
--     MESSAGES: 9223
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
null;
wwv_flow_imp.component_end;
end;
/
begin
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(407461221238763)
,p_name=>'TEAM_MAX_ONE_LEAD'
,p_message_text=>'Only one Lead per action team'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(407305186235290)
,p_name=>'TEAM_MUST_HAVE_A_LEAD'
,p_message_text=>'Each action team needs a Lead'
);
wwv_flow_imp_shared.create_message(
 p_id=>wwv_flow_imp.id(407724220245779)
,p_name=>'TEAM_NO_DUPE_MEMBERS'
,p_message_text=>'No duplicate team members allowed'
);
wwv_flow_imp.component_end;
end;
/
