prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>1379356379574033
,p_default_application_id=>9223
,p_default_id_offset=>3976166214630110
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_menu(
 p_id=>wwv_flow_imp.id(661482369010163136)
,p_name=>'Breadcrumb'
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(661307665769665287)
,p_short_name=>'Staff'
,p_link=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>2
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(661317410452683149)
,p_short_name=>'Actions'
,p_link=>'f?p=&APP_ID.:4:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>4
);
wwv_flow_imp_shared.create_menu_option(
 p_id=>wwv_flow_imp.id(661318575319683156)
,p_parent_id=>wwv_flow_imp.id(661317410452683149)
,p_short_name=>'Action'
,p_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_imp.component_end;
end;
/
