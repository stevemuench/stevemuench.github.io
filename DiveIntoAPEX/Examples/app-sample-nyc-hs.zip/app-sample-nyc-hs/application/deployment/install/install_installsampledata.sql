prompt --application/deployment/install/install_installsampledata
begin
--   Manifest
--     INSTALL: INSTALL-InstallSampleData
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>21049
,p_default_id_offset=>17046775821402119029
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(15952586183229634952)
,p_install_id=>wwv_flow_imp.id(21029855402235680)
,p_name=>'InstallSampleData'
,p_sequence=>40
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --EBA_DEMO_NYC_HIGHSCHOOLS: 427/10000 rows exported, APEX$DATA$PKG/EBA_DEMO_NYC_HIGHSCHOOLS$403914',
'    apex_data_install.load_supporting_object_data(p_table_name => ''EBA_DEMO_NYC_HIGHSCHOOLS'', p_delete_after_install => false );',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
