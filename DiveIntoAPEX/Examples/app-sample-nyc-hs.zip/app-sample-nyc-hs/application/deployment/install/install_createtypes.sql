prompt --application/deployment/install/install_createtypes
begin
--   Manifest
--     INSTALL: INSTALL-CreateTypes
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>21049
,p_default_id_offset=>17046775821402119029
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(20682725703229175)
,p_install_id=>wwv_flow_imp.id(21029855402235680)
,p_name=>'CreateTypes'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace type t_highschool_row as object(',
'    school_name         varchar2(255),',
'    latitude            number,',
'    longitude           number,',
'    college_career_rate number,',
'    attendance_rate     number,',
'    graduation_rate     number)',
'/',
'create or replace type t_highschool_table as table of t_highschool_row',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
