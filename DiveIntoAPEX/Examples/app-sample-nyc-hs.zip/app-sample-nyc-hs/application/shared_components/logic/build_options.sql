prompt --application/shared_components/logic/build_options
begin
--   Manifest
--     BUILD OPTIONS: 103
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>21049
,p_default_id_offset=>17046775821402119029
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_build_option(
 p_id=>wwv_flow_imp.id(32217570701595184)
,p_build_option_name=>'Commented Out'
,p_build_option_status=>'EXCLUDE'
);
wwv_flow_imp.component_end;
end;
/
