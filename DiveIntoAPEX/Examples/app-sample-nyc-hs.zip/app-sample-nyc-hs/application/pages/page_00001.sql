prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.1'
,p_default_workspace_id=>9937757192523594183
,p_default_application_id=>21049
,p_default_id_offset=>17046775821402119029
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'&APP_NAME.'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.do_not_hyphenate {',
'  hyphens: none;',
'  -webkit-hyphens: none;',
'}'))
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230116150210'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16837862233691105055)
,p_plug_name=>'MapAndChart'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32180304643595115)
,p_plug_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_new_grid_row=>false
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16837862116831105054)
,p_plug_name=>'Attendance, Graduation, and College/Career Rates'
,p_parent_plug_id=>wwv_flow_imp.id(16837862233691105055)
,p_region_css_classes=>'margin-top-md'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(32147870717595090)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select school_name, graduation_rate, ',
'       attendance_rate, college_career_rate',
'from eba_demo_nyc_highschool_data( ',
'       p_page_id => :APP_PAGE_ID,',
'       p_region_static_id => ''schools'')'))
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_ajax_items_to_submit=>'P1_SEARCH,P1_LANGUAGES,P1_AP_COURSES,P1_SPORTS'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(16837861992943105053)
,p_region_id=>wwv_flow_imp.id(16837862116831105054)
,p_chart_type=>'bar'
,p_height=>'300'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'on'
,p_stack_label=>'off'
,p_connect_nulls=>'Y'
,p_value_position=>'auto'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_show_label=>true
,p_show_row=>true
,p_show_start=>true
,p_show_end=>true
,p_show_progress=>true
,p_show_baseline=>true
,p_legend_rendered=>'off'
,p_legend_position=>'auto'
,p_overview_rendered=>'off'
,p_horizontal_grid=>'auto'
,p_vertical_grid=>'auto'
,p_gauge_orientation=>'circular'
,p_gauge_plot_area=>'on'
,p_show_gauge_value=>true
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16837861925753105052)
,p_chart_id=>wwv_flow_imp.id(16837861992943105053)
,p_seq=>10
,p_name=>'Attendance'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'ATTENDANCE_RATE'
,p_items_label_column_name=>'SCHOOL_NAME'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16837861473420105048)
,p_chart_id=>wwv_flow_imp.id(16837861992943105053)
,p_seq=>20
,p_name=>'Graduation'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'GRADUATION_RATE'
,p_items_label_column_name=>'SCHOOL_NAME'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(16837861445472105047)
,p_chart_id=>wwv_flow_imp.id(16837861992943105053)
,p_seq=>30
,p_name=>'College/Career'
,p_location=>'REGION_SOURCE'
,p_items_value_column_name=>'COLLEGE_CAREER_RATE'
,p_items_label_column_name=>'SCHOOL_NAME'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16837861795171105051)
,p_chart_id=>wwv_flow_imp.id(16837861992943105053)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(16837861703247105050)
,p_chart_id=>wwv_flow_imp.id(16837861992943105053)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_zoom_order_seconds=>false
,p_zoom_order_minutes=>false
,p_zoom_order_hours=>false
,p_zoom_order_days=>false
,p_zoom_order_weeks=>false
,p_zoom_order_months=>false
,p_zoom_order_quarters=>false
,p_zoom_order_years=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31501859830967581)
,p_plug_name=>'Map'
,p_parent_plug_id=>wwv_flow_imp.id(16837862233691105055)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32180304643595115)
,p_plug_display_sequence=>10
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_MAP_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_map_region(
 p_id=>wwv_flow_imp.id(31499418681967556)
,p_region_id=>wwv_flow_imp.id(31501859830967581)
,p_height=>400
,p_navigation_bar_type=>'FULL'
,p_navigation_bar_position=>'END'
,p_init_position_zoom_type=>'QUERY_RESULTS'
,p_layer_messages_position=>'BELOW'
,p_show_legend=>false
,p_features=>'MOUSEWHEEL_ZOOM:RECTANGLE_ZOOM:SCALE_BAR:INFINITE_MAP'
);
wwv_flow_imp_page.create_map_region_layer(
 p_id=>wwv_flow_imp.id(31499270629967555)
,p_map_region_id=>wwv_flow_imp.id(31499418681967556)
,p_name=>'Schools Layer'
,p_layer_type=>'POINT'
,p_display_sequence=>10
,p_location=>'LOCAL'
,p_query_type=>'SQL'
,p_layer_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select school_name, latitude, longitude',
'from eba_demo_nyc_highschool_data( ',
'       p_page_id => :APP_PAGE_ID,',
'       p_region_static_id => ''schools'')'))
,p_items_to_submit=>'P1_SEARCH,P1_LANGUAGES,P1_AP_COURSES,P1_SPORTS'
,p_has_spatial_index=>false
,p_geometry_column_data_type=>'LONLAT_COLUMNS'
,p_longitude_column=>'LONGITUDE'
,p_latitude_column=>'LATITUDE'
,p_point_display_type=>'SVG'
,p_point_svg_shape=>'Default'
,p_feature_clustering=>false
,p_tooltip_adv_formatting=>false
,p_info_window_adv_formatting=>false
,p_allow_hide=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31502183743967584)
,p_plug_name=>'Schools'
,p_region_name=>'schools'
,p_region_css_classes=>'box'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32177532715595113)
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select ID,',
'       BOROUGH,',
'       SCHOOL_NAME,',
'       NEIGHBORHOOD,',
'       INTEREST,',
'       METHOD,',
'       TOTAL_STUDENTS,',
'       GRADUATION_RATE,',
'       ATTENDANCE_RATE,',
'       COLLEGE_CAREER_RATE,',
'       SAFE,',
'       SEATS,',
'       APPLICANTS,',
'       DBN,',
'       LATITUDE,',
'       LONGITUDE,',
'       LANGUAGE_CLASSES,',
'       REPLACE(ADVANCED_PLACEMENT_COURSES,''AP '')',
'       ADVANCED_PLACEMENT_COURSES,',
'       SCHOOL_SPORTS',
'  from EBA_DEMO_NYC_HIGHSCHOOLS'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_show_total_row_count=>false
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(17004585364715758539)
,p_region_id=>wwv_flow_imp.id(31502183743967584)
,p_layout_type=>'GRID'
,p_grid_column_count=>2
,p_title_adv_formatting=>false
,p_title_column_name=>'SCHOOL_NAME'
,p_title_css_classes=>'do_not_hyphenate'
,p_sub_title_adv_formatting=>true
,p_sub_title_html_expr=>'&BOROUGH. - &NEIGHBORHOOD.'
,p_body_adv_formatting=>true
,p_body_html_expr=>wwv_flow_string.join(wwv_flow_t_varchar2(
'{if LANGUAGE_CLASSES/}',
'  <div><u>Languages</u></div>',
'   &LANGUAGE_CLASSES.',
'{endif/}',
'{if ADVANCED_PLACEMENT_COURSES/}',
'  <div><u>AP Courses</u></div>',
'   &ADVANCED_PLACEMENT_COURSES.',
'{endif/}',
'{if SCHOOL_SPORTS/}',
'  <div><u>Sports</u></div>',
'  &SCHOOL_SPORTS.',
'{endif/}',
''))
,p_second_body_adv_formatting=>true
,p_second_body_html_expr=>'&INTEREST. - &METHOD.'
,p_media_adv_formatting=>false
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(31502034980967583)
,p_plug_name=>'Filter Schools'
,p_region_css_classes=>'w100p'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(32178865042595114)
,p_plug_display_sequence=>10
,p_plug_display_point=>'BEFORE_NAVIGATION_BAR'
,p_plug_source_type=>'NATIVE_SMART_FILTERS'
,p_filtered_region_id=>wwv_flow_imp.id(31502183743967584)
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'0'
,p_attribute_02=>'N'
,p_attribute_03=>'10000'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16837863409756105067)
,p_name=>'P1_SEARCH'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(31502034980967583)
,p_prompt=>'Search'
,p_source=>'BOROUGH,SCHOOL_NAME,NEIGHBORHOOD,INTEREST,METHOD,LANGUAGE_CLASSES,ADVANCED_PLACEMENT_COURSES,SCHOOL_SPORTS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_SEARCH'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'ROW'
,p_attribute_04=>'N'
,p_fc_show_chart=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16837863094517105064)
,p_name=>'P1_LANGUAGES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(31502034980967583)
,p_prompt=>'Languages'
,p_source=>'LANGUAGE_CLASSES'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_icon_css_classes=>'fa-language'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_toggleable=>false
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16837862969930105063)
,p_name=>'P1_SPORTS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(31502034980967583)
,p_prompt=>'Sports'
,p_source=>'SCHOOL_SPORTS'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_icon_css_classes=>'fa-soccer-ball-o'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_toggleable=>false
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'OR'
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16837862901813105062)
,p_name=>'P1_AP_COURSES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(31502034980967583)
,p_prompt=>'AP Courses'
,p_source=>'ADVANCED_PLACEMENT_COURSES'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_icon_css_classes=>'fa-user-graduate'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_toggleable=>false
,p_multi_value_type=>'SEPARATED'
,p_multi_value_separator=>','
,p_multi_value_trim_space=>true
,p_fc_filter_combination=>'AND'
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(16837861285818105046)
,p_name=>'P1_BOROUGH'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(31502034980967583)
,p_prompt=>'Borough'
,p_source=>'BOROUGH'
,p_source_type=>'FACET_COLUMN'
,p_display_as=>'NATIVE_CHECKBOX'
,p_item_icon_css_classes=>'fa-map-o'
,p_item_template_options=>'#DEFAULT#'
,p_fc_show_label=>true
,p_fc_compute_counts=>true
,p_fc_show_counts=>true
,p_fc_zero_count_entries=>'H'
,p_fc_filter_values=>false
,p_fc_sort_by_top_counts=>true
,p_fc_show_selected_first=>false
,p_fc_show_chart=>false
,p_fc_toggleable=>false
,p_suggestions_type=>'DYNAMIC'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(31499219377967554)
,p_name=>'After Refresh School List'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31502183743967584)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_CARDS|REGION TYPE|tablemodelviewpagechange'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(31499099724967553)
,p_event_id=>wwv_flow_imp.id(31499219377967554)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Map'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31501859830967581)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(16837861649550105049)
,p_event_id=>wwv_flow_imp.id(31499219377967554)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Refresh Chart'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(16837862116831105054)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(17004586232990758548)
,p_name=>'After Refresh Map'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(31501859830967581)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9185230354499994636)
,p_event_id=>wwv_flow_imp.id(17004586232990758548)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_ORG.STEVEMUENCH.APEX.CENTER_ZOOM_MAP'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(31501859830967581)
);
wwv_flow_imp.component_end;
end;
/
