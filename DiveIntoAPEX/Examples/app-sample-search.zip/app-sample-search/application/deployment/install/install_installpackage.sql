prompt --application/deployment/install/install_installpackage
begin
--   Manifest
--     INSTALL: INSTALL-InstallPackage
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(321430239667765358)
,p_install_id=>wwv_flow_imp.id(321405151839401670)
,p_name=>'InstallPackage'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'CREATE OR REPLACE EDITIONABLE FUNCTION "CONVERT_END_USER_SEARCH" (',
'    p_search in varchar2 )',
'    return varchar2 ',
'is',
'    c_xml constant varchar2(32767) := ''<query><textquery><progression>'' ||',
'                                        ''<seq>  #SEARCH#  </seq>'' ||',
'                                        ''<seq> FUZZY({#SEARCH#}, 60, 100, W )  </seq>'' ||',
'                                        ''<seq>  #SEARCH#% </seq>'' ||',
'                                        ''<seq> %#SEARCH#% </seq>'' ||',
'                                        ''<seq> !{#SEARCH#} </seq>'' ||',
'                                      ''</progression></textquery></query>'';',
'    l_search varchar2(32767) := p_search;',
'begin',
'    -- remove special characters; irrelevant for full text search',
'    l_search := regexp_replace( l_search, ''[<>{}/()*%&!$?.:,;\+#]'', '''' );',
'    l_search := replace( c_xml, ''#SEARCH#'', l_search );',
'    apex_debug.info(''convert_end_user_search (IN): %s'',p_search);',
'    apex_debug.info(''convert_end_user_search (RETURN): %s'',l_search);',
'    return l_search;',
'end;',
'/',
'',
'CREATE OR REPLACE EDITIONABLE PACKAGE "EBA_DEMO_APPSEARCH" is',
'    procedure log_recent_search(p_search_text varchar2);',
'    procedure log_recent_search_and_keep_max(p_search_text varchar2, p_max_keep_recents number);',
'end;',
'/',
'',
'',
'CREATE OR REPLACE EDITIONABLE PACKAGE BODY "EBA_DEMO_APPSEARCH" is',
'    procedure log_recent_search_and_keep_max(p_search_text varchar2, p_max_keep_recents number) is',
'        l_existing_search_text_id number;',
'        l_normalized_search_text varchar2(4000);',
'        function normalize_search_text(p_search_text varchar2) return varchar2 is',
'        begin',
'            return trim(lower(regexp_replace(p_search_text,''\ +'','' '')));',
'        end;',
'    begin',
'        l_normalized_search_text := normalize_search_text(p_search_text);',
'        -- Add normalized search text or update the entry if already existed',
'        begin',
'            select id ',
'            into l_existing_search_text_id',
'            from eba_demo_appsearch_recents',
'            where search_text = l_normalized_search_text',
'              and created_by = v(''APP_USER'');',
'            update eba_demo_appsearch_recents',
'            set search_text = search_text',
'            where id = l_existing_search_text_id;',
'        exception',
'            when no_data_found then',
'            insert into eba_demo_appsearch_recents(search_text)',
'            values (l_normalized_search_text);',
'        end;',
'        if p_max_keep_recents > 0 then',
'        -- Keep only the p_max_keep_recents most recent searches',
'            delete from eba_demo_appsearch_recents',
'            where id in (',
'              select id from (',
'                select id, row_number() over (order by updated desc) as row_num',
'                from eba_demo_appsearch_recents',
'                order by updated desc',
'                offset p_max_keep_recents rows',
'                )',
'                where row_num > p_max_keep_recents',
'              );',
'          end if;',
'    end;',
'    procedure log_recent_search(p_search_text varchar2) is',
'    begin',
'        log_recent_search_and_keep_max(p_search_text      => p_search_text,',
'                                       p_max_keep_recents => -1 );',
'    end;',
'end;',
'/',
'',
''))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(321430360465765359)
,p_script_id=>wwv_flow_imp.id(321430239667765358)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_APPSEARCH'
,p_last_updated_by=>'SMUENCH'
,p_last_updated_on=>to_date('20220902180248','YYYYMMDDHH24MISS')
,p_created_by=>'SMUENCH'
,p_created_on=>to_date('20220902180248','YYYYMMDDHH24MISS')
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(2839831633658644)
,p_script_id=>wwv_flow_imp.id(321430239667765358)
,p_object_owner=>'#OWNER#'
,p_object_type=>'FUNCTION'
,p_object_name=>'CONVERT_END_USER_SEARCH'
,p_last_updated_by=>'SMUENCH'
,p_last_updated_on=>to_date('20220923094017','YYYYMMDDHH24MISS')
,p_created_by=>'SMUENCH'
,p_created_on=>to_date('20220923094017','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
