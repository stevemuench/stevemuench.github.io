prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 500
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(321405151839401670)
,p_get_version_sql_query=>'SELECT OBJECT_NAME FROM SYS.USER_OBJECTS WHERE OBJECT_NAME = ''EBA_DEMO_APPSEARCH_RECENTS'''
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'-- drop objects',
'drop table eba_demo_appsearch_recents cascade constraints;',
'drop package eba_demo_appsearch;'))
);
wwv_flow_imp.component_end;
end;
/
