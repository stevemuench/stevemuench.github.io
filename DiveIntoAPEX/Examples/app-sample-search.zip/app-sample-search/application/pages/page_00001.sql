prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'App Search'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20220923122145'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2773816194905808)
,p_plug_name=>'Results Cards'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(286807847310205919)
,p_plug_display_sequence=>30
,p_include_in_reg_disp_sel_yn=>'Y'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select primary_key_1, title, description,link, ''fa ''||icon_value as icon_value ',
'from table(apex_search.search(',
'            apex_t_varchar2(''employees'',''departments'',''countries'',''navigation_menu'',''people''),',
'            :p0_search))'))
,p_lazy_loading=>false
,p_plug_source_type=>'NATIVE_CARDS'
,p_plug_query_num_rows_type=>'SCROLL'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_query_no_data_found=>'No Employees, Departments, Countries, People, or Application Pages found.'
,p_show_total_row_count=>false
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P0_CARDS=''Y'' AND :P0_SEARCH IS NOT NULL'
,p_plug_display_when_cond2=>'PLSQL'
);
wwv_flow_imp_page.create_card(
 p_id=>wwv_flow_imp.id(2773930164905809)
,p_region_id=>wwv_flow_imp.id(2773816194905808)
,p_layout_type=>'GRID'
,p_title_adv_formatting=>false
,p_title_column_name=>'TITLE'
,p_sub_title_adv_formatting=>false
,p_body_adv_formatting=>false
,p_body_column_name=>'DESCRIPTION'
,p_second_body_adv_formatting=>false
,p_icon_source_type=>'DYNAMIC_CLASS'
,p_icon_class_column_name=>'ICON_VALUE'
,p_icon_position=>'START'
,p_media_adv_formatting=>false
,p_pk1_column_name=>'PRIMARY_KEY_1'
);
wwv_flow_imp_page.create_card_action(
 p_id=>wwv_flow_imp.id(2774004173905810)
,p_card_id=>wwv_flow_imp.id(2773930164905809)
,p_action_type=>'FULL_CARD'
,p_display_sequence=>10
,p_link_target_type=>'REDIRECT_URL'
,p_link_target=>'&LINK.'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(130184993288654134)
,p_plug_name=>'Search'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(286800705830205913)
,p_plug_display_sequence=>20
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'NATIVE_SEARCH_REGION'
,p_ajax_items_to_submit=>'P0_SEARCH'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P0_CARDS=''N'' AND :P0_SEARCH IS NOT NULL'
,p_plug_display_when_cond2=>'PLSQL'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_05=>'P0_SEARCH'
,p_attribute_06=>'N'
,p_attribute_11=>'Y'
,p_attribute_14=>'15'
,p_attribute_15=>'Y'
,p_attribute_16=>'No Employees, Departments, Countries, People, or Application Pages found.'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(130185019633654135)
,p_region_id=>wwv_flow_imp.id(130184993288654134)
,p_search_config_id=>wwv_flow_imp.id(286984032150253784)
,p_use_as_initial_result=>false
,p_display_sequence=>10
,p_name=>'Employees'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(130185185518654136)
,p_region_id=>wwv_flow_imp.id(130184993288654134)
,p_search_config_id=>wwv_flow_imp.id(286984354366261233)
,p_use_as_initial_result=>false
,p_display_sequence=>20
,p_name=>'Departments'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(130185296070654137)
,p_region_id=>wwv_flow_imp.id(130184993288654134)
,p_search_config_id=>wwv_flow_imp.id(286984641554268568)
,p_use_as_initial_result=>false
,p_display_sequence=>30
,p_name=>'Countries'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(295124839788392928)
,p_region_id=>wwv_flow_imp.id(130184993288654134)
,p_search_config_id=>wwv_flow_imp.id(321397219152218572)
,p_use_as_initial_result=>false
,p_display_sequence=>40
,p_name=>'Navigation Menu'
,p_override_icon=>'fa-window-search'
);
wwv_flow_imp_page.create_search_region_source(
 p_id=>wwv_flow_imp.id(2773797429905807)
,p_region_id=>wwv_flow_imp.id(130184993288654134)
,p_search_config_id=>wwv_flow_imp.id(2809987962184447)
,p_use_as_initial_result=>false
,p_display_sequence=>50
,p_name=>'People'
);
wwv_flow_imp_page.create_report_region(
 p_id=>wwv_flow_imp.id(295124926816392929)
,p_name=>'Recent Searches'
,p_template=>wwv_flow_imp.id(286866515941205972)
,p_display_sequence=>40
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select search_text',
'from eba_demo_appsearch_recents',
'where created_by = :APP_USER',
'order by updated desc'))
,p_display_when_condition=>'P0_SEARCH'
,p_display_condition_type=>'ITEM_IS_NULL'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_imp.id(286900222580206005)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_imp_page.create_report_columns(
 p_id=>wwv_flow_imp.id(295125040774392930)
,p_query_column_id=>1
,p_column_alias=>'SEARCH_TEXT'
,p_column_display_sequence=>10
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P0_SEARCH:\#SEARCH_TEXT#\'
,p_column_linktext=>'#SEARCH_TEXT#'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(295122232595392902)
,p_branch_name=>'Redirect Keeping Submitted Search'
,p_branch_action=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P0_SEARCH:\&P0_SEARCH.\&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(295125137743392931)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Remember Recent Searches'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_DEMO_APPSEARCH'
,p_attribute_04=>'LOG_RECENT_SEARCH_AND_KEEP_MAX'
,p_process_when=>'P0_SEARCH'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(295125217618392932)
,p_page_process_id=>wwv_flow_imp.id(295125137743392931)
,p_page_id=>1
,p_name=>'p_search_text'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P0_SEARCH'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(295125312312392933)
,p_page_process_id=>wwv_flow_imp.id(295125137743392931)
,p_page_id=>1
,p_name=>'p_max_keep_recents'
,p_direction=>'IN'
,p_data_type=>'NUMBER'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'STATIC'
,p_value=>'10'
);
wwv_flow_imp.component_end;
end;
/
