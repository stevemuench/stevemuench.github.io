prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20220923121529'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(130185744095654142)
,p_button_sequence=>20
,p_button_name=>'GLOBAL_SEARCH'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(286939437494206039)
,p_button_image_alt=>'Search'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(2774165329905811)
,p_name=>'P0_CARDS'
,p_item_sequence=>30
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(130185536054654140)
,p_name=>'P0_SEARCH'
,p_item_sequence=>10
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_prompt=>'Search'
,p_placeholder=>'Search for countries, employees, departments, people, or pages in this application by name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_tag_css_classes=>'w100p'
,p_field_template=>wwv_flow_imp.id(286936993749206036)
,p_item_css_classes=>'w100p'
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
);
wwv_flow_imp.component_end;
end;
/
