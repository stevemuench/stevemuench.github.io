prompt --application/pages/page_00011
begin
--   Manifest
--     PAGE: 00011
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_page.create_page(
 p_id=>11
,p_name=>'README'
,p_alias=>'README'
,p_step_title=>'README'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20220923162358'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(2774239413905812)
,p_plug_name=>'README'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(286802130367205915)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_source_type=>'PLUGIN_MARKDOWN_REGION'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'APP_STATIC_FILE'
,p_attribute_03=>'README.md.txt'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3091844754825223)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(286878955919205983)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(286764039932205880)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(286941055795206040)
);
wwv_flow_imp.component_end;
end;
/
