prompt --application/shared_components/files/datamodel_quicksql_txt
begin
--   Manifest
--     APP STATIC FILES: 500
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '232073657474696E6773203D207B207072656669783A20226562615F64656D6F5F617070736561726368222C2073656D616E746963733A202243484152222C206175646974436F6C733A20747275652C2064726F703A20747275652C206C616E67756167';
wwv_flow_imp.g_varchar2_table(2) := '653A2022454E222C20415045583A2074727565207D0A726563656E74730A202020207365617263685F74657874';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(321404727945397468)
,p_file_name=>'datamodel_quicksql.txt'
,p_mime_type=>'text/plain'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
