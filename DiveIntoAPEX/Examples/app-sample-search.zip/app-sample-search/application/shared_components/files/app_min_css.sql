prompt --application/shared_components/files/app_min_css
begin
--   Manifest
--     APP STATIC FILES: 500
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '2E612D546162732D70616E656C2C2E6E6F2D616E696D202E612D43617264566965772D6974656D3E6469762C2E6E6F2D616E696D202E612D536561726368526573756C74732D6974656D3E6469762C2E6E6F2D616E696D202E742D54616273526567696F';
wwv_flow_imp.g_varchar2_table(2) := '6E2D6974656D733E6469767B646973706C61793A6E6F6E657D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(295701788279029192)
,p_file_name=>'app.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
