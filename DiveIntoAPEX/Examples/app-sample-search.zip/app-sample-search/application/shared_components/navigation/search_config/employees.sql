prompt --application/shared_components/navigation/search_config/employees
begin
--   Manifest
--     SEARCH CONFIG: Employees
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(286984032150253784)
,p_label=>'Employees'
,p_static_id=>'employees'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EMP'
,p_searchable_columns=>'ENAME:JOB'
,p_pk_column_name=>'EMPNO'
,p_title_column_name=>'ENAME'
,p_description_column_name=>'JOB'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.::P5_EMPNO:&EMPNO.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-users-alt'
);
wwv_flow_imp.component_end;
end;
/
