prompt --application/shared_components/navigation/search_config/countries
begin
--   Manifest
--     SEARCH CONFIG: Countries
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(286984641554268568)
,p_label=>'Countries'
,p_static_id=>'countries'
,p_search_prefix=>'country'
,p_search_type=>'SIMPLE'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_COUNTRIES_V'
,p_searchable_columns=>'NAME:CAPITAL'
,p_pk_column_name=>'COUNTRY_ID'
,p_title_column_name=>'NAME'
,p_description_column_name=>'CAPITAL'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.::P3_COUNTRY_ID:&COUNTRY_ID.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-globe'
);
wwv_flow_imp.component_end;
end;
/
