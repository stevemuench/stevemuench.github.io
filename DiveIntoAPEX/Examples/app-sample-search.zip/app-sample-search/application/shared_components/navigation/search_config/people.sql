prompt --application/shared_components/navigation/search_config/people
begin
--   Manifest
--     SEARCH CONFIG: People
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(2809987962184447)
,p_label=>'People'
,p_static_id=>'people'
,p_search_prefix=>'person'
,p_search_type=>'TEXT_MANUAL'
,p_location=>'LOCAL'
,p_query_type=>'TABLE'
,p_query_table=>'EBA_DEMO_IG_PEOPLE'
,p_oratext_index_column_name=>'NAME'
,p_oratext_function=>'convert_end_user_search'
,p_pk_column_name=>'ID'
,p_title_column_name=>'NAME'
,p_description_column_name=>'COUNTRY'
,p_link_target_type=>'REDIRECT_PAGE'
,p_link_target=>'f?p=&APP_ID.:10:&APP_SESSION.::&DEBUG.::P10_ID:&ID.'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-nurse'
);
wwv_flow_imp.component_end;
end;
/
