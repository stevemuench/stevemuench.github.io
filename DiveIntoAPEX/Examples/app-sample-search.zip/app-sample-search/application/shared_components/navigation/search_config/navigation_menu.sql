prompt --application/shared_components/navigation/search_config/navigation_menu
begin
--   Manifest
--     SEARCH CONFIG: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_search_config(
 p_id=>wwv_flow_imp.id(321397219152218572)
,p_label=>'Navigation Menu'
,p_static_id=>'navigation_menu'
,p_search_prefix=>'page'
,p_search_type=>'APEX_LIST'
,p_list_id=>wwv_flow_imp.id(286764515579205881)
,p_pk_column_name=>'1'
,p_title_column_name=>'2'
,p_description_column_name=>'8'
,p_custom_01_column_name=>'7'
,p_icon_source_type=>'STATIC_CLASS'
,p_icon_css_classes=>'fa-address-card-o'
);
wwv_flow_imp.component_end;
end;
/
