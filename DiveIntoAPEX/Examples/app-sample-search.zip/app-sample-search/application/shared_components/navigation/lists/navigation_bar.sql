prompt --application/shared_components/navigation/lists/navigation_bar
begin
--   Manifest
--     LIST: Navigation Bar
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0-15'
,p_default_workspace_id=>3226192879003700
,p_default_application_id=>500
,p_default_id_offset=>0
,p_default_owner=>'SMUENCH'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(286964096676206065)
,p_name=>'Navigation Bar'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'&APP_USER.'
,p_list_item_link_target=>'#'
,p_list_item_icon=>'fa-user'
,p_list_text_02=>'has-username'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3081993327535039)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Results as Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P0_CARDS,P0_SEARCH:Y,\&P0_SEARCH.\:'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'P0_CARDS'
,p_list_item_disp_condition2=>'N'
,p_parent_list_item_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3082404962546025)
,p_list_item_display_sequence=>15
,p_list_item_link_text=>'Results as Cards'
,p_list_item_link_target=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.::P0_CARDS,P0_SEARCH:N,\&P0_SEARCH.\:'
,p_list_item_icon=>'fa-check'
,p_list_item_disp_cond_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_list_item_disp_condition=>'P0_CARDS'
,p_list_item_disp_condition2=>'Y'
,p_parent_list_item_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(3095014101063388)
,p_list_item_display_sequence=>18
,p_list_item_link_text=>'README'
,p_list_item_link_target=>'f?p=&APP_ID.:11:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-file-word-o'
,p_parent_list_item_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(286976056785206083)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'---'
,p_list_item_link_target=>'separator'
,p_parent_list_item_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(286976405683206083)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Sign Out'
,p_list_item_link_target=>'&LOGOUT_URL.'
,p_list_item_icon=>'fa-sign-out'
,p_parent_list_item_id=>wwv_flow_imp.id(286975507438206082)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
