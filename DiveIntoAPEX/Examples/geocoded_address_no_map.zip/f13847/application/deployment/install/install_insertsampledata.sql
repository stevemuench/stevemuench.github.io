prompt --application/deployment/install/install_insertsampledata
begin
--   Manifest
--     INSTALL: INSTALL-InsertSampleData
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.10.15'
,p_release=>'21.2.0'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>13847
,p_default_id_offset=>0
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_api.create_install_script(
 p_id=>wwv_flow_api.id(22851801952441110114)
,p_install_id=>wwv_flow_api.id(22840043040587916778)
,p_name=>'InsertSampleData'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    --COUNTRIES_TABLE_NO_GEOM: 255/10000 rows exported, APEX$DATA$PKG/COUNTRIES_TABLE_NO_GEOM$716340',
'    apex_data_install.load_supporting_object_data(p_table_name => ''COUNTRIES_TABLE_NO_GEOM'', p_delete_after_install => true );',
'end;'))
);
wwv_flow_api.component_end;
end;
/
