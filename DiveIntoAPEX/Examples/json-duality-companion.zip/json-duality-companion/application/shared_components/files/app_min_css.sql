prompt --application/shared_components/files/app_min_css
begin
--   Manifest
--     APP STATIC FILES: 116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '3A726F6F747B2D2D75742D626F64792D636F6E74656E742D70616464696E672D793A3172656D3B2D2D75742D626F64792D636F6E74656E742D70616464696E672D783A3172656D7D';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(11380119551556772)
,p_file_name=>'app.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
