prompt --application/shared_components/user_interface/lovs/lov_json_col_tables
begin
--   Manifest
--     LOV_JSON_COL_TABLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(9101451477680120)
,p_lov_name=>'LOV_JSON_COL_TABLES'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select table_name d, table_name r',
'from (',
'    select distinct table_name',
'  from user_tab_columns',
'where data_type = ''JSON''',
'minus',
'select view_name',
' from user_json_duality_views)',
'order by d'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'R'
,p_display_column_name=>'D'
,p_version_scn=>41371311258641
);
wwv_flow_imp.component_end;
end;
/
