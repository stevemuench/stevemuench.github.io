prompt --application/shared_components/user_interface/lovs/lov_json_collections
begin
--   Manifest
--     LOV_JSON_COLLECTIONS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(11748155723730489)
,p_lov_name=>'LOV_JSON_COLLECTIONS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select collection_name, collection_name as collection_name2, case collection_type when ''DUALITY VIEW'' then ''fa-eye'' when ''TABLE'' then ''fa-table'' end collection_type_icon',
'from user_json_collections',
'order by collection_name'))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'COLLECTION_NAME2'
,p_display_column_name=>'COLLECTION_NAME'
,p_icon_column_name=>'COLLECTION_TYPE_ICON'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>41373608692987
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11752865329952957)
,p_query_column_name=>'COLLECTION_TYPE_ICON'
,p_heading=>'Collection Type Icon'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11765830325603653)
,p_query_column_name=>'COLLECTION_NAME2'
,p_heading=>'Collection Name2'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(11748679397732262)
,p_query_column_name=>'COLLECTION_NAME'
,p_display_sequence=>20
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
