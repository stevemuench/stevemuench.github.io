prompt --application/shared_components/plugins/template_component/bicoastal_button_bar
begin
--   Manifest
--     PLUGIN: BICOASTAL_BUTTON_BAR
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_plugin(
 p_id=>wwv_flow_imp.id(11174376315746884)
,p_plugin_type=>'TEMPLATE COMPONENT'
,p_theme_id=>nvl(wwv_flow_application_install.get_theme_id, '')
,p_name=>'BICOASTAL_BUTTON_BAR'
,p_display_name=>'Bicoastal Button Bar'
,p_supported_component_types=>'REGION_ONLY'
,p_image_prefix => nvl(wwv_flow_application_install.get_static_plugin_file_prefix('TEMPLATE COMPONENT','BICOASTAL_BUTTON_BAR'),'')
,p_css_file_urls=>'#PLUGIN_FILES#bicoastal-button-bar#MIN#.css'
,p_partial_template=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div class="bicoastal-button-bar-outer-container">',
'    <div class="bicoastal-button-bar-inner-container">',
'        {if LEFT_SIDE_BUTTONS/}',
'        <div class="bicoastal-button-bar-left-buttons">',
'            <p>#LEFT_SIDE_BUTTONS#</p>',
'        </div>',
'        {endif/}',
'        {if RIGHT_SIDE_BUTTONS/}',
'        <div class="bicoastal-button-bar-right-buttons">',
'            <p>#RIGHT_SIDE_BUTTONS#</p>',
'        </div>',
'        {endif/}',
'    </div>',
'</div>'))
,p_default_escape_mode=>'HTML'
,p_translate_this_template=>false
,p_api_version=>1
,p_substitute_attributes=>true
,p_version_scn=>41371917076236
,p_subscribe_plugin_settings=>true
,p_version_identifier=>'1.0'
,p_files_version=>15
);
wwv_flow_imp_shared.create_plugin_slot(
 p_id=>wwv_flow_imp.id(11175436579754133)
,p_plugin_id=>wwv_flow_imp.id(11174376315746884)
,p_name=>'LEFT_SIDE_BUTTONS'
,p_placeholder=>'LEFT_SIDE_BUTTONS'
,p_has_grid_support=>false
,p_has_item_support=>false
);
wwv_flow_imp_shared.create_plugin_slot(
 p_id=>wwv_flow_imp.id(11175724646754137)
,p_plugin_id=>wwv_flow_imp.id(11174376315746884)
,p_name=>'RIGHT_SIDE_BUTTONS'
,p_placeholder=>'RIGHT_SIDE_BUTTONS'
,p_has_grid_support=>false
,p_has_item_support=>false
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '6269636F617374616C2D627574746F6E2D6261722D6F757465722D636F6E7461696E6572207B0A202020206D617267696E3A20303B0A2020202070616464696E673A20303B0A202020206865696768743A20313030253B0A2020202077696474683A2031';
wwv_flow_imp.g_varchar2_table(2) := '3030253B0A20202020646973706C61793A20666C65783B0A202020206A7573746966792D636F6E74656E743A2063656E7465723B0A20202020616C69676E2D6974656D733A2063656E7465723B0A202020206F766572666C6F773A2068696464656E3B0A';
wwv_flow_imp.g_varchar2_table(3) := '7D0A0A2E6269636F617374616C2D627574746F6E2D6261722D696E6E65722D636F6E7461696E6572207B0A2020202077696474683A20313030253B0A20202020646973706C61793A20666C65783B0A202020206A7573746966792D636F6E74656E743A20';
wwv_flow_imp.g_varchar2_table(4) := '73706163652D6265747765656E3B0A2020202070616464696E673A203020323070783B0A20202020626F782D73697A696E673A20626F726465722D626F783B0A20202020706F736974696F6E3A2072656C61746976653B0A7D0A0A2E6269636F61737461';
wwv_flow_imp.g_varchar2_table(5) := '6C2D627574746F6E2D6261722D6C6566742D627574746F6E732C202E6269636F617374616C2D627574746F6E2D6261722D72696768742D627574746F6E73207B0A20202020646973706C61793A20666C65783B0A20202020616C69676E2D6974656D733A';
wwv_flow_imp.g_varchar2_table(6) := '2063656E7465723B0A7D0A0A2E6269636F617374616C2D627574746F6E2D6261722D6C6566742D627574746F6E73207B0A202020206A7573746966792D636F6E74656E743A20666C65782D73746172743B0A7D0A0A2E6269636F617374616C2D62757474';
wwv_flow_imp.g_varchar2_table(7) := '6F6E2D6261722D72696768742D627574746F6E73207B0A202020206A7573746966792D636F6E74656E743A20666C65782D656E643B0A7D0A';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(11177751017771426)
,p_plugin_id=>wwv_flow_imp.id(11174376315746884)
,p_file_name=>'bicoastal-button-bar.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '6269636F617374616C2D627574746F6E2D6261722D6F757465722D636F6E7461696E65727B6D617267696E3A303B70616464696E673A303B6865696768743A313030253B77696474683A313030253B646973706C61793A666C65783B6A7573746966792D';
wwv_flow_imp.g_varchar2_table(2) := '636F6E74656E743A63656E7465723B616C69676E2D6974656D733A63656E7465723B6F766572666C6F773A68696464656E7D2E6269636F617374616C2D627574746F6E2D6261722D696E6E65722D636F6E7461696E65727B77696474683A313030253B64';
wwv_flow_imp.g_varchar2_table(3) := '6973706C61793A666C65783B6A7573746966792D636F6E74656E743A73706163652D6265747765656E3B70616464696E673A3020323070783B626F782D73697A696E673A626F726465722D626F783B706F736974696F6E3A72656C61746976657D2E6269';
wwv_flow_imp.g_varchar2_table(4) := '636F617374616C2D627574746F6E2D6261722D6C6566742D627574746F6E732C2E6269636F617374616C2D627574746F6E2D6261722D72696768742D627574746F6E737B646973706C61793A666C65783B616C69676E2D6974656D733A63656E7465727D';
wwv_flow_imp.g_varchar2_table(5) := '2E6269636F617374616C2D627574746F6E2D6261722D6C6566742D627574746F6E737B6A7573746966792D636F6E74656E743A666C65782D73746172747D2E6269636F617374616C2D627574746F6E2D6261722D72696768742D627574746F6E737B6A75';
wwv_flow_imp.g_varchar2_table(6) := '73746966792D636F6E74656E743A666C65782D656E647D';
end;
/
begin
wwv_flow_imp_shared.create_plugin_file(
 p_id=>wwv_flow_imp.id(11211473196027223)
,p_plugin_id=>wwv_flow_imp.id(11174376315746884)
,p_file_name=>'bicoastal-button-bar.min.css'
,p_mime_type=>'text/css'
,p_file_charset=>'utf-8'
,p_file_content=>wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
end;
/
begin
wwv_flow_imp.component_end;
end;
/
