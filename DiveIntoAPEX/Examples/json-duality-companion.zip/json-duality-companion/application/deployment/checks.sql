prompt --application/deployment/checks
begin
--   Manifest
--     INSTALL CHECKS: 116
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(11251696562484963)
,p_install_id=>wwv_flow_imp.id(9095088049246382)
,p_name=>'Requires 23ai Version 23.4'
,p_sequence=>10
,p_check_type=>'FUNCTION_BODY'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_version_string constant varchar2(8) := ''Version''||chr(32);',
'    l_oracle_string  constant varchar2(6) := ''Oracle'';',
'    l_major_version           varchar2(100);',
'    l_minor_version           number;',
'    l_patch_version           number;',
'begin',
'    select to_number(regexp_substr(substr(banner_full, instr(banner_full, l_version_string) + length(l_version_string)), ''([0-9]+)\.([0-9]+)'', 1, 1, null, 1)),',
'           to_number(regexp_substr(substr(banner_full, instr(banner_full, l_version_string) + length(l_version_string)), ''([0-9]+)\.([0-9]+)'', 1, 1, null, 2)),',
'           to_number(regexp_substr(substr(banner_full, instr(banner_full, l_version_string) + length(l_version_string)), ''([0-9]+)\.([0-9]+)'', 1, 1, null, 3))',
'    into l_major_version, l_minor_version, l_patch_version',
'    from v$version',
'    where banner like l_oracle_string||''%'';',
'',
'    return l_major_version > 23 or (l_major_version = 23 and l_minor_version >= 4);',
'end;'))
,p_check_condition2=>'PLSQL'
,p_failure_message=>'This application requires Oracle 23ai version 23.4 or later.'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(3291327422958758)
,p_install_id=>wwv_flow_imp.id(9095088049246382)
,p_name=>'Requires CREATE TABLE privilege'
,p_sequence=>20
,p_check_type=>'EXISTS'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select privilege',
'from user_sys_privs',
'where privilege = ''CREATE TABLE'''))
,p_failure_message=>'Parsing Schema requires the CREATE TABLE privilege to use this application'
);
wwv_flow_imp_shared.create_install_check(
 p_id=>wwv_flow_imp.id(3291446838964543)
,p_install_id=>wwv_flow_imp.id(9095088049246382)
,p_name=>'Requires CREATE VIEW privilege'
,p_sequence=>30
,p_check_type=>'EXISTS'
,p_check_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select privilege',
'from user_sys_privs',
'where privilege = ''CREATE VIEW'''))
,p_failure_message=>'Parsing schema requires the CREATE VIEW privilege to use this application'
);
wwv_flow_imp.component_end;
end;
/
