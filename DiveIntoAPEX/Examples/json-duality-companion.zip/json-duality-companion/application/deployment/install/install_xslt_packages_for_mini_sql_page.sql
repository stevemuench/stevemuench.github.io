prompt --application/deployment/install/install_xslt_packages_for_mini_sql_page
begin
--   Manifest
--     INSTALL: INSTALL-XSLT Packages for Mini SQL Page
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(9389170708012824)
,p_install_id=>wwv_flow_imp.id(9095088049246382)
,p_name=>'XSLT Packages for Mini SQL Page'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace PACKAGE "EBA_DEMO_XSLT" is',
'    function validate_sql_statement( p_sql clob) return varchar2;',
'    function html_for_sql( p_sql clob ) return clob;',
'end;',
'/',
'create or replace PACKAGE "EBA_DEMO_XSLT_STYLESHEETS" is',
'   c_rowset_to_table constant xmltype := xmltype(q''[',
'        <xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">',
'          <xsl:template match="/">',
'              <xsl:apply-templates/>',
'          </xsl:template>',
'          <xsl:template match="ROWSET">',
'            <table class="sql-results" cellspacing="0">',
'              <!-- Apply templates in "ColumnHeader" mode to just *first* ROW child -->',
'              <thead><xsl:apply-templates select="ROW[1]/*" mode="ColumnHeaders"/></thead>',
'              <!-- Then apply templates to all child nodes normally -->',
'              <tbody><xsl:apply-templates/></tbody>',
'            </table>',
'          </xsl:template>',
'          <xsl:template match="ROW">',
'            <tr><xsl:apply-templates/></tr>',
'          </xsl:template>',
'          <!-- Match any element child of a ROW -->',
'          <xsl:template match="ROW/*">',
'            <td><xsl:apply-templates/></td>',
'          </xsl:template>',
'          <!-- Match any element child of a ROW when in "ColumnHeaders" Mode-->',
'          <xsl:template match="ROW/*" mode="ColumnHeaders">',
'            <th>',
'              <!-- Put the value of the *name* of the current element -->',
'              <xsl:value-of select="name(.)"/>',
'            </th>',
'          </xsl:template>',
'        </xsl:stylesheet>     ',
'   ]''); ',
'end;',
'/',
'create or replace PACKAGE BODY "EBA_DEMO_XSLT" is ',
'    function results_div(p_prefix varchar2, p_message varchar2) return varchar2 is',
'    begin',
'        return ''<div class="sql-results"><strong>''||p_prefix||'':</strong> ''||p_message||''</div>'';',
'    end;',
'',
'    function validate_sql_statement( p_sql clob) return varchar2 is',
'        l_cursor number := dbms_sql.open_cursor;',
'        l_first_word varchar2(200);',
'    begin',
'        if p_sql is not null then',
'            l_first_word := substr(regexp_substr ( p_sql, ''[A-z]*'' ),1,200);',
'            if upper(l_first_word) not in (''SELECT'',''WITH'') then',
'                return ''Query must start with SELECT or WITH'';',
'            end if;',
'            execute immediate ''alter session set cursor_sharing=force'';',
'            dbms_sql.parse( l_cursor, p_sql, dbms_sql.native );',
'            execute immediate ''alter session set cursor_sharing=exact'';',
'            dbms_sql.close_cursor( l_cursor );',
'        end if;',
'        return null;',
'    exception',
'        when others then',
'            execute immediate ''alter session set cursor_sharing=exact'';',
'            dbms_sql.close_cursor( l_cursor );',
'            return sqlerrm;',
'    end;',
'',
'    function html_for_sql( p_sql clob ) return clob is',
'        ctx dbms_xmlgen.ctxhandle;',
'        l_html clob;',
'        l_xml_clob clob;',
'        l_validate_result varchar2(4000);',
'        l_xml xmltype;',
'        c_stylesheet xmltype := eba_demo_xslt_stylesheets.c_rowset_to_table;',
'    begin',
'        if p_sql is not null then',
'            l_validate_result := validate_sql_statement(p_sql);',
'            if l_validate_result is null then',
'                ctx := dbms_xmlgen.newcontext(p_sql);',
'                dbms_xmlgen.setnullhandling(ctx, dbms_xmlgen.empty_tag);',
'                l_xml_clob := dbms_xmlgen.getxml(ctx);',
'                dbms_xmlgen.closecontext(ctx);',
'                if l_xml_clob is not null then',
'                    l_xml := xmltype(l_xml_clob);',
'                    select xmlserialize( content xmltransform(l_xml,c_stylesheet) as clob) into l_html from dual;',
'                else',
'                    l_html := results_div(''INFO'',''No rows found'');',
'                end if;',
'            else',
'                l_html := results_div(''ERROR'',l_validate_result);',
'            end if;',
'        end if;',
'        return l_html;',
'    end;',
'end;',
'/',
' '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(11149829339439824)
,p_script_id=>wwv_flow_imp.id(9389170708012824)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_XSLT'
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(11149947937439837)
,p_script_id=>wwv_flow_imp.id(9389170708012824)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_XSLT_STYLESHEETS'
);
wwv_flow_imp.component_end;
end;
/
