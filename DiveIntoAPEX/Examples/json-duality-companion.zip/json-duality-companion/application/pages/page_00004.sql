prompt --application/pages/page_00004
begin
--   Manifest
--     PAGE: 00004
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>4
,p_name=>'Create JSON Table'
,p_alias=>'CREATE-JSON-TABLE'
,p_step_title=>'Create JSON Table'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10357288778161069)
,p_plug_name=>'Create JSON Collection Table'
,p_icon_css_classes=>'fa-table'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8814489092863166)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(374144465300297)
,p_button_sequence=>30
,p_button_name=>'CREATE_NEW_TABLE'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(8911352582863399)
,p_button_image_alt=>'Create New JSON Collection Table'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(393935636993556)
,p_name=>'P4_NEW_JSON_COLLECTION_TABLE_NAME'
,p_is_required=>true
,p_item_sequence=>10
,p_prompt=>'New JSON Collection Table Name'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_colspan=>6
,p_field_template=>wwv_flow_imp.id(8910136086863392)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(394243783995845)
,p_name=>'P4_IGNORE_EXISTING_TABLE'
,p_item_sequence=>20
,p_item_default=>'N'
,p_prompt=>'Ignore Existing Table?'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(374259628300298)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Create New Table'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>12145179139473503
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(374293676300299)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(374259628300298)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Ignore Existing Table...'
,p_attribute_01=>'N'
,p_process_when=>'P4_IGNORE_EXISTING_TABLE'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>12145213187473504
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(374418783300300)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(374293676300299)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Drop Existing Table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(',
'  ''drop table %s cascade constraints'',',
'  :P4_NEW_JSON_COLLECTION_TABLE_NAME);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>12145338294473505
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(374544027300301)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(374259628300298)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create New JSON Collection'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(',
'  ''create json collection table %s'',',
'  :P4_NEW_JSON_COLLECTION_TABLE_NAME);'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>12145463538473506
);
wwv_flow_imp.component_end;
end;
/
