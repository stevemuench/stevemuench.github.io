prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Migrate JSON Tables'
,p_alias=>'MIGRATE-JSON-TABLES'
,p_step_title=>'Migrate JSON Tables to Duality Views'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'21'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(374628600300302)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(8794082938863123)
,p_plug_display_sequence=>10
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3285422964942908)
,p_plug_name=>'Flex'
,p_plug_display_sequence=>30
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3285559850942909)
,p_plug_name=>'Drop'
,p_plug_display_sequence=>60
,p_plug_new_grid_row=>false
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9340620244710712)
,p_plug_name=>'Migrate JSON Collection Tables to Duality Views'
,p_icon_css_classes=>'fa-magic'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8814489092863166)
,p_plug_display_sequence=>50
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11244303495242037)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(8847551824863235)
,p_plug_display_sequence=>90
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11244444711242038)
,p_plug_name=>'Tables to Migrate'
,p_parent_plug_id=>wwv_flow_imp.id(11244303495242037)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(9042410575926429)
,p_plug_name=>'Tables to Migrate'
,p_region_name=>'json_tables_to_migrate'
,p_parent_plug_id=>wwv_flow_imp.id(11244444711242038)
,p_region_css_classes=>'margin-top-md'
,p_region_template_options=>'#DEFAULT#'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8827972335863194)
,p_plug_display_sequence=>100
,p_plug_display_point=>'SUB_REGIONS'
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id,',
'       json_table_name,',
'       dualv_name',
'from table(json_duality_companion.json_tables_to_migrate)'))
,p_plug_source_type=>'NATIVE_IG'
,p_prn_units=>'INCHES'
,p_prn_paper_size=>'LETTER'
,p_prn_width=>11
,p_prn_height=>8.5
,p_prn_orientation=>'HORIZONTAL'
,p_prn_page_header_font_color=>'#000000'
,p_prn_page_header_font_family=>'Helvetica'
,p_prn_page_header_font_weight=>'normal'
,p_prn_page_header_font_size=>'12'
,p_prn_page_footer_font_color=>'#000000'
,p_prn_page_footer_font_family=>'Helvetica'
,p_prn_page_footer_font_weight=>'normal'
,p_prn_page_footer_font_size=>'12'
,p_prn_header_bg_color=>'#EEEEEE'
,p_prn_header_font_color=>'#000000'
,p_prn_header_font_family=>'Helvetica'
,p_prn_header_font_weight=>'bold'
,p_prn_header_font_size=>'10'
,p_prn_body_bg_color=>'#FFFFFF'
,p_prn_body_font_color=>'#000000'
,p_prn_body_font_family=>'Helvetica'
,p_prn_body_font_weight=>'normal'
,p_prn_body_font_size=>'10'
,p_prn_border_width=>.5
,p_prn_page_header_alignment=>'CENTER'
,p_prn_page_footer_alignment=>'CENTER'
,p_prn_border_color=>'#666666'
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9042792956926432)
,p_name=>'DUALV_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'DUALV_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_TEXT_FIELD'
,p_heading=>'Duality View Name to Create'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>50
,p_value_alignment=>'LEFT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
,p_is_required=>true
,p_max_length=>255
,p_enable_filter=>true
,p_filter_operators=>'C:S:CASE_INSENSITIVE:REGEXP'
,p_filter_is_required=>false
,p_filter_text_case=>'MIXED'
,p_filter_exact_match=>true
,p_filter_lov_type=>'DISTINCT'
,p_use_as_row_header=>false
,p_enable_sort_group=>true
,p_enable_control_break=>true
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9042865981926433)
,p_name=>'APEX$ROW_ACTION'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_ACTION'
,p_display_sequence=>20
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9042937217926434)
,p_name=>'APEX$ROW_SELECTOR'
,p_session_state_data_type=>'VARCHAR2'
,p_item_type=>'NATIVE_ROW_SELECTOR'
,p_display_sequence=>10
,p_attribute_01=>'Y'
,p_attribute_02=>'Y'
,p_attribute_03=>'N'
,p_use_as_row_header=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9043315122926438)
,p_name=>'ID'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'ID'
,p_data_type=>'NUMBER'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_HIDDEN'
,p_display_sequence=>30
,p_attribute_01=>'Y'
,p_use_as_row_header=>false
,p_enable_sort_group=>false
,p_is_primary_key=>true
,p_duplicate_value=>true
,p_include_in_export=>false
);
wwv_flow_imp_page.create_region_column(
 p_id=>wwv_flow_imp.id(9043488784926439)
,p_name=>'JSON_TABLE_NAME'
,p_source_type=>'DB_COLUMN'
,p_source_expression=>'JSON_TABLE_NAME'
,p_data_type=>'VARCHAR2'
,p_session_state_data_type=>'VARCHAR2'
,p_is_query_only=>false
,p_item_type=>'NATIVE_POPUP_LOV'
,p_heading=>'JSON Collection Table Name with Existing Documents'
,p_heading_alignment=>'LEFT'
,p_display_sequence=>40
,p_value_alignment=>'LEFT'
,p_attribute_01=>'POPUP'
,p_attribute_02=>'FIRST_ROWSET'
,p_attribute_04=>'N'
,p_attribute_05=>'N'
,p_is_required=>false
,p_lov_type=>'SQL_QUERY'
,p_lov_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select d, r',
'from',
'(',
'    select table_name d, table_name r',
'      from (',
'        select distinct table_name',
'          from user_tab_columns',
'         where data_type = ''JSON''',
'        minus',
'        select view_name',
'        from user_json_duality_views',
'        minus',
'        select d.referenced_name',
'        from user_json_duality_views v ',
'        left join user_dependencies d on d.name = v.view_name',
'                                        and d.type = ''VIEW''',
'                                        and d.referenced_type = ''TABLE'')',
')',
'where d not in (select json_table_name',
'                   from json_table(:P1_GRID_JSON_CONTENT, ''$[*]''',
'                      columns (',
'                         json_table_name varchar2(4000) path ''$.JSON_TABLE_NAME.v'' ',
'                      )) where json_table_name is not null)',
'order by d'))
,p_lov_display_extra=>false
,p_lov_display_null=>true
,p_lov_cascade_parent_items=>'ID'
,p_ajax_items_to_submit=>'P1_GRID_JSON_CONTENT'
,p_ajax_optimize_refresh=>true
,p_filter_is_required=>false
,p_static_id=>'JSON_TABLE_NAME'
,p_use_as_row_header=>false
,p_enable_hide=>true
,p_is_primary_key=>false
,p_duplicate_value=>true
,p_include_in_export=>true
);
wwv_flow_imp_page.create_interactive_grid(
 p_id=>wwv_flow_imp.id(9042575122926430)
,p_internal_uid=>9042575122926430
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_add_row_if_empty=>true
,p_submit_checked_rows=>false
,p_lazy_loading=>false
,p_requires_filter=>false
,p_select_first_row=>true
,p_fixed_row_height=>true
,p_pagination_type=>'SCROLL'
,p_show_total_row_count=>true
,p_show_toolbar=>true
,p_toolbar_buttons=>null
,p_add_button_label=>'Add JSON Table to Migrate'
,p_enable_save_public_report=>false
,p_enable_subscriptions=>true
,p_enable_flashback=>false
,p_define_chart_view=>false
,p_enable_download=>false
,p_download_formats=>null
,p_enable_mail_download=>true
,p_fixed_header=>'PAGE'
,p_show_icon_view=>false
,p_show_detail_view=>false
);
wwv_flow_imp_page.create_ig_report(
 p_id=>wwv_flow_imp.id(9098884446676397)
,p_interactive_grid_id=>wwv_flow_imp.id(9042575122926430)
,p_static_id=>'90989'
,p_type=>'PRIMARY'
,p_default_view=>'GRID'
,p_show_row_number=>false
,p_settings_area_expanded=>true
);
wwv_flow_imp_page.create_ig_report_view(
 p_id=>wwv_flow_imp.id(9099009527676398)
,p_report_id=>wwv_flow_imp.id(9098884446676397)
,p_view_type=>'GRID'
,p_stretch_columns=>true
,p_srv_exclude_null_values=>false
,p_srv_only_display_columns=>true
,p_edit_mode=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9100462833676417)
,p_view_id=>wwv_flow_imp.id(9099009527676398)
,p_display_seq=>3
,p_column_id=>wwv_flow_imp.id(9042792956926432)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9103853134704752)
,p_view_id=>wwv_flow_imp.id(9099009527676398)
,p_display_seq=>1
,p_column_id=>wwv_flow_imp.id(9042865981926433)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9108864561994523)
,p_view_id=>wwv_flow_imp.id(9099009527676398)
,p_display_seq=>4
,p_column_id=>wwv_flow_imp.id(9043315122926438)
,p_is_visible=>true
,p_is_frozen=>false
);
wwv_flow_imp_page.create_ig_report_column(
 p_id=>wwv_flow_imp.id(9109771084994529)
,p_view_id=>wwv_flow_imp.id(9099009527676398)
,p_display_seq=>2
,p_column_id=>wwv_flow_imp.id(9043488784926439)
,p_is_visible=>true
,p_is_frozen=>true
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11244560330242039)
,p_plug_name=>'Generated DDL'
,p_parent_plug_id=>wwv_flow_imp.id(11244303495242037)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10765757896206122)
,p_plug_name=>'Generated DDL'
,p_parent_plug_id=>wwv_flow_imp.id(11244560330242039)
,p_plug_display_sequence=>140
,p_plug_grid_column_css_classes=>'margin-top-md'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P1_DDL as value_edit,',
'       null    as value_diff,',
'       ''sql''   as language'))
,p_plug_source_type=>'PLUGIN_RW.APEX.VS.MONACO.EDITOR'
,p_plug_read_only_when_type=>'ALWAYS'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'calc(100vh - 30rem)',
  'attribute_02', 'begin null; end;',
  'attribute_03', 'sql',
  'attribute_04', 'vs',
  'attribute_05', 'search')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13362266939699046)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(374628600300302)
,p_button_name=>'INFER_AND_GENERATE_SCHEMA'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Generate DDL for Duality Views and Tables'
,p_icon_css_classes=>'fa-refresh'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11242324024242017)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(374628600300302)
,p_button_name=>'RUN_SCRIPT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Run Duality View DDL and Migrate Documents'
,p_button_condition=>':P1_OUTPUT_FORMAT = ''executable'' and :P1_DDL is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-database-play'
,p_grid_column_css_classes=>'u-align-self-center u-justify-content-center'
,p_grid_new_row=>'N'
,p_grid_new_column=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9040019508926405)
,p_name=>'P1_CONFIGURATION'
,p_data_type=>'CLOB'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9040246323926407)
,p_name=>'P1_DDL'
,p_data_type=>'CLOB'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9041030743926415)
,p_name=>'P1_USE_FLEX_FIELDS'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(3285422964942908)
,p_item_default=>'Y'
,p_prompt=>'Use Flex Fields'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'<p>When <code>useFlexFields</code> is true, for each duality view <em>VIEWNAME</em>, a flex column named <code>ORA$<em>VIEWNAME</em>_FLEX</code> is added to each table that directly underlies the top-level fields of an object in the supported documen'
||'ts. (The fields stored in a given flex column are unnested to that object.) The default value is <strong>true</strong>.</p>'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9041395989926418)
,p_name=>'P1_OUTPUT_FORMAT'
,p_item_sequence=>50
,p_item_default=>'executable'
,p_prompt=>'Format'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_lov=>'STATIC:PL/SQL;executable,SQL;standalone'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'NO'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Defines the format of the output data definition language (DDL) script. ',
'    The default value is <code>executable</code>, which means you can execute the DDL script directly:',
'    it uses PL/SQL <code>EXECUTE IMMEDIATE</code>. The other possible value is <code>standalone</code>, ',
'    which means you can use the DDL script in a SQL script that you run separately.',
'<p>',
'<p>',
'    If the generated DDL is larger than 32K bytes then you must use <code>standalone</code>; otherwise, an error',
'    is raised when you use <code>EXECUTE IMMEDIATE</code>. An <code>executable</code> script can be too large',
'    if the input data sets are themselves very large or they have many levels of nested values.',
'</p>'))
,p_attribute_01=>'NONE'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9041969600926424)
,p_name=>'P1_UPDATEABLE_DUALITY_VIEWS'
,p_item_sequence=>40
,p_item_default=>'Y'
,p_prompt=>'Updateable Views?'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<p>',
'    Determines whether the duality views to be generated are to be updatable (true) or not (false).',
'    When true, annotations are set for maximum updatability of each view. When false all of the',
'    views created are read-only. The default value is true.',
'</p>'))
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9044259628926447)
,p_name=>'P1_GRID_JSON_CONTENT'
,p_data_type=>'CLOB'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(9375204494897206)
,p_name=>'P1_CLEAR'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11242840417242022)
,p_name=>'P1_EXISTING_DUALITY_VIEWS'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11340984595400982)
,p_name=>'P1_IGNORE_EXISTING_VIEWS'
,p_item_sequence=>70
,p_item_plug_id=>wwv_flow_imp.id(3285559850942909)
,p_item_default=>'N'
,p_prompt=>'Ignore Existing Views?'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11341271329404548)
,p_name=>'P1_DROP_DEPENDENT_TABLES'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(3285559850942909)
,p_item_default=>'N'
,p_prompt=>'Also Drop Dependent Tables?'
,p_display_as=>'NATIVE_YES_NO'
,p_begin_on_new_line=>'N'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(11242724776242021)
,p_validation_name=>'Ensure Duality Views Don''t Exist Already'
,p_validation_sequence=>10
,p_validation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_existing_views varchar2(4000);',
'begin',
'    if nvl(:P1_IGNORE_EXISTING_VIEWS,''N'') = ''N'' then',
'        l_existing_views := json_duality_companion.existing_duality_views_to_migrate;',
'        if l_existing_views is not null then',
'            return ',
'                case ',
'                    when instr(l_existing_views,'','') > 0 ',
'                    then ''These target duality views already exist:'' ',
'                    else ''This target duality view already exists:''',
'                end',
'                ||'' ''',
'                ||l_existing_views;',
'        end if;',
'    end if;',
'    return null;',
'end;'))
,p_validation2=>'PLSQL'
,p_validation_type=>'FUNC_BODY_RETURNING_ERR_TEXT'
,p_when_button_pressed=>wwv_flow_imp.id(11242324024242017)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11241734499242011)
,p_name=>'When Format Changed - DDL'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OUTPUT_FORMAT'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11241872710242012)
,p_event_id=>wwv_flow_imp.id(11241734499242011)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Clear DDL Hidden Item'
,p_action=>'NATIVE_CLEAR'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DDL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11242035335242014)
,p_event_id=>wwv_flow_imp.id(11241734499242011)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Clear Code Editor'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'monaco.editor.getModels()[0].setValue("");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9339560239710701)
,p_name=>'On Page Load'
,p_event_sequence=>30
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9044541952926450)
,p_event_id=>wwv_flow_imp.id(9339560239710701)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Get Grid Data as JSON'
,p_action=>'PLUGIN_CA.INSUM.GETIGDATA'
,p_attribute_01=>'json_tables_to_migrate'
,p_attribute_02=>'P1_GRID_JSON_CONTENT'
,p_attribute_03=>'ALL'
,p_attribute_04=>'JSON_TABLE_NAME'
,p_attribute_05=>'ID,DUALV_NAME'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9340466385710710)
,p_name=>'When Grid Row Initialized'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_imp.id(9042410575926429)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'NATIVE_IG|REGION TYPE|apexbeginrecordedit'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9044422582926449)
,p_event_id=>wwv_flow_imp.id(9340466385710710)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Get Grid Data as JSON'
,p_action=>'PLUGIN_CA.INSUM.GETIGDATA'
,p_attribute_01=>'json_tables_to_migrate'
,p_attribute_02=>'P1_GRID_JSON_CONTENT'
,p_attribute_03=>'ALL'
,p_attribute_04=>'JSON_TABLE_NAME'
,p_attribute_05=>'ID,DUALV_NAME'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9339798293710703)
,p_event_id=>wwv_flow_imp.id(9340466385710710)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'console.log($v(''P1_GRID_JSON_CONTENT''));'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(9376545639897219)
,p_name=>'When Table Name Changed'
,p_event_sequence=>60
,p_triggering_element_type=>'COLUMN'
,p_triggering_region_id=>wwv_flow_imp.id(9042410575926429)
,p_triggering_element=>'JSON_TABLE_NAME'
,p_condition_element_type=>'COLUMN'
,p_condition_element=>'JSON_TABLE_NAME'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(9376630889897220)
,p_event_id=>wwv_flow_imp.id(9376545639897219)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Default Duality View Name'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'COLUMN'
,p_affected_elements=>'DUALV_NAME'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'$v(''JSON_TABLE_NAME'')+"_DV"'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11241376002242007)
,p_name=>'When Format Changed - Switches'
,p_event_sequence=>70
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_OUTPUT_FORMAT'
,p_triggering_condition_type=>'JAVASCRIPT_EXPRESSION'
,p_triggering_expression=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$v(''P1_OUTPUT_FORMAT'') === "executable" && ',
'$v(''P1_DDL'')           !== ""'))
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11241429399242008)
,p_event_id=>wwv_flow_imp.id(11241376002242007)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_IGNORE_EXISTING_VIEWS,P1_DROP_DEPENDENT_TABLES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11241619490242010)
,p_event_id=>wwv_flow_imp.id(11241376002242007)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_IGNORE_EXISTING_VIEWS,P1_DROP_DEPENDENT_TABLES'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11242475854242018)
,p_event_id=>wwv_flow_imp.id(11241376002242007)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_SHOW'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11242324024242017)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11242534387242019)
,p_event_id=>wwv_flow_imp.id(11241376002242007)
,p_event_result=>'FALSE'
,p_action_sequence=>20
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(11242324024242017)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(4374457558995582)
,p_name=>'When Ignore Switch Changed'
,p_event_sequence=>80
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_IGNORE_EXISTING_VIEWS'
,p_condition_element=>'P1_IGNORE_EXISTING_VIEWS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4374823736995594)
,p_event_id=>wwv_flow_imp.id(4374457558995582)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Enable Drop Switch'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$("#P1_DROP_DEPENDENT_TABLES").parent(".a-Switch").removeClass("apex_disabled");',
'',
''))
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(4375334894995596)
,p_event_id=>wwv_flow_imp.id(4374457558995582)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Disable Drop Switch'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P1_DROP_DEPENDENT_TABLES").parent(".a-Switch").addClass("apex_disabled");'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3285101366942905)
,p_name=>'When Use Flex Switch Changed'
,p_event_sequence=>90
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_USE_FLEX_FIELDS'
,p_condition_element=>'P1_USE_FLEX_FIELDS'
,p_triggering_condition_type=>'EQUALS'
,p_triggering_expression=>'Y'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3285250171942906)
,p_event_id=>wwv_flow_imp.id(3285101366942905)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Enable Min Frequency'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_MIN_FREQUENCY'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3285365962942907)
,p_event_id=>wwv_flow_imp.id(3285101366942905)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Disable Min Frequency'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_MIN_FREQUENCY'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9041759262926422)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Create Duality Views and Tables'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(13362266939699046)
,p_internal_uid=>9041759262926422
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(358040695511596)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Run Generated DDL Script'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11242324024242017)
,p_internal_uid=>12128960206684801
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9375350013897207)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Clearing Tables to Migrate...'
,p_attribute_01=>'N'
,p_process_when=>'P1_CLEAR'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>9375350013897207
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(525499331931157)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(525611192931158)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Drop Existing Duality Views'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'DROP_DUALITY_VIEWS_TO_MIGRATE'
,p_internal_uid=>11245420179242048
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(525366728931156)
,p_page_process_id=>wwv_flow_imp.id(525499331931157)
,p_page_id=>1
,p_name=>'p_drop_related_tables'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_DROP_DEPENDENT_TABLES'
,p_format_mask=>'Y,N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1148084184932706)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(1148019231932705)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Drop Dependent Tables from DDL'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'DROP_TABLES_FROM_DDL'
,p_internal_uid=>12919003696105911
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(1148197957932707)
,p_page_process_id=>wwv_flow_imp.id(1148084184932706)
,p_page_id=>1
,p_name=>'p_ddl'
,p_direction=>'IN'
,p_data_type=>'CLOB'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_DDL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9044188576926446)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9044068943926445)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Clear DDL'
,p_process_sql_clob=>':P1_DDL := null;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9044188576926446
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9375495763897208)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(9375350013897207)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Clear Tables to Migrate'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'CLEAR_JSON_TABLES_TO_MIGRATE'
,p_internal_uid=>9375495763897208
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9043001700926435)
,p_process_sequence=>20
,p_region_id=>wwv_flow_imp.id(9042410575926429)
,p_parent_process_id=>wwv_flow_imp.id(9041759262926422)
,p_process_type=>'NATIVE_IG_DML'
,p_process_name=>'Tables to Migrate - Save Interactive Grid Data'
,p_attribute_01=>'PLSQL_CODE'
,p_attribute_04=>wwv_flow_string.join(wwv_flow_t_varchar2(
'case :APEX$ROW_STATUS',
'when ''C'' then',
'    :ID := json_duality_companion.add_json_table_to_migrate(',
'            :JSON_TABLE_NAME,',
'            :DUALV_NAME);',
'when ''U'' then',
'    json_duality_companion.update_json_table_to_migrate(',
'            json_duality_companion.t_json_table_to_migrate(',
'                :ID,',
'                :JSON_TABLE_NAME,',
'                :DUALV_NAME));',
'when ''D'' then',
'    json_duality_companion.remove_json_table_to_migrate(',
'            json_duality_companion.t_json_table_to_migrate(',
'                :ID,',
'                :JSON_TABLE_NAME,',
'                :DUALV_NAME));',
'end case;',
''))
,p_attribute_05=>'N'
,p_attribute_06=>'N'
,p_internal_uid=>9043001700926435
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11242297900242016)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(9041759262926422)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Ensure at Least One Table'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if json_duality_companion.count_json_tables_to_migrate = 0 then',
'    apex_error.add_error (',
'        p_message          => ''Please select at least one table to migrate'',',
'        p_display_location => apex_error.c_on_error_page);',
'end if;'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11242297900242016
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9043936557926444)
,p_process_sequence=>30
,p_parent_process_id=>wwv_flow_imp.id(9041759262926422)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Any Tables to Migrate...'
,p_attribute_01=>'N'
,p_process_when=>'json_duality_companion.json_tables_to_migrate_count > 0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>9043936557926444
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9044068943926445)
,p_process_sequence=>40
,p_parent_process_id=>wwv_flow_imp.id(9041759262926422)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Else...'
,p_attribute_01=>'N'
,p_process_when=>'json_duality_companion.json_tables_to_migrate_count = 0'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>9044068943926445
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9040663842926411)
,p_process_sequence=>50
,p_parent_process_id=>wwv_flow_imp.id(9043936557926444)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Adjust Configuration'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'JSON_DUALITY_MIGRATOR_CONFIG'
,p_internal_uid=>9040663842926411
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9040736377926412)
,p_page_process_id=>wwv_flow_imp.id(9040663842926411)
,p_page_id=>1
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_CONFIGURATION'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9040959909926414)
,p_page_process_id=>wwv_flow_imp.id(9040663842926411)
,p_page_id=>1
,p_name=>'p_use_flex_fields'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'ITEM'
,p_value=>'P1_USE_FLEX_FIELDS'
,p_format_mask=>'Y,N'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9041444600926419)
,p_page_process_id=>wwv_flow_imp.id(9040663842926411)
,p_page_id=>1
,p_name=>'p_output_format'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'ITEM'
,p_value=>'P1_OUTPUT_FORMAT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9042293611926427)
,p_page_process_id=>wwv_flow_imp.id(9040663842926411)
,p_page_id=>1
,p_name=>'p_updatable_duality_views'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>50
,p_value_type=>'ITEM'
,p_value=>'P1_UPDATEABLE_DUALITY_VIEWS'
,p_format_mask=>'Y,N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(13362370007699047)
,p_process_sequence=>60
,p_parent_process_id=>wwv_flow_imp.id(9043936557926444)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Infer and Generate Schema'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'DBMS_JSON_DUALITY'
,p_attribute_04=>'INFER_AND_GENERATE_SCHEMA'
,p_internal_uid=>13362370007699047
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(9039627172926401)
,p_page_process_id=>wwv_flow_imp.id(13362370007699047)
,p_page_id=>1
,p_name=>'config'
,p_direction=>'IN'
,p_data_type=>'JSON'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>'JSON(:P1_CONFIGURATION)'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(13362670642699050)
,p_page_process_id=>wwv_flow_imp.id(13362370007699047)
,p_page_id=>1
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_DDL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(9041841170926423)
,p_process_sequence=>70
,p_parent_process_id=>wwv_flow_imp.id(9043936557926444)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Trim Unprintable Characters'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P1_DDL := RTRIM(:P1_DDL,CHR(0));',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>9041841170926423
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11243189340242025)
,p_process_sequence=>80
,p_parent_process_id=>wwv_flow_imp.id(9043936557926444)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Change RAW _id to VARCHAR2'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'CHANGE_RAW_IDS_TO_VARCHAR2'
,p_process_success_message=>'Generated Duality View DDL Successfully'
,p_internal_uid=>11243189340242025
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11243258962242026)
,p_page_process_id=>wwv_flow_imp.id(11243189340242025)
,p_page_id=>1
,p_name=>'p_ddl'
,p_direction=>'IN_OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_DDL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(525611192931158)
,p_process_sequence=>90
,p_parent_process_id=>wwv_flow_imp.id(358040695511596)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Ignoring Duality View Existence...'
,p_attribute_01=>'N'
,p_process_when=>'P1_IGNORE_EXISTING_VIEWS'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>11245308318242047
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(1148019231932705)
,p_process_sequence=>100
,p_parent_process_id=>wwv_flow_imp.id(358040695511596)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Dropping Dependent Tables...'
,p_attribute_01=>'N'
,p_process_when=>'P1_DROP_DEPENDENT_TABLES'
,p_process_when_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_process_when2=>'Y'
,p_internal_uid=>12918938743105910
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(525266862931155)
,p_process_sequence=>110
,p_parent_process_id=>wwv_flow_imp.id(358040695511596)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Create Generated Artifacts'
,p_process_sql_clob=>'execute immediate :P1_DDL;'
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>11245652648242050
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(358177594511597)
,p_process_sequence=>120
,p_parent_process_id=>wwv_flow_imp.id(358040695511596)
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Import JSON Collection Tables to New Duality Views'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'IMPORT_DUALITY_VIEWS_TO_MIGRATE'
,p_process_success_message=>'Ran DDL and Migrated Documents Successfully'
,p_internal_uid=>12129097105684802
);
wwv_flow_imp.component_end;
end;
/
