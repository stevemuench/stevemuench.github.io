prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Show Definition'
,p_alias=>'SHOW-DEFINITION'
,p_step_title=>'Show Definition'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10372213565272456)
,p_plug_name=>'Show Definition and Related Tables for Duality View'
,p_icon_css_classes=>'fa-network-hub'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8814489092863166)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11243595530242029)
,p_plug_name=>'Tabs'
,p_region_template_options=>'#DEFAULT#:js-useLocalStorage:t-TabsRegion-mod--simple'
,p_plug_template=>wwv_flow_imp.id(8847551824863235)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P6_DUALV_NAME'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11243697409242030)
,p_plug_name=>'Definition'
,p_parent_plug_id=>wwv_flow_imp.id(11243595530242029)
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11243848881242032)
,p_plug_name=>'Definition'
,p_parent_plug_id=>wwv_flow_imp.id(11243697409242030)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'margin-top-md'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT dbms_metadata.get_ddl(''VIEW'',:P6_DUALV_NAME) as value_edit,',
'       null as value_diff,',
'       ''sql'' as language'))
,p_plug_source_type=>'PLUGIN_RW.APEX.VS.MONACO.EDITOR'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'calc(100vh - 27rem)',
  'attribute_02', 'begin null; end;',
  'attribute_03', 'sql',
  'attribute_04', 'vs',
  'attribute_05', 'search')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11243779199242031)
,p_plug_name=>'Related Tables'
,p_parent_plug_id=>wwv_flow_imp.id(11243595530242029)
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10767766526206142)
,p_plug_name=>'Diagram'
,p_parent_plug_id=>wwv_flow_imp.id(11243779199242031)
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source_type=>'PLUGIN_MERMAID_DIAGRAM'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_item', 'P6_DIAGRAM')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(12526732576873692)
,p_plug_name=>'No JSON Relational Duality Views Yet'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(8765996742863054)
,p_plug_display_sequence=>60
,p_location=>null
,p_plug_source_type=>'PLUGIN_MARKDOWN'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P6_DUALV_NAME'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'file_name', 'nothing_to_describe.md',
  'source', 'APPLICATION_STATIC_FILE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10766325322206128)
,p_name=>'P6_DIAGRAM'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11142062189005650)
,p_name=>'P6_DUALV_NAME'
,p_item_sequence=>10
,p_prompt=>'Duality View Name'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'LOV_DUALITY_VIEWS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select view_name d, view_name r, ''fa-eye'' icon',
'from user_json_duality_views',
'order by view_name'))
,p_cSize=>30
,p_colspan=>6
,p_display_when=>'P6_DUALV_NAME'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_09=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11243973939242033)
,p_name=>'P6_DDL'
,p_data_type=>'CLOB'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(11142432005009895)
,p_computation_sequence=>30
,p_computation_item=>'P6_DUALV_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(view_name)',
'from user_json_duality_views',
'where view_name = :P6_DUALV_NAME'))
,p_computation_comment=>'Set the value to null if it''s current value is no longer a valid duality view name.'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(358198083511598)
,p_computation_sequence=>40
,p_computation_item=>'P6_DUALV_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select view_name',
'from user_json_duality_views',
'order by case when view_name = coalesce(:P2_DUALV_NAME,:P3_DUALV_NAME) then 0 else 1 end, view_name',
'fetch first row only'))
,p_compute_when=>'P6_DUALV_NAME'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(11244081010242034)
,p_computation_sequence=>50
,p_computation_item=>'P6_DDL'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'dbms_metadata.get_ddl(''VIEW'',:P6_DUALV_NAME)'
,p_compute_when=>'P6_DUALV_NAME'
,p_compute_when_type=>'ITEM_IS_NOT_NULL'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10766823316206133)
,p_name=>'When View Name Changes'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P6_DUALV_NAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10766932539206134)
,p_event_id=>wwv_flow_imp.id(10766823316206133)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P6_DIAGRAM := json_duality_companion.diagram_text_for_dualv(:P6_DUALV_NAME);',
':P6_DDL := dbms_metadata.get_ddl(''VIEW'',:P6_DUALV_NAME);'))
,p_attribute_02=>'P6_DUALV_NAME'
,p_attribute_03=>'P6_DIAGRAM,P6_DDL'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10768065272206145)
,p_event_id=>wwv_flow_imp.id(10766823316206133)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10767766526206142)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11244139135242035)
,p_event_id=>wwv_flow_imp.id(10766823316206133)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_name=>'Update Code Editor'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'monaco.editor.getModels()[0].setValue($v(''P6_DDL''));'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10766524627206130)
,p_process_sequence=>10
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Get Diagram Text'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'JSON_DUALITY_COMPANION'
,p_attribute_04=>'DIAGRAM_TEXT_FOR_DUALV'
,p_process_when=>'P6_DUALV_NAME'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>10766524627206130
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10766688474206131)
,p_page_process_id=>wwv_flow_imp.id(10766524627206130)
,p_page_id=>6
,p_direction=>'OUT'
,p_data_type=>'CLOB'
,p_ignore_output=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P6_DIAGRAM'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(10766799405206132)
,p_page_process_id=>wwv_flow_imp.id(10766524627206130)
,p_page_id=>6
,p_name=>'p_dualv_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P6_DUALV_NAME'
);
wwv_flow_imp.component_end;
end;
/
