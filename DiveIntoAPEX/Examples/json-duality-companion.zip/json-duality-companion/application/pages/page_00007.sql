prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Experiment with SQL'
,p_alias=>'EXPERIMENT-WITH-SQL'
,p_step_title=>'Experiment with SQL'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.sql-results tbody { font-family: Courier; font-size: 10pt }',
'.sql-results  thead tr th { font-weight: boldest;   border-bottom: 1px dotted lightgrey; }',
'.sql-results  tr { padding-top: 5px }',
'.sql-results  td,th { padding-left: 5px; padding-right: 5px; text-align: left; border-right: 1px dotted lightgrey; }',
'.sql-results  td:last-child, th:last-child { border-right: none }',
'.sql-results tbody tr:nth-child(even) {background: lightblue; color: black}',
'.sql-results table { ',
'    border-spacing: 0;',
'    border-collapse: collapse;',
'}'))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'25'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10767034855206135)
,p_plug_name=>'SQL Query'
,p_region_css_classes=>'margin-top-md'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8771145704863072)
,p_plug_display_sequence=>20
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P7_SQL as value_edit,',
'       null    as value_diff,',
'       ''sql''   as language'))
,p_plug_source_type=>'PLUGIN_RW.APEX.VS.MONACO.EDITOR'
,p_ajax_items_to_submit=>'P1_SQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', '30vh',
  'attribute_02', 'begin null; end;',
  'attribute_03', 'sql',
  'attribute_04', 'vs')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10767383605206138)
,p_plug_name=>'Results'
,p_region_template_options=>'#DEFAULT#:t-Region--noUI:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(8837793661863214)
,p_plug_display_sequence=>40
,p_location=>null
,p_function_body_language=>'PLSQL'
,p_plug_source=>'return eba_demo_xslt.html_for_sql(apex_session_state.get_clob(''P7_SQL''));'
,p_plug_source_type=>'NATIVE_DYNAMIC_CONTENT'
,p_ajax_items_to_submit=>'P7_SQL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10790426191112579)
,p_plug_name=>'Experiment with SQL'
,p_icon_css_classes=>'fa-file-sql-o'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8814489092863166)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10767229537206137)
,p_button_sequence=>10
,p_button_name=>'RUN_QUERY'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Run Query'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-database-play'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10767187204206136)
,p_name=>'P7_SQL'
,p_item_sequence=>30
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10767407990206139)
,p_name=>'When Click Run Query'
,p_event_sequence=>10
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10767229537206137)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10767574432206140)
,p_event_id=>wwv_flow_imp.id(10767407990206139)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_name=>'Copy Code Editor to P7_SQL'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P7_SQL'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11241025283242004)
,p_event_id=>wwv_flow_imp.id(10767407990206139)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'// First clear the errors',
'apex.message.clearErrors();',
'',
'// Now show new errors',
'apex.message.showErrors( [',
'    {',
'        type:       "error",',
'        location:   "page",',
'        message:    "Please provide a SQL query to run",',
'        unsafe:     false',
'    }',
'] );'))
,p_client_condition_type=>'NULL'
,p_client_condition_element=>'P7_SQL'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10767648637206141)
,p_event_id=>wwv_flow_imp.id(10767407990206139)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(10767383605206138)
,p_client_condition_type=>'NOT_NULL'
,p_client_condition_element=>'P7_SQL'
);
wwv_flow_imp.component_end;
end;
/
