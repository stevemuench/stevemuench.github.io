prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.05.31'
,p_release=>'24.1.1'
,p_default_workspace_id=>7216627174553626
,p_default_application_id=>103
,p_default_id_offset=>11770919511173205
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Browse/Edit JSON'
,p_alias=>'BROWSE-EDIT-JSON'
,p_step_title=>'Browse/Edit JSON'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'apex.page.warnOnUnsavedChanges( "", () => {',
'',
'    const oldDoc = $v(''P3_JSON_DOCUMENT_OLD'').replace(/\r\n/g, ''\n'');',
'    const newDoc = monaco.editor.getModels()[0].getValue().replace(/\r\n/g, ''\n'');',
'',
'    // Compare the normalized strings',
'    return oldDoc !== newDoc;',
'} );'))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'16'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(373985499300296)
,p_plug_name=>'No JSON Relational Duality Views or JSON Collection Tables to Browse Yet'
,p_region_template_options=>'#DEFAULT#:t-Alert--horizontal:t-Alert--defaultIcons:t-Alert--info'
,p_plug_template=>wwv_flow_imp.id(8765996742863054)
,p_plug_display_sequence=>180
,p_location=>null
,p_plug_source_type=>'PLUGIN_MARKDOWN'
,p_plug_display_condition_type=>'ITEM_IS_NULL'
,p_plug_display_when_condition=>'P3_DUALV_NAME_ORIG'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'file_name', 'nothing_to_browse.md',
  'source', 'APPLICATION_STATIC_FILE')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10140665995899208)
,p_plug_name=>'Browse/Edit JSON'
,p_title=>'Browse/Edit JSON Duality View and Collection Table Documents'
,p_icon_css_classes=>'fa-server-edit'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8814489092863166)
,p_plug_display_sequence=>30
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10141021845899212)
,p_plug_name=>'JSON Document Form'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8771145704863072)
,p_plug_display_sequence=>70
,p_query_type=>'FUNC_BODY_RETURNING_SQL'
,p_function_body_language=>'PLSQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'return case',
'        when :P3_DUALV_NAME is not null then',
'            apex_string.format(q''~',
'            select resid,',
'                   etag,',
'                   json_serialize(data returning clob pretty %s) as json_document',
'            from %s',
'            order by resid',
'            ~'',',
'            case when nvl(:P3_USE_EJSON,''N'')=''Y'' then ''extended'' end,',
'            :P3_DUALV_NAME)',
'        else',
'            -- Make the APEX Builder query parser happy when :P3_DUALV_NAME is null',
'            q''~',
'            select cast(null as varchar2(255)) as resid, ',
'                   cast(null as varchar2(255)) as etag, ',
'                   to_clob(null)               as json_document',
'              from dual',
'            ~''',
'       end;'))
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
,p_ajax_items_to_submit=>'P3_USE_EJSON,P3_DUALV_NAME'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P3_DUALV_NAME_ORIG'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(10141398027899215)
,p_plug_name=>'JSON Editor'
,p_region_css_classes=>'margin-top-md'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(8771145704863072)
,p_plug_display_sequence=>80
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select :P3_JSON_DOCUMENT as value_edit,',
'       null              as value_diff,',
'       ''json''            as language'))
,p_plug_source_type=>'PLUGIN_RW.APEX.VS.MONACO.EDITOR'
,p_ajax_items_to_submit=>'P3_JSON_DOCUMENT'
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P3_DUALV_NAME_ORIG'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'attribute_01', 'calc(100vh - 30rem)',
  'attribute_02', 'begin null; end;',
  'attribute_03', 'json',
  'attribute_04', 'vs',
  'attribute_05', 'search')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11168238846659421)
,p_plug_name=>'Buttons'
,p_region_template_options=>'#DEFAULT#:t-ButtonRegion--noUI'
,p_plug_template=>wwv_flow_imp.id(8794082938863123)
,p_plug_display_sequence=>50
,p_location=>null
,p_plug_display_condition_type=>'ITEM_IS_NOT_NULL'
,p_plug_display_when_condition=>'P3_DUALV_NAME_ORIG'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3286307241942917)
,p_plug_name=>'Extended Indicator'
,p_parent_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_plug_display_sequence=>10
,p_plug_grid_column_css_classes=>'u-align-self-center'
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'<em>Extended JSON</em>:'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(3286479774942918)
,p_plug_name=>'Extended JSON Toggle'
,p_parent_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3285787560942912)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3286479774942918)
,p_button_name=>'USE_EXTENDED_JSON'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'OFF'
,p_button_condition=>'P3_USE_EJSON'
,p_button_condition2=>'N'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-align-left'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(3285913756942913)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(3286479774942918)
,p_button_name=>'USE_STANDARD_JSON'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'ON'
,p_button_condition=>'P3_USE_EJSON'
,p_button_condition2=>'Y'
,p_button_condition_type=>'VAL_OF_ITEM_IN_COND_EQ_COND2'
,p_icon_css_classes=>'fa-ai-sparkle-generate-text'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10763740799206102)
,p_button_sequence=>30
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'SAVE_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Save'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P3_RESID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10768230642206147)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'DELETE_DOCUMENT'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Delete'
,p_button_position=>'NEXT'
,p_button_condition=>'P3_RESID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10764275575206107)
,p_button_sequence=>60
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'CREATE_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Add New'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P3_RESID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-server-new'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11168320559659422)
,p_button_sequence=>80
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'DUPLICATE_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Duplicate'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P3_RESID'
,p_button_condition_type=>'ITEM_IS_NOT_NULL'
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11244681039242040)
,p_button_sequence=>90
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'REREAD_DOCUMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Reread'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_RESID:&P3_RESID.'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10764927172206114)
,p_button_sequence=>100
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'ADD_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Save New'
,p_button_position=>'NEXT'
,p_warn_on_unsaved_changes=>null
,p_button_condition=>'P3_RESID'
,p_button_condition_type=>'ITEM_IS_NULL'
,p_icon_css_classes=>'fa-save'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10768414071206149)
,p_button_sequence=>110
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'CANCEL_ADD_DOCUMENT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Cancel'
,p_button_position=>'NEXT'
,p_button_redirect_url=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_RESID:&P3_RESID_FOR_CANCEL.'
,p_button_condition=>':P3_RESID is null and :P3_RESID_FOR_CANCEL is not null'
,p_button_condition2=>'PLSQL'
,p_button_condition_type=>'EXPRESSION'
,p_icon_css_classes=>'fa-remove'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10141699245899218)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'PREVIOUS_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Previous'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-left'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(10141505117899217)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(11168238846659421)
,p_button_name=>'NEXT_DOCUMENT'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft'
,p_button_template_id=>wwv_flow_imp.id(8911484282863400)
,p_button_image_alt=>'Next'
,p_button_position=>'PREVIOUS'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-chevron-right'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10143136125899233)
,p_branch_name=>'Next Document'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_RESID,P3_DUALV_NAME:&P3_NEXT_PRIMARY_KEY.,&P3_DUALV_NAME_ORIG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10141505117899217)
,p_branch_sequence=>10
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10143335314899235)
,p_branch_name=>'Previous Document'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_RESID,P3_DUALV_NAME:&P3_PREVIOUS_PRIMARY_KEY.,&P3_DUALV_NAME_ORIG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10141699245899218)
,p_branch_sequence=>20
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10764835010206113)
,p_branch_name=>'Create Document'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_CREATE_DOCUMENT,P3_RESID_FOR_CANCEL,P3_DUALV_NAME:Y,&P3_RESID.,&P3_DUALV_NAME_ORIG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(10764275575206107)
,p_branch_sequence=>30
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(11168960051659428)
,p_branch_name=>'Duplicate Document'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_CREATE_DOCUMENT,P3_RESID_FOR_CANCEL,P3_DUPLICATE,P3_DUALV_NAME:Y,&P3_RESID.,Y,&P3_DUALV_NAME_ORIG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_when_button_id=>wwv_flow_imp.id(11168320559659422)
,p_branch_sequence=>40
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(10768594284206150)
,p_branch_name=>'Stay on Same Doc for Save and Add'
,p_branch_action=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::P3_RESID,P3_DUALV_NAME:&P3_RESID.,&P3_DUALV_NAME_ORIG.&success_msg=#SUCCESS_MSG#'
,p_branch_point=>'AFTER_PROCESSING'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>50
,p_branch_condition_type=>'REQUEST_IN_CONDITION'
,p_branch_condition=>'|ADD_DOCUMENT|SAVE_DOCUMENT|'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(525741203931160)
,p_name=>'P3_DUALV_NAME_ORIG'
,p_item_sequence=>170
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3286031254942914)
,p_name=>'P3_USE_EJSON'
,p_item_sequence=>200
,p_item_default=>'N'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10140825738899210)
,p_name=>'P3_DUALV_NAME'
,p_item_sequence=>10
,p_prompt=>'Collection Table or Duality View Name'
,p_display_as=>'NATIVE_SELECT_ONE'
,p_named_lov=>'LOV_JSON_COLLECTIONS'
,p_lov=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select collection_name, collection_name as collection_name2, case collection_type when ''DUALITY VIEW'' then ''fa-eye'' when ''TABLE'' then ''fa-table'' end collection_type_icon',
'from user_json_collections',
'order by collection_name'))
,p_cSize=>30
,p_display_when=>'P3_DUALV_NAME_ORIG'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_warn_on_unsaved_changes=>'I'
,p_attribute_01=>'CONTAINS'
,p_attribute_02=>'N'
,p_attribute_04=>'N'
,p_attribute_09=>'0'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10141217099899214)
,p_name=>'P3_JSON_DOCUMENT'
,p_data_type=>'CLOB'
,p_source_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(10141021845899212)
,p_item_source_plug_id=>wwv_flow_imp.id(10141021845899212)
,p_source=>'JSON_DOCUMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10141719377899219)
,p_name=>'P3_NEXT_PRIMARY_KEY'
,p_item_sequence=>90
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10141804825899220)
,p_name=>'P3_PREVIOUS_PRIMARY_KEY'
,p_item_sequence=>100
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10141996719899221)
,p_name=>'P3_PAGINATION_DISPLAY'
,p_item_sequence=>110
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10142372202899225)
,p_name=>'P3_URL_TO_THIS_PAGE'
,p_item_sequence=>120
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10142867679899230)
,p_name=>'P3_JSON_DOCUMENT_OLD'
,p_item_sequence=>130
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10143058040899232)
,p_name=>'P3_ETAG'
,p_source_data_type=>'VARCHAR2'
,p_is_query_only=>true
,p_item_sequence=>40
,p_item_source_plug_id=>wwv_flow_imp.id(10141021845899212)
,p_source=>'ETAG'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10765612405206121)
,p_name=>'P3_CREATE_DOCUMENT'
,p_item_sequence=>140
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10765825964206123)
,p_name=>'P3_RESID'
,p_source_data_type=>'VARCHAR2'
,p_is_primary_key=>true
,p_item_sequence=>30
,p_item_source_plug_id=>wwv_flow_imp.id(10141021845899212)
,p_prompt=>'Current Document RESID'
,p_source=>'RESID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_begin_on_new_line=>'N'
,p_display_when=>'P3_DUALV_NAME_ORIG'
,p_display_when_type=>'ITEM_IS_NOT_NULL'
,p_field_template=>wwv_flow_imp.id(8908843209863389)
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_protection_level=>'S'
,p_attribute_01=>'Y'
,p_attribute_02=>'VALUE'
,p_attribute_04=>'Y'
,p_attribute_05=>'PLAIN'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(10768338895206148)
,p_name=>'P3_RESID_FOR_CANCEL'
,p_item_sequence=>150
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11169032376659429)
,p_name=>'P3_DUPLICATE'
,p_item_sequence=>160
,p_display_as=>'NATIVE_HIDDEN'
,p_is_persistent=>'N'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10142918654899231)
,p_computation_sequence=>10
,p_computation_item=>'P3_JSON_DOCUMENT_OLD'
,p_computation_point=>'AFTER_HEADER'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P3_JSON_DOCUMENT'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10140929312899211)
,p_computation_sequence=>10
,p_computation_item=>'P3_DUALV_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select max(collection_name)',
'  from user_json_collections',
'where collection_name = :P3_DUALV_NAME'))
,p_computation_comment=>'Null out the P3_DUALV_NAME if it''s current value it no longer a valid duality view or JSON collection'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(11244799668242041)
,p_computation_sequence=>20
,p_computation_item=>'P3_DUALV_NAME'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'QUERY'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select collection_name',
'from user_json_collections',
'order by case when collection_name = :P2_DUALV_NAME then 0 else 1 end, collection_name',
'fetch first row only'))
,p_compute_when=>'P3_DUALV_NAME'
,p_compute_when_type=>'ITEM_IS_NULL'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(10765920786206124)
,p_computation_sequence=>30
,p_computation_item=>'P3_RESID'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'FUNCTION_BODY'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_first_resid varchar2(255);',
'begin',
'    execute immediate apex_string.format(''select resid from %s order by resid fetch first row only'', :P3_DUALV_NAME)',
'    into l_first_resid;',
'    return l_first_resid;',
'exception',
'    when no_data_found then',
'        return null;',
'end;'))
,p_compute_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P3_DUALV_NAME is not null and',
':P3_RESID      is     null and',
'nvl(:P3_CREATE_DOCUMENT,''N'')=''N'''))
,p_compute_when_text=>'PLSQL'
,p_compute_when_type=>'EXPRESSION'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(525623834931159)
,p_computation_sequence=>40
,p_computation_item=>'P3_DUALV_NAME_ORIG'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'ITEM_VALUE'
,p_computation=>'P3_DUALV_NAME'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(11246618846259719)
,p_validation_name=>'Ensure Some JSON is Provided'
,p_validation_sequence=>10
,p_validation=>'P3_JSON_DOCUMENT'
,p_validation_type=>'ITEM_NOT_NULL'
,p_error_message=>'JSON cannot be empty. Delete a document using the appropriate button.'
,p_associated_item=>wwv_flow_imp.id(10140825738899210)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_validation(
 p_id=>wwv_flow_imp.id(11246144915247180)
,p_validation_name=>'Ensure JSON is Valid'
,p_validation_sequence=>20
,p_validation=>'json_duality_companion.is_valid_json(:P3_JSON_DOCUMENT)'
,p_validation2=>'PLSQL'
,p_validation_type=>'EXPRESSION'
,p_error_message=>'Syntax error in JSON document'
,p_associated_item=>wwv_flow_imp.id(10140825738899210)
,p_error_display_location=>'INLINE_WITH_FIELD_AND_NOTIFICATION'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10142166994899223)
,p_name=>'When DualV Name Changed'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P3_DUALV_NAME'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10142505014899227)
,p_event_id=>wwv_flow_imp.id(10142166994899223)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P3_URL_TO_THIS_PAGE := apex_page.get_url(',
'                            p_page => :APP_PAGE_ID,',
'                            p_items => ''P3_DUALV_NAME'',',
'                            p_values => :P3_DUALV_NAME);'))
,p_attribute_02=>'P3_DUALV_NAME'
,p_attribute_03=>'P3_URL_TO_THIS_PAGE'
,p_attribute_04=>'N'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10142268392899224)
,p_event_id=>wwv_flow_imp.id(10142166994899223)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'apex.navigation.redirect(apex.items.P3_URL_TO_THIS_PAGE.value);'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10143449797899236)
,p_name=>'When Click Previous Document'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10141699245899218)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10143566090899237)
,p_event_id=>wwv_flow_imp.id(10143449797899236)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10143679009899238)
,p_event_id=>wwv_flow_imp.id(10143449797899236)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'PREVIOUS_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10143858352899240)
,p_name=>'When Click Next Document'
,p_event_sequence=>30
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10141505117899217)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10143753017899239)
,p_event_id=>wwv_flow_imp.id(10143858352899240)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10143934381899241)
,p_event_id=>wwv_flow_imp.id(10143858352899240)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'NEXT_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10763849793206103)
,p_name=>'When Click Save'
,p_event_sequence=>40
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10763740799206102)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10764023345206105)
,p_event_id=>wwv_flow_imp.id(10763849793206103)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10764187733206106)
,p_event_id=>wwv_flow_imp.id(10763849793206103)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'SAVE_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10764435066206109)
,p_name=>'When Click Create'
,p_event_sequence=>50
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10764275575206107)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10764645689206111)
,p_event_id=>wwv_flow_imp.id(10764435066206109)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10764751076206112)
,p_event_id=>wwv_flow_imp.id(10764435066206109)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'CREATE_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10765006485206115)
,p_name=>'When Click Add Document'
,p_event_sequence=>60
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(10764927172206114)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10765270681206117)
,p_event_id=>wwv_flow_imp.id(10765006485206115)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10765370569206118)
,p_event_id=>wwv_flow_imp.id(10765006485206115)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'ADD_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11166298972659401)
,p_name=>'On Page Load - Enable/Disable Previous Button'
,p_event_sequence=>70
,p_condition_element=>'P3_PREVIOUS_PRIMARY_KEY'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11166320233659402)
,p_event_id=>wwv_flow_imp.id(11166298972659401)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10141699245899218)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11166478692659403)
,p_event_id=>wwv_flow_imp.id(11166298972659401)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10141699245899218)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11166561900659404)
,p_name=>'On Page Load - Enable/Disable Next'
,p_event_sequence=>80
,p_condition_element=>'P3_NEXT_PRIMARY_KEY'
,p_triggering_condition_type=>'NOT_NULL'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11166633120659405)
,p_event_id=>wwv_flow_imp.id(11166561900659404)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_ENABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10141505117899217)
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11166735153659406)
,p_event_id=>wwv_flow_imp.id(11166561900659404)
,p_event_result=>'FALSE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_DISABLE'
,p_affected_elements_type=>'BUTTON'
,p_affected_button_id=>wwv_flow_imp.id(10141505117899217)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(11168586543659424)
,p_name=>'When Click Duplicate'
,p_event_sequence=>90
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(11168320559659422)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11168745302659426)
,p_event_id=>wwv_flow_imp.id(11168586543659424)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$s(''P3_JSON_DOCUMENT'',monaco.editor.getModels()[0].getValue());'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(11168804330659427)
,p_event_id=>wwv_flow_imp.id(11168586543659424)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_01=>'DUPLICATE_DOCUMENT'
,p_attribute_02=>'N'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144037316899242)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Save Document If Not Toggling EJSON'
,p_attribute_01=>'N'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when=>'|USE_STANDARD_JSON|USE_EXTENDED_JSON|'
,p_process_when_type=>'REQUEST_NOT_IN_CONDITION'
,p_internal_uid=>10144037316899242
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3286114140942915)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Use EJSON'
,p_process_sql_clob=>':P3_USE_EJSON := ''Y'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3285787560942912)
,p_internal_uid=>15057033652116120
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(3286270150942916)
,p_process_sequence=>30
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Use Standard JSON'
,p_process_sql_clob=>':P3_USE_EJSON := ''N'';'
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(3285913756942913)
,p_internal_uid=>15057189662116121
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10141147872899213)
,p_process_sequence=>20
,p_process_point=>'BEFORE_HEADER'
,p_region_id=>wwv_flow_imp.id(10141021845899212)
,p_process_type=>'NATIVE_FORM_INIT'
,p_process_name=>'Initialize form Browse/Edit View'
,p_attribute_01=>'P3_NEXT_PRIMARY_KEY'
,p_attribute_02=>'P3_PREVIOUS_PRIMARY_KEY'
,p_attribute_03=>'P3_PAGINATION_DISPLAY'
,p_process_when=>'P3_DUALV_NAME_ORIG'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>10141147872899213
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11169105193659430)
,p_process_sequence=>30
,p_process_point=>'BEFORE_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Duplicate ResId to Cancel Doc'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(q''~',
'   select json_serialize(',
'            json_transform(data,',
'                remove ''$."_id"'',',
'                remove ''$."_metadata"'')',
'             returning clob pretty)',
'     from %s',
'     where resid = :resid',
'~'', :P3_DUALV_NAME)',
'into :P3_JSON_DOCUMENT',
'using :P3_RESID_FOR_CANCEL;'))
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
'nvl(:P3_DUPLICATE,''N'')=''Y'' and ',
':P3_RESID_FOR_CANCEL is not null'))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>11169105193659430
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144224926899244)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(10144037316899242)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Document Exists...'
,p_attribute_01=>'N'
,p_process_when=>'P3_RESID'
,p_process_when_type=>'ITEM_IS_NOT_NULL'
,p_internal_uid=>10144224926899244
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144481745899246)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(10144224926899244)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'If Updating & Document Changed'
,p_attribute_01=>'N'
,p_process_when=>':P3_RESID is not null and coalesce(:P3_JSON_DOCUMENT,''~'') != coalesce(:P3_JSON_DOCUMENT_OLD,''~'')'
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'PLSQL'
,p_internal_uid=>10144481745899246
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144577636899247)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(10144139079899243)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert JSON Document'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(q''~',
'    insert into %s(data) ',
'    values (json(:data extended))',
'    returning resid, etag',
'         into :resid, :etag',
'~'',:P3_DUALV_NAME_ORIG)',
'using :P3_JSON_DOCUMENT',
'returning into :P3_RESID, :P3_ETAG;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10144577636899247
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144744155899249)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(10144656082899248)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Delete JSON Document'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(q''~',
'    delete from %s ',
'    where resid = :resid',
'      and etag  = :etag',
'~'',:P3_DUALV_NAME_ORIG)',
'using :P3_RESID, :P3_ETAG;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10144744155899249
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10763682800206101)
,p_process_sequence=>10
,p_parent_process_id=>wwv_flow_imp.id(10144481745899246)
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Update JSON Document'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'execute immediate apex_string.format(q''~',
'    update %s ',
'    set data = json(:data extended)',
'    where resid = :resid',
'~'',:P3_DUALV_NAME_ORIG)',
'using :P3_JSON_DOCUMENT, :P3_RESID;',
''))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>10763682800206101
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144139079899243)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(10144037316899242)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Else if Document is New...'
,p_attribute_01=>'N'
,p_process_when=>'P3_RESID'
,p_process_when_type=>'ITEM_IS_NULL'
,p_internal_uid=>10144139079899243
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(10144656082899248)
,p_process_sequence=>20
,p_parent_process_id=>wwv_flow_imp.id(10144224926899244)
,p_process_type=>'NATIVE_EXECUTION_CHAIN'
,p_process_name=>'Else If Deleting Document'
,p_attribute_01=>'N'
,p_process_when_button_id=>wwv_flow_imp.id(10768230642206147)
,p_internal_uid=>10144656082899248
);
wwv_flow_imp.component_end;
end;
/
