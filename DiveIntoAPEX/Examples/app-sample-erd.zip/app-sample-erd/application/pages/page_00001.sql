prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>15440109311117192192
,p_default_application_id=>1861
,p_default_id_offset=>1412858337662352
,p_default_owner=>'WKSP_APEXORDERDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'ER Diagram'
,p_alias=>'ER-DIAGRAM'
,p_step_title=>'ER Diagram'
,p_autocomplete_on_off=>'OFF'
,p_javascript_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'https://cdnjs.cloudflare.com/ajax/libs/mermaid/9.3.0/mermaid.min.js',
'#APP_FILES#svg-pan-zoom.min.js'))
,p_javascript_code_onload=>wwv_flow_string.join(wwv_flow_t_varchar2(
'mermaid.initialize({',
'            maxTextSize: 900000,',
'            startOnLoad: false,',
'            securityLevel: ''strict''',
'});',
'mermaid.mermaidAPI.render(''diagramsvg'',apex.items.P1_DIAGRAM.value,(svg) => {',
'    document.getElementById(''diagram'').innerHTML = svg;',
'});',
'// Configure panning and zooming for the SVG diagram',
'var panZoom = svgPanZoom(''#diagramsvg'', {maxZoom: 30});',
'// Workaround mentioned in svg-pan-zoom README to restore height to <svg> element',
'// https://github.com/bumbu/svg-pan-zoom',
'var svg = $("svg").first();',
'svg.height("85vh");',
'svg.css("maxWidth","100%");',
''))
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.include_columns {',
'   min-width: 6em;',
'}',
''))
,p_page_template_options=>'#DEFAULT#:t-DeferredRendering'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20231013151748'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(11964522704569150110)
,p_plug_name=>'Diagram'
,p_region_name=>'diagram'
,p_region_css_classes=>'mermaid'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(13436051134230557237)
,p_plug_display_sequence=>30
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(13464578528920914902)
,p_button_sequence=>50
,p_button_name=>'Refresh_Diagram'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13436189323250557350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Refresh'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(8813689006928909)
,p_button_sequence=>60
,p_button_name=>'Copy_Mermaid'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13436189323250557350)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Copy'
,p_button_position=>'BEFORE_NAVIGATION_BAR'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-copy'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(3380393021178)
,p_name=>'P1_PRETTY_NAMES'
,p_item_sequence=>40
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_item_default=>'N'
,p_prompt=>'Pretty?'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(13436187583623557347)
,p_item_css_classes=>'u-align-self-center margin-left-sm margin-right-sm include_columns'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Display id, audit, and row version columns?'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8814411309928917)
,p_name=>'P1_INCLUDE_COLUMNS'
,p_item_sequence=>20
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_item_default=>'N'
,p_prompt=>'Columns?'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(13436187583623557347)
,p_item_css_classes=>'u-align-self-center margin-left-sm margin-right-sm include_columns'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Show columns and datatypes?'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8814712527928920)
,p_name=>'P1_ALL_COLUMNS'
,p_item_sequence=>30
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_item_default=>'N'
,p_prompt=>'All?'
,p_display_as=>'NATIVE_YES_NO'
,p_field_template=>wwv_flow_imp.id(13436187583623557347)
,p_item_css_classes=>'u-align-self-center margin-left-sm margin-right-sm include_columns'
,p_item_template_options=>'#DEFAULT#'
,p_help_text=>'Display id, audit, and row version columns?'
,p_attribute_01=>'N'
,p_attribute_02=>'Y'
,p_attribute_04=>'N'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11964522585026150108)
,p_name=>'P1_DIAGRAM'
,p_data_type=>'CLOB'
,p_item_sequence=>20
,p_item_default=>'erDiagram'
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'Y'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(9060534669698001)
,p_computation_sequence=>10
,p_computation_item=>'P1_DIAGRAM'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>wwv_flow_string.join(wwv_flow_t_varchar2(
'eba_erd_mermaid.diagram_text(p_table_prefix     => :P0_TABLE_PREFIX,',
'                             p_include_columns  => :P1_INCLUDE_COLUMNS = ''Y'',',
'                             p_all_columns      => :P1_ALL_COLUMNS     = ''Y'',',
'                             p_pretty_tab_names => :P1_PRETTY_NAMES    = ''Y'')'))
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8813710770928910)
,p_name=>'On Click Copy Mermaid Text'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(8813689006928909)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8813832296928911)
,p_event_id=>wwv_flow_imp.id(8813710770928910)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'PLUGIN_APEX.COPY.TEXT.2.CLIPBOARD'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_DIAGRAM'
,p_attribute_01=>'2000'
,p_attribute_02=>'%0 copied to Clipboard!'
,p_attribute_03=>'12'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8814527950928918)
,p_name=>'On Change Show Columns'
,p_event_sequence=>30
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_INCLUDE_COLUMNS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8815062758928923)
,p_event_id=>wwv_flow_imp.id(8814527950928918)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_name=>'Enable All if Showing Columns'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P1_ALL_COLUMNS").parent(".a-Switch").removeClass("apex_disabled").attr(''tabindex'',''-1'');'
,p_client_condition_type=>'EQUALS'
,p_client_condition_element=>'P1_INCLUDE_COLUMNS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8815201318928925)
,p_event_id=>wwv_flow_imp.id(8814527950928918)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_name=>'Set All False if Hiding Columns'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P1_ALL_COLUMNS'
,p_attribute_01=>'STATIC_ASSIGNMENT'
,p_attribute_02=>'N'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8815156788928924)
,p_event_id=>wwv_flow_imp.id(8814527950928918)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'Y'
,p_name=>'Disable All if Hiding Columns'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>'$("#P1_ALL_COLUMNS").parent(".a-Switch").addClass("apex_disabled").attr(''tabindex'',''-1'');'
,p_client_condition_type=>'NOT_EQUALS'
,p_client_condition_element=>'P1_INCLUDE_COLUMNS'
,p_client_condition_expression=>'Y'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8814606406928919)
,p_event_id=>wwv_flow_imp.id(8814527950928918)
,p_event_result=>'TRUE'
,p_action_sequence=>50
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(8814868918928921)
,p_name=>'On Change All Columns'
,p_event_sequence=>40
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_ALL_COLUMNS'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(8814967065928922)
,p_event_id=>wwv_flow_imp.id(8814868918928921)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(3417457021179)
,p_name=>'On Change Pretty'
,p_event_sequence=>50
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P1_PRETTY_NAMES'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'change'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(3586590021180)
,p_event_id=>wwv_flow_imp.id(3417457021179)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SUBMIT_PAGE'
,p_attribute_02=>'Y'
);
wwv_flow_imp.component_end;
end;
/
