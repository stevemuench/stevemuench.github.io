prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>15440109311117192192
,p_default_application_id=>1861
,p_default_id_offset=>1412858337662352
,p_default_owner=>'WKSP_APEXORDERDEMO'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
,p_last_updated_by=>'STEVE'
,p_last_upd_yyyymmddhh24miss=>'20230101120452'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(8814307321928916)
,p_name=>'P0_TABLE_PREFIX'
,p_item_sequence=>10
,p_item_display_point=>'BEFORE_NAVIGATION_BAR'
,p_prompt=>'Table Prefix'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(13436187583623557347)
,p_item_css_classes=>'w100p padding-right-md'
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'N'
,p_attribute_02=>'N'
,p_attribute_04=>'TEXT'
,p_attribute_05=>'BOTH'
,p_attribute_06=>'UPPER'
);
wwv_flow_imp.component_end;
end;
/
