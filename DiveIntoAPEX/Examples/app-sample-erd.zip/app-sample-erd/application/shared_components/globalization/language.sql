prompt --application/shared_components/globalization/language
begin
--   Manifest
--     LANGUAGE MAP: 1861
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>15440109311117192192
,p_default_application_id=>1861
,p_default_id_offset=>1412858337662352
,p_default_owner=>'WKSP_APEXORDERDEMO'
);
null;
wwv_flow_imp.component_end;
end;
/
