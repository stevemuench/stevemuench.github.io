prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>11123263479045381
,p_default_application_id=>100
,p_default_id_offset=>2153279278969116
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Home'
,p_alias=>'HOME'
,p_step_title=>'Bulk Zip Data Loader'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'13'
,p_last_updated_by=>'SMUENCH'
,p_last_upd_yyyymmddhh24miss=>'20230813161335'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13613785781360291)
,p_plug_name=>'Upload Zip File'
,p_plug_display_sequence=>10
,p_plug_display_point=>'AFTER_LOGO'
,p_plug_source=>'- Upload Zip File'
,p_plug_query_num_rows=>15
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
,p_attribute_03=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(11748629200212139)
,p_button_sequence=>20
,p_button_name=>'Upload_and_Load_All_Data'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_imp.id(13494678121359846)
,p_button_image_alt=>'Upload And Load All Data'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(11748543471212138)
,p_name=>'P1_ZIP_FILE_UPLOAD'
,p_item_sequence=>10
,p_display_as=>'NATIVE_FILE'
,p_cSize=>30
,p_field_template=>wwv_flow_imp.id(13492184338359836)
,p_item_template_options=>'#DEFAULT#'
,p_attribute_01=>'APEX_APPLICATION_TEMP_FILES'
,p_attribute_09=>'REQUEST'
,p_attribute_10=>'N'
,p_attribute_12=>'DROPZONE_INLINE'
,p_attribute_13=>'Upload Athlete Session Data in Bulk'
,p_attribute_14=>'Drag and drop a zip file of athlete session data here, or click to choose a zip file from the file system.'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(11748720459212140)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Process Uploaded Zip to Load All Data'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'EBA_DEMO_BULK_DATA_LOAD'
,p_attribute_04=>'FROM_UPLOADED_ZIP_FILE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_when_button_id=>wwv_flow_imp.id(11748629200212139)
,p_internal_uid=>11748720459212140
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(11748824719212141)
,p_page_process_id=>wwv_flow_imp.id(11748720459212140)
,p_page_id=>1
,p_name=>'p_file_name'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P1_ZIP_FILE_UPLOAD'
);
wwv_flow_imp.component_end;
end;
/
