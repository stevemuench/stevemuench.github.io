prompt --application/deployment/install/install_drop_tables
begin
--   Manifest
--     INSTALL: INSTALL-Drop Tables
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>11123263479045381
,p_default_application_id=>100
,p_default_id_offset=>2153279278969116
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13619473596619115)
,p_install_id=>wwv_flow_imp.id(13617154368407474)
,p_name=>'Drop Tables'
,p_sequence=>10
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'    l_tables apex_t_varchar2 := apex_t_varchar2(''eba_demo_athletes'',',
'                                                ''eba_demo_athlete_sessions'',',
'                                                ''eba_demo_athlete_session_data'',',
'                                                ''eba_demo_uploaded_session_data'');',
'begin',
'    --',
'    -- Quietly drop all tables in the list',
'    --',
'    for j in 1..l_tables.count loop',
'        begin',
'            execute immediate ''drop table ''||l_tables(j)||'' cascade constraints'';',
'        exception',
'            when others then',
'                if sqlcode != -942 then',
'                    raise;',
'                end if;',
'        end;',
'    end loop;',
'end;',
'/',
''))
);
wwv_flow_imp.component_end;
end;
/
