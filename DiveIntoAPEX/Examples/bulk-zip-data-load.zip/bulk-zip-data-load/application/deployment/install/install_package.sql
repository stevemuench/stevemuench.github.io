prompt --application/deployment/install/install_package
begin
--   Manifest
--     INSTALL: INSTALL-Package
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>11123263479045381
,p_default_application_id=>100
,p_default_id_offset=>2153279278969116
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(13617766310409532)
,p_install_id=>wwv_flow_imp.id(13617154368407474)
,p_name=>'Package'
,p_sequence=>30
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'create or replace package eba_demo_bulk_data_load is ',
'    procedure from_uploaded_zip_file( ',
'        p_file_name in varchar2); ',
'end;',
'/',
'create or replace package body eba_demo_bulk_data_load is ',
'    procedure from_uploaded_zip_file( ',
'        p_file_name in varchar2)  ',
'    is',
'        l_zipfile        blob;',
'        l_csv_file       blob;',
'        l_files          apex_zip.t_files;',
'        l_result         apex_data_loading.t_data_load_result;',
'        l_file_count     pls_integer := 0;',
'        l_row_count      pls_integer := 0;',
'        l_error_count    pls_integer := 0;',
'        l_session_date   date;',
'        l_athlete_name   eba_demo_athletes.name%type;',
'        l_athlete_id     eba_demo_athletes.id%type;',
'        l_filename_parts apex_t_varchar2;',
'        l_new_session_id eba_demo_athlete_sessions.id%type;',
'    begin ',
'        --',
'        -- Get the uploaded zip file',
'        --',
'        select blob_content',
'        into l_zipfile',
'        from apex_application_temp_files',
'        where name = p_file_name;',
'        --',
'        -- Get list of files from the zip',
'        --',
'        l_files := apex_zip.get_files(l_zipfile);',
'        --',
'        -- Process the individual files inside the zip',
'        --',
'        for j in 1..l_files.count loop',
'            --',
'            -- Start by clearing any existing rows out of the temporary upload table',
'            --',
'            delete from eba_demo_uploaded_session_data;',
'            --',
'            -- Get the contents of the current CSV file in the zip file',
'            --',
'            l_csv_file := apex_zip.get_file_content(l_zipfile,l_files(j));',
'            --',
'            -- Load the data from the current CSV file into the temp data loading table',
'            -- using the data loading definition with static id ''athlete_session_data_csv''',
'            --',
'            l_result := apex_data_loading.load_data(',
'                            p_data_to_load => l_csv_file,',
'                            p_static_id    => ''athlete_session_data_csv'');',
'    ',
'            --',
'            -- Track number of files, rows, and errors during processing',
'            --',
'            l_file_count   := l_file_count + 1;',
'            l_row_count    := l_row_count  + l_result.processed_rows;',
'            l_error_count  := l_error_count  + l_result.error_rows;',
'            --',
'            -- Extract the name of the athlete from the current file name',
'            -- that we are assuming will be of the form:',
'            --',
'            -- athletes/AMINA/SESSION_2023_08_01_12_10.csv',
'            --',
'            l_filename_parts := apex_string.split(l_files(j),''/'');',
'            l_athlete_name   := l_filename_parts(2);',
'            l_session_date   := to_date(l_filename_parts(3),''"SESSION_"YYYY_MM_DD_HH24_MI".csv"'');',
'            --',
'            -- Lookup the athlete id from their name. If not found, then',
'            -- create a new athlete with this name and return the newly',
'            -- assigned athlete id into l_athlete_id',
'            --',
'            begin',
'                select id',
'                into l_athlete_id',
'                from eba_demo_athletes',
'                where name = l_athlete_name;',
'            exception',
'                when no_data_found then',
'                    insert into eba_demo_athletes(',
'                        name',
'                    )',
'                    values(',
'                        l_athlete_name',
'                    )',
'                    returning id into l_athlete_id;',
'            end;',
'            --',
'            -- Create a new athlete session for the athlete id',
'            -- and session date (inferred from the CSV file name above)',
'            --',
'            insert into eba_demo_athlete_sessions(',
'                athlete_id,',
'                session_date',
'            )',
'            values (',
'                l_athlete_id,',
'                l_session_date',
'            )',
'            returning id into l_new_session_id;',
'            --',
'            -- Finally, move all the uploaded performance data for the current',
'            -- athlete''s session into the newly created athlete session',
'            -- using the l_new_session_id returned above',
'            --',
'            insert into eba_demo_athlete_session_data(',
'                athlete_session_id,',
'                activity,',
'                value1,',
'                value2',
'            )',
'            select ',
'                l_new_session_id,',
'                activity,',
'                value1,',
'                value2',
'              from eba_demo_uploaded_session_data;',
'        end loop;',
'        --',
'        -- For good measure, leave the temporary upload table empty once',
'        -- we''re done processing the CSV files in the zip.',
'        --',
'        delete from eba_demo_uploaded_session_data;',
'    end; ',
'end;',
'/ '))
);
wwv_flow_imp_shared.create_install_object(
 p_id=>wwv_flow_imp.id(4410909042414)
,p_script_id=>wwv_flow_imp.id(13617766310409532)
,p_object_owner=>'#OWNER#'
,p_object_type=>'PACKAGE'
,p_object_name=>'EBA_DEMO_BULK_DATA_LOAD'
,p_last_updated_by=>'SMUENCH'
,p_last_updated_on=>to_date('20230813150709','YYYYMMDDHH24MISS')
,p_created_by=>'SMUENCH'
,p_created_on=>to_date('20230813150709','YYYYMMDDHH24MISS')
);
wwv_flow_imp.component_end;
end;
/
