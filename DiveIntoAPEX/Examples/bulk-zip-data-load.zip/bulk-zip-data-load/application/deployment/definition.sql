prompt --application/deployment/definition
begin
--   Manifest
--     INSTALL: 100
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.0'
,p_default_workspace_id=>11123263479045381
,p_default_application_id=>100
,p_default_id_offset=>2153279278969116
,p_default_owner=>'WKSP_DEV'
);
wwv_flow_imp_shared.create_install(
 p_id=>wwv_flow_imp.id(13617154368407474)
,p_deinstall_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'DROP TABLE "EBA_DEMO_ATHLETES" CASCADE CONSTRAINTS;',
'DROP TABLE "EBA_DEMO_ATHLETE_SESSIONS" CASCADE CONSTRAINTS;',
'DROP TABLE "EBA_DEMO_ATHLETE_SESSION_DATA" CASCADE CONSTRAINTS;',
'DROP TABLE "EBA_DEMO_UPLOADED_SESSION_DATA" CASCADE CONSTRAINTS;',
''))
);
wwv_flow_imp.component_end;
end;
/
