prompt --application/deployment/install/install_sample_items
begin
--   Manifest
--     INSTALL: INSTALL-Sample Items
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>277464
,p_default_id_offset=>16714660002257548
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_install_script(
 p_id=>wwv_flow_imp.id(63069756285727331727)
,p_install_id=>wwv_flow_imp.id(63063004144493230148)
,p_name=>'Sample Items'
,p_sequence=>20
,p_script_type=>'INSTALL'
,p_script_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    insert into eba_demo_item(name) values (''Apple'');',
'    insert into eba_demo_item(name) values (''Banana'');',
'    insert into eba_demo_item(name) values (''Cherry'');',
'    insert into eba_demo_item(name) values (''Date'');',
'    insert into eba_demo_item(name) values (''Elderberry'');',
'    insert into eba_demo_item(name) values (''Fig'');',
'    insert into eba_demo_item(name) values (''Grape'');',
'    insert into eba_demo_item(name) values (''Honeydew'');',
'    insert into eba_demo_item(name) values (''Ita'');',
'    insert into eba_demo_item(name) values (''Jackfruit'');',
'    insert into eba_demo_item(name) values (''Kiwi'');',
'    insert into eba_demo_item(name) values (''Lemon'');',
'    insert into eba_demo_item(name) values (''Mango'');',
'    insert into eba_demo_item(name) values (''Nectarine'');',
'    insert into eba_demo_item(name) values (''Orange'');',
'    insert into eba_demo_item(name) values (''Papaya'');',
'    insert into eba_demo_item(name) values (''Quince'');',
'    insert into eba_demo_item(name) values (''Raspberry'');',
'    insert into eba_demo_item(name) values (''Strawberry'');',
'    insert into eba_demo_item(name) values (''Tomato'');',
'    insert into eba_demo_item(name) values (''Ugli'');',
'    insert into eba_demo_item(name) values (''Voavanga''); ',
'    insert into eba_demo_item(name) values (''Watermelon'');',
'    insert into eba_demo_item(name) values (''Xigua'');',
'    insert into eba_demo_item(name) values (''Yuzu'');',
'    insert into eba_demo_item(name) values (''Zucchini'');',
'    commit;',
'end;'))
);
wwv_flow_imp.component_end;
end;
/
