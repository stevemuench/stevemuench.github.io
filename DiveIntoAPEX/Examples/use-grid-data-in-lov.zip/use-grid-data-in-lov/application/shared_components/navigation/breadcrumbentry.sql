prompt --application/shared_components/navigation/breadcrumbentry
begin
--   Manifest
--     BREADCRUMB ENTRY: 
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>277464
,p_default_id_offset=>16714660002257548
,p_default_owner=>'WKSP_SMUENCH'
);
null;
wwv_flow_imp.component_end;
end;
/
