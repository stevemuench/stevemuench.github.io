prompt --application/shared_components/navigation/lists/navigation_menu
begin
--   Manifest
--     LIST: Navigation Menu
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2023.04.28'
,p_release=>'23.1.2'
,p_default_workspace_id=>230327479351921145
,p_default_application_id=>277464
,p_default_id_offset=>16714660002257548
,p_default_owner=>'WKSP_SMUENCH'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(63063156667460985946)
,p_name=>'Navigation Menu'
,p_list_status=>'PUBLIC'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(63069957256514100878)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Orders'
,p_list_item_link_target=>'f?p=&APP_ID.:2:&APP_SESSION.::&DEBUG.:::'
,p_list_item_icon=>'fa-table'
,p_list_item_current_type=>'COLON_DELIMITED_PAGE_LIST'
,p_list_item_current_for_pages=>'2,3'
);
wwv_flow_imp.component_end;
end;
/
