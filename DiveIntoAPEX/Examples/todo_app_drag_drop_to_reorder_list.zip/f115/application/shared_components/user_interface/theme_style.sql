prompt --application/shared_components/user_interface/theme_style
begin
--   Manifest
--     THEME STYLE: 115
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>19404766370905118
,p_default_application_id=>115
,p_default_id_offset=>21701331810507059
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63580307815444627)
,p_theme_id=>42
,p_name=>'Vita - Red'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Red.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Red#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>1938457712423918173
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63580465192444627)
,p_theme_id=>42
,p_name=>'Redwood Light'
,p_css_file_urls=>wwv_flow_string.join(wwv_flow_t_varchar2(
'#IMAGE_PREFIX#libraries/oracle-fonts/oraclesans-apex#MIN#.css?v=#APEX_VERSION#',
'#THEME_IMAGES#css/Redwood-Light#MIN#.css?v=#APEX_VERSION#'))
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_read_only=>true
,p_reference_id=>2596426436825065489
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63580698244444627)
,p_theme_id=>42
,p_name=>'Vita'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>true
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>2719875314571594493
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63580839104444627)
,p_theme_id=>42
,p_name=>'Vita - Slate'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Slate.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Slate#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3291983347983194966
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63581083450444628)
,p_theme_id=>42
,p_name=>'Vita - Dark'
,p_is_current=>false
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Dark.less'
,p_theme_roller_output_file_url=>'#THEME_IMAGES#css/Vita-Dark#MIN#.css?v=#APEX_VERSION#'
,p_theme_roller_read_only=>true
,p_reference_id=>3543348412015319650
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63581291398444628)
,p_theme_id=>42
,p_name=>'Vista'
,p_css_file_urls=>'#THEME_IMAGES#css/Vista#MIN#.css?v=#APEX_VERSION#'
,p_is_current=>false
,p_is_public=>false
,p_is_accessible=>false
,p_theme_roller_read_only=>true
,p_reference_id=>4007676303523989775
);
wwv_flow_api.create_theme_style(
 p_id=>wwv_flow_api.id(63660226514447659)
,p_theme_id=>42
,p_name=>'App Todo Vita Slate'
,p_is_current=>true
,p_is_public=>true
,p_is_accessible=>false
,p_theme_roller_input_file_urls=>'#THEME_IMAGES#less/theme/Vita-Slate.less'
,p_theme_roller_config=>'{"customCSS":".appTodo .element {\n    height: 3em;\n    width: 25em;\n    transition: all .1s ease-out;\n    border-bottom: 1px solid #eee\n}\n.appTodo .element:hover {\n    -webkit-transform: translateY(-2px);\n    -ms-transform: translateY(-2px);\'
||'n    transform: translateY(-2px);\n    box-shadow: 0 4px 4px -4px rgba(0,0,0,.05);\n}\n\nul.appTodo {\n    list-style-type: none;\n}\n\n.fa-2 {\n    font-size: 2em;\n}\n\n.appTodo .element a {\n    color: #1d1d1d;\n    position: relative;\n}\n\n.appT'
||'odo a.chkItem {\n    float: right;\n    right: 10px;\n    top: 7px;\n}\n\n.appTodo a.deleteChk:hover {\n    color: #eb4747;\n}\n.appTodo a.deleteChk:hover i.fa-trash {\n    transform: scale(1.1);\n}\n\n.appTodo a.deleteChk {\n    top: 13px;\n    left'
||': 8px;\n    color: #646464;\n}\n\n.appTodo a.todoElement {\n    top: 12px;\n    left: 12px;\n}","vars":{}}'
,p_theme_roller_output_file_url=>'#THEME_DB_IMAGES#41958894703940600.css'
,p_theme_roller_read_only=>false
);
wwv_flow_api.component_end;
end;
/
