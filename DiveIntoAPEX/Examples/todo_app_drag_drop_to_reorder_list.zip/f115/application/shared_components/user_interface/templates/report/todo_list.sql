prompt --application/shared_components/user_interface/templates/report/todo_list
begin
--   Manifest
--     ROW TEMPLATE: TODO_LIST
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>19404766370905118
,p_default_application_id=>115
,p_default_id_offset=>21701331810507059
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_row_template(
 p_id=>wwv_flow_api.id(63641324228594774)
,p_row_template_name=>'Todo List'
,p_internal_name=>'TODO_LIST'
,p_row_template1=>'<li data-id="#ID#"><div class="element">#DEL_CHK# #TODO# #CHECK_ITEM#</div></li>'
,p_row_template_before_rows=>wwv_flow_string.join(wwv_flow_t_varchar2(
' <ul class="appTodo">',
''))
,p_row_template_after_rows=>' </ul>'
,p_row_template_type=>'NAMED_COLUMNS'
,p_row_template_display_cond1=>'0'
,p_row_template_display_cond2=>'0'
,p_row_template_display_cond3=>'0'
,p_row_template_display_cond4=>'0'
,p_theme_id=>42
,p_theme_class_id=>7
,p_translate_this_template=>'N'
);
wwv_flow_api.component_end;
end;
/
