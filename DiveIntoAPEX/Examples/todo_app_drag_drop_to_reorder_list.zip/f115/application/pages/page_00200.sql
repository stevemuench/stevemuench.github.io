prompt --application/pages/page_00200
begin
--   Manifest
--     PAGE: 00200
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2021.04.15'
,p_release=>'21.1.5'
,p_default_workspace_id=>19404766370905118
,p_default_application_id=>115
,p_default_id_offset=>21701331810507059
,p_default_owner=>'EXAMPLES'
);
wwv_flow_api.create_page(
 p_id=>200
,p_user_interface_id=>wwv_flow_api.id(63601194548444648)
,p_name=>'Todos'
,p_alias=>'TODOS'
,p_step_title=>'Todos'
,p_autocomplete_on_off=>'OFF'
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function updateDisplaySeq() {',
'    var results = $("ul.appTodo").sortable(''toArray'', {attribute: ''data-id''}).toString();',
'    apex.server.process( "UPDATE_ORDER",',
'    {x01:results},',
'    {',
'        success: function( pData )',
'        {',
'            apex.event.trigger(''#todoRegion'',''apexrefresh'');',
'        },',
'        dataType: "text"',
'    });',
'}'))
,p_css_file_urls=>'#JQUERYUI_DIRECTORY#ui/widgets/#MIN_DIRECTORY#sortable#MIN#.js'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_last_updated_by=>'LEARNING'
,p_last_upd_yyyymmddhh24miss=>'20210823143601'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(63626007335487792)
,p_name=>'Classic Report'
,p_template=>wwv_flow_api.id(63499026906444571)
,p_display_sequence=>20
,p_region_template_options=>'#DEFAULT#:is-collapsed:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'TABLE'
,p_query_table=>'APP_TODO'
,p_include_rowid_column=>false
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(63544924506444598)
,p_query_num_rows=>50
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_query_num_rows_type=>'NEXT_PREVIOUS_LINKS'
,p_pagination_display_position=>'BOTTOM_RIGHT'
,p_csv_output=>'Y'
,p_csv_output_link_text=>'Download'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63626382083487793)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>1
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63626749110487794)
,p_query_column_id=>2
,p_column_alias=>'OWNER'
,p_column_display_sequence=>2
,p_column_heading=>'Owner'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63627207070487794)
,p_query_column_id=>3
,p_column_alias=>'DISPLAY_SEQ'
,p_column_display_sequence=>3
,p_column_heading=>'Display Seq'
,p_column_alignment=>'RIGHT'
,p_heading_alignment=>'RIGHT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63627574112487794)
,p_query_column_id=>4
,p_column_alias=>'TODO'
,p_column_display_sequence=>4
,p_column_heading=>'Todo'
,p_heading_alignment=>'LEFT'
,p_disable_sort_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63632443707503276)
,p_query_column_id=>5
,p_column_alias=>'COMPLETED_BY'
,p_column_display_sequence=>14
,p_column_heading=>'Completed By'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63632622481503277)
,p_query_column_id=>6
,p_column_alias=>'COMPLETED_ON'
,p_column_display_sequence=>24
,p_column_heading=>'Completed On'
,p_use_as_row_header=>'N'
,p_disable_sort_column=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_region(
 p_id=>wwv_flow_api.id(63631106681503262)
,p_name=>'Todo List'
,p_region_name=>'todoRegion'
,p_template=>wwv_flow_api.id(63516006653444580)
,p_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#'
,p_display_point=>'BODY'
,p_source_type=>'NATIVE_SQL_REPORT'
,p_query_type=>'SQL'
,p_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select id',
'     , id del_chk',
'     , todo',
'     , ''<i class="fa fa-2 fa'' ',
'       || case ',
'             when completed_by is null then '''' ',
'             else                           ''-check'' ',
'          end ',
'       || ''-square-o"></i>'' check_item',
'from app_todo',
'where owner = :APP_USER',
'order by display_seq'))
,p_ajax_enabled=>'Y'
,p_lazy_loading=>false
,p_query_row_template=>wwv_flow_api.id(63641324228594774)
,p_query_num_rows=>15
,p_query_options=>'DERIVED_REPORT_COLUMNS'
,p_csv_output=>'N'
,p_prn_output=>'N'
,p_sort_null=>'L'
,p_plug_query_strip_html=>'N'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63631147984503263)
,p_query_column_id=>1
,p_column_alias=>'ID'
,p_column_display_sequence=>10
,p_column_heading=>'Id'
,p_use_as_row_header=>'N'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63633090141503282)
,p_query_column_id=>2
,p_column_alias=>'DEL_CHK'
,p_column_display_sequence=>20
,p_column_heading=>'Del Chk'
,p_use_as_row_header=>'N'
,p_column_link=>'#0'
,p_column_linktext=>'<i class="fa fa-trash"></i>'
,p_column_link_attr=>'data-id="#DEL_CHK#" class="deleteChk"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63631309332503264)
,p_query_column_id=>3
,p_column_alias=>'TODO'
,p_column_display_sequence=>30
,p_column_heading=>'Todo'
,p_use_as_row_header=>'N'
,p_column_link=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:201:P201_ID:#ID#'
,p_column_linktext=>'#TODO#'
,p_column_link_attr=>'class="todoElement"'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_report_columns(
 p_id=>wwv_flow_api.id(63631922818503270)
,p_query_column_id=>4
,p_column_alias=>'CHECK_ITEM'
,p_column_display_sequence=>40
,p_column_heading=>'Check Item'
,p_use_as_row_header=>'N'
,p_column_link=>'#0'
,p_column_linktext=>'#CHECK_ITEM#'
,p_column_link_attr=>'data-id="#ID#" class="chkItem"'
,p_display_as=>'WITHOUT_MODIFICATION'
,p_derived_column=>'N'
,p_include_in_export=>'Y'
);
wwv_flow_api.create_page_button(
 p_id=>wwv_flow_api.id(63629679952487797)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_api.id(63631106681503262)
,p_button_name=>'CREATE'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>wwv_flow_api.id(63578493285444622)
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Add Todo'
,p_button_position=>'BELOW_BOX'
,p_button_redirect_url=>'f?p=&APP_ID.:201:&SESSION.::&DEBUG.:201'
);
wwv_flow_api.create_page_item(
 p_id=>wwv_flow_api.id(63632193756503273)
,p_name=>'P200_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_api.id(63631106681503262)
,p_display_as=>'NATIVE_HIDDEN'
,p_attribute_01=>'N'
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(63628698919487796)
,p_name=>'Edit Report - Dialog Closed'
,p_event_sequence=>10
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(63626007335487792)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63629190243487797)
,p_event_id=>wwv_flow_api.id(63628698919487796)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63626007335487792)
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63631446890503266)
,p_event_id=>wwv_flow_api.id(63628698919487796)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63631106681503262)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(63631545534503267)
,p_name=>'Edit Todo - Dialog Closed'
,p_event_sequence=>20
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(63631106681503262)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterclosedialog'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63631762734503269)
,p_event_id=>wwv_flow_api.id(63631545534503267)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63631106681503262)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(63631971489503271)
,p_name=>'Toggle Check Item'
,p_event_sequence=>30
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.chkItem'
,p_bind_type=>'live'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63632266064503274)
,p_event_id=>wwv_flow_api.id(63631971489503271)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P200_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63632080049503272)
,p_event_id=>wwv_flow_api.id(63631971489503271)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'update app_todo',
'   set completed_by = case ',
'                        when completed_by is null then :APP_USER ',
'                        else null ',
'                      end,',
'       completed_on = case ',
'                        when completed_by is null then sysdate ',
'                        else null ',
'                      end                      ',
'   where id = :P200_ID',
'     and owner = :APP_USER;'))
,p_attribute_02=>'P200_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63632423780503275)
,p_event_id=>wwv_flow_api.id(63631971489503271)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63631106681503262)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(63633215214503283)
,p_name=>'Delete Todo'
,p_event_sequence=>40
,p_triggering_element_type=>'JQUERY_SELECTOR'
,p_triggering_element=>'.deleteChk'
,p_bind_type=>'live'
,p_bind_event_type=>'click'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63633369289503285)
,p_event_id=>wwv_flow_api.id(63633215214503283)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_CONFIRM'
,p_attribute_01=>'Are you sure you want to delete?'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63633327577503284)
,p_event_id=>wwv_flow_api.id(63633215214503283)
,p_event_result=>'TRUE'
,p_action_sequence=>20
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_SET_VALUE'
,p_affected_elements_type=>'ITEM'
,p_affected_elements=>'P200_ID'
,p_attribute_01=>'JAVASCRIPT_EXPRESSION'
,p_attribute_05=>'this.triggeringElement.dataset.id'
,p_attribute_09=>'N'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63633498252503286)
,p_event_id=>wwv_flow_api.id(63633215214503283)
,p_event_result=>'TRUE'
,p_action_sequence=>30
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'delete ',
'  from app_todo',
'where owner = :APP_USER ',
'  and id = :P200_ID;'))
,p_attribute_02=>'P200_ID'
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63633604865503287)
,p_event_id=>wwv_flow_api.id(63633215214503283)
,p_event_result=>'TRUE'
,p_action_sequence=>40
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_REFRESH'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63631106681503262)
);
wwv_flow_api.create_page_da_event(
 p_id=>wwv_flow_api.id(63633710176503288)
,p_name=>'Make Region Sortable'
,p_event_sequence=>50
,p_triggering_element_type=>'REGION'
,p_triggering_region_id=>wwv_flow_api.id(63631106681503262)
,p_bind_type=>'bind'
,p_bind_event_type=>'apexafterrefresh'
);
wwv_flow_api.create_page_da_action(
 p_id=>wwv_flow_api.id(63633761097503289)
,p_event_id=>wwv_flow_api.id(63633710176503288)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_api.id(63631106681503262)
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'$(this.affectedElements[0]).find("ul").sortable({',
'    items: ''li''',
'  , containment: ''#todoRegion''',
'  , update: function(event,ui) { updateDisplaySeq(); }',
'});'))
);
wwv_flow_api.create_page_process(
 p_id=>wwv_flow_api.id(63633858531503290)
,p_process_sequence=>10
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'UPDATE_ORDER'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'declare',
'  l_array apex_application_global.vc_arr2;',
'  s number;',
'begin',
'  l_array := apex_util.string_to_table(apex_application.g_x01,'','');',
'  for i in 1..l_array.count loop',
'    s := i * 10;',
'    update app_todo',
'      set display_seq = s',
'      where id = to_number(l_array(i))',
'      and (display_seq is null or display_seq != s);',
'  end loop;',
'  htp.prn(''{"result":"OK"}'');',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
);
wwv_flow_api.component_end;
end;
/
